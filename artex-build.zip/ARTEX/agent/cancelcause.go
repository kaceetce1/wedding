package agent

import (
	"context"
	"errors"
	"fmt"
)

// AbortCause names why an agent run's context was cancelled. Every cancellation
// site should attach one so the activity trace can report the real initiator.
type AbortCause struct {
	Code  string
	Short string
	Text  string
}

func (c *AbortCause) Error() string { return c.Text }

func cause(code, short, text string) *AbortCause {
	return &AbortCause{Code: code, Short: short, Text: text}
}

// Causef builds a cause that includes runtime-specific detail.
func Causef(code, short, format string, args ...any) *AbortCause {
	return &AbortCause{Code: code, Short: short, Text: fmt.Sprintf(format, args...)}
}

var (
	// Task-level execution context.
	AbortPausedByUser = cause("paused_by_user", "User paused the task",
		"User paused the task via the task-control API (POST /api/tasks/{id}/control, action=pause). This Planner/Worker run was actively cancelled; the intent that was running is returned to the frontier(open) and, after the task resumes, is claimed again and executed from the start")
	AbortPausedByOrchestrator = cause("paused_by_orchestrator", "The orchestrator agent paused the task",
		"The orchestrator agent called the pause_task tool to pause this task. This Planner/Worker run was actively cancelled; the intent that was running is returned to the frontier(open) and re-executed after resuming")
	AbortTaskDeleted = cause("task_deleted", "Task deleted",
		"The task is being deleted (DELETE /api/tasks/{id}); the deletion barrier has cancelled the Planner, Worker and main Agent currently running for this task; the results of this run will no longer be used")
	AbortPausedOnReload = cause("paused_on_reload", "Backend restored the task's paused state",
		"On startup the backend restored the task's paused state from the status persisted in the database. This run was cancelled; normally no Agent is running during the restore phase")
	AbortGoalMet = cause("goal_met", "Planner determined the task goals were met",
		"The planner determined the task goals were met and set the task to done, then cancelled the Worker still running; those intents are marked stopped rather than failed")
	AbortSettleDrainTimeout = cause("settle_drain_timeout", "The wait for task-timeout settlement was exhausted",
		"After the task reached timeout, the system waited for the running Worker to settle gracefully, but the 90-second drain grace was still insufficient, so a hard cancel was performed; the intent is marked exhausted, and the facts and assets already written during settlement are kept")

	// Per-work context.
	AbortKilledByPlanner = cause("killed_by_planner", "Planner terminated this intent",
		"The planner called kill_work to actively terminate this intent, usually meaning it went off track or no longer has value; the intent is marked stopped and will not be re-claimed automatically")
	AbortWorkPausedByUser = cause("work_paused_by_user", "User paused this Worker intent",
		"The user paused the running Worker. This call was cancelled and the intent turned to paused; all registered intents, facts, findings and activity records are kept, and it re-executes from the start after resuming")
	AbortWorkCancelledByUser = cause("work_cancelled_by_user", "User deleted this Worker intent",
		"The user deleted the running Worker. This call was cancelled; after the Worker exits its write region, the server handles the intent according to the deletion mode the user chose — a soft delete only marks it deleted and keeps all its output, while a hard delete cascades and removes the intent together with the downstream nodes supported only by it")
	AbortWorkFinished = cause("work_finished", "Worker finished normally and released its context",
		"The Worker finished normally and the engine released its context resources in detachWork. This is not a run interruption; if it appears in an interruption message, it means a race occurred between cancellation and the finish event")
	AbortPausedRaceGuard = cause("paused_race_guard", "Refusing to start a new run while the task is paused",
		"While the task is paused, the engine refuses to issue a new execution context, to prevent a race between claim and pause from letting a Worker keep starting; claimed intents are returned to the frontier")

	// Main Agent and standalone conversation contexts.
	AbortChatStoppedByUser = cause("chat_stopped_by_user", "User stopped this conversation turn",
		"The user clicked stop, actively aborting this main Agent or conversation Agent run. Activity records already produced are kept, and the next message can still be sent")
	AbortChatPausedWithTask = cause("chat_paused_with_task", "Task paused and aborted the main Agent conversation",
		"When the user paused the task, the main Agent conversation that was running was cancelled as well. Activity records already produced are kept; this turn's messages will not be replayed automatically after the task resumes")
	AbortChatTurnFinished = cause("chat_turn_finished", "This conversation turn finished normally and released its context",
		"This conversation turn finished normally and the server is releasing that turn's context resources. This is not a run interruption; if it appears in an interruption message, it means a race occurred between cancellation and the finish event")

	// Process-level and per-run hard backstop.
	AbortShutdown = cause("shutdown", "Backend process is shutting down",
		"The backend process received SIGINT or SIGTERM and is restarting, updating or shutting down. All running Agents are cancelled; after a restart, leftover running intents are reset to open and re-executed")
	AbortRunHardTimeout = cause("run_hard_timeout", "A single run's hard-timeout backstop triggered",
		"A single run exceeded the soft wall-clock budget plus the extra grace, meaning a model request or some tool did not return for a long time, so the normal turn-boundary settlement could not run. Check in particular the last tool call that had not returned before the interruption")
)

// AbortReason resolves the named cause attached to a cancelled run context.
func AbortReason(ctx context.Context) (code, short, text string, ok bool) {
	c := context.Cause(ctx)
	if c == nil {
		return "", "", "", false
	}
	var ac *AbortCause
	if errors.As(c, &ac) {
		return ac.Code, ac.Short, ac.Text, true
	}
	switch {
	case errors.Is(c, context.DeadlineExceeded):
		return "deadline_exceeded", "Upstream context reached its deadline",
			"Upstream context reached its deadline, but the setter did not attach a named cause via WithTimeoutCause: " + c.Error(), true
	case errors.Is(c, context.Canceled):
		return "canceled_no_cause", "Canceller attached no named cause",
			"Upstream context was cancelled, but the canceller did not attach a named cause via context.WithCancelCause; register a cause in agent/cancelcause.go and wire it into that cancellation site", true
	default:
		return "other", firstLine(c.Error(), 80), c.Error(), true
	}
}
