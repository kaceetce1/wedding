package agent

import (
	"context"

	"github.com/Autumn-27/artex/db"
)

// FindingRecorder is injected by the host; agents never synthesize or copy
// evidence bodies themselves. Its implementation owns the atomic write.
type FindingRecorder interface {
	Record(context.Context, db.RecordFindingInput, []db.TrafficRef) (*db.RecordedFinding, error)
}

// Tool-use guidance is appended without replacing the user's editable prompt.
// It does not require capture or claim that unavailable traffic tools exist.
const findingTrafficGuidance = "\n\n**Finding traffic evidence (optional)**: when calling report_finding to report a finding, if there is an HTTP request/response you have inspected and confirmed to support the finding conclusion, you may use traffic_refs to bind real IDs in reproduction order; domain and time serve only as candidate filters and do not imply association. For non-HTTP findings such as TCP, or when uncollected or with no exact match, omit it or pass [], keep other verifiable evidence such as command output and logs in evidence, and preferably explain why it was not bound. Do not guess IDs, and do not repeat probing merely to fill in packets."

func (t *ToolSet) SetFindingRecorder(r FindingRecorder)   { t.findingRecorder = r }
func (w *Worker) SetFindingRecorder(r FindingRecorder)    { w.findingRecorder = r }
func (p *Planner) SetFindingRecorder(r FindingRecorder)   { p.findingRecorder = r }
func (m *MainAgent) SetFindingRecorder(r FindingRecorder) { m.findingRecorder = r }
