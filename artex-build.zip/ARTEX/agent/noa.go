package agent

import (
	"log"
	"path/filepath"

	"github.com/Autumn-27/norma/agentcore"
	"github.com/Autumn-27/norma/noaadapter"
)

// noaWarn returns a diagnostics sink tagging non-fatal noa messages with the
// session, routed through the package logger (agents have no per-instance one).
func noaWarn(session string) func(string) {
	return func(msg string) { log.Printf("[noa] %s: %s", session, msg) }
}

// noa is the "model-driven context compression" mechanism introduced by norma v0.4.0,
// toggled by the user in system settings as a platform experimental feature. It is
// mutually exclusive with the built-in compaction: noaadapter.Enable is the only entry
// point, attaching a context taker-over (Compactor), the Compress tool and three
// resident prompt segments in one call; not calling Enable means off (built-in
// compaction keeps working as usual). The switch is resolved by the noaEnabledFn
// injected per agent and read once per run, so toggling only affects runs started
// afterwards and needs no agent rebuild.

// enableNoa wires noa into opts when the resolver reports it enabled. archiveRoot is
// the persistence base directory for archived raw text (the global workDir; every agent
// lands uniformly under <workDir>/noa, not scattered per task/intent directory), and
// sessionID names the archive subdirectory beneath it (globally unique, so it cannot
// collide within the same base directory).
//
// noa is experimental: a failed hookup must not interrupt the real task. On error it is
// reported via onWarn and falls back to built-in compaction. On success it clears
// opts.Compaction, avoiding the agentcore warning about two context managers set at once.
func enableNoa(opts *agentcore.Options, enabled func() bool, archiveRoot, sessionID string, onWarn func(string)) {
	if enabled == nil || !enabled() {
		return
	}
	if opts.OnWarn == nil {
		opts.OnWarn = onWarn
	}
	if err := noaadapter.Enable(opts, noaadapter.Options{
		ArchiveBaseDir: filepath.Join(archiveRoot, "noa"),
		SessionID:      sessionID,
		OnWarn:         onWarn,
	}); err != nil {
		if onWarn != nil {
			onWarn("noa compression enable failed, falling back to built-in compaction: " + err.Error())
		}
		return
	}
	// Compactor overrides Compaction, but with both set agentcore warns every time; clear it explicitly.
	opts.Compaction = nil
}
