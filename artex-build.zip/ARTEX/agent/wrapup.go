package agent

import (
	"strings"

	"github.com/Autumn-27/norma/harness"
)

// Wrap-up prompt (wrap-up / settlement prompt): when an agent is terminated because
// [its step budget is exhausted (MaxTurns)] or [it timed out (run_seconds/MaxDuration)],
// the SDK's settlement phase injects this prompt, letting the agent first persist the
// content it identified but did not write back, and then output a one-line summary,
// so the run does not end unfinished.
//
// Each agent's wrap-up prompt can be overridden on demand from the admin UI (stored in
// agents.wrapup_prompt); when left empty, the built-in default here is used. Only the
// [prompt body] is editable; which tools are disabled and how many turns the wrap-up
// itself is given are code-owned policy.

// WrapupOverride, if set, returns the stored wrap-up prompt for an agent key and
// whether a non-empty one exists. Wired by the server to the agents table (like
// PromptOverride for system prompts). nil / empty → the built-in default is used.
var WrapupOverride func(agentKey string) (string, bool)

// WrapupMaxTurnsOverride, if set, returns the admin-configured turn budget for the
// wrap-up phase of an agent and whether a positive one exists. Wired to the agents
// table. nil / ≤0 → the built-in per-agent default (wrapupTurnDefaults) is used.
var WrapupMaxTurnsOverride func(agentKey string) (int, bool)

// Built-in default wrap-up prompts, indexed by agent key. worker reuses the historically
// hard-coded settleWrapUpPrompt (defined in worker.go); planner/mainagent each have their
// own version; anything not matching (custom agents) falls back to the generic default.
var wrapupDefaults = map[string]string{
	"worker":    settleWrapUpPrompt,
	"planner":   plannerWrapUpDefault,
	"mainagent": mainAgentWrapUpDefault,
}

// wrapupTurnDefaults: each agent's built-in default turn budget for its [own] wrap-up
// phase (overridable from the admin UI when >0). All are given 10 turns, ensuring the
// wrap-up phase has enough steps to persist results. No match falls back to genericWrapupTurns.
var wrapupTurnDefaults = map[string]int{
	"worker":    10,
	"planner":   10,
	"mainagent": 10,
}

const genericWrapupTurns = 10

const plannerWrapUpDefault = "Your planning step budget for this round is about to run out — note that this is only the end of [this round]; the system will still wake you again as the situation changes to continue planning, this is not the task terminating, and you do not need to bring the whole plan to a close here. Persist the conclusions you have already worked out this round, don't let this round go to waste, but also [do not force intents just to wrap up] (0 intents this round is still a perfectly normal result): (1) if you have determined an exploration direction that [should be dispatched right now], submit it in one batch with add_intent (don't hold back what you've already decided on); (2) for goals that some finding/fact has shown to be achieved, call prove_goal to mark them met (don't miss any); (3) if you have identified a multi-step serial exploitation chain, note it down with TodoWrite so the next wake-up can continue dispatching it. When done, just end this round; no summary text is needed."

const mainAgentWrapUpDefault = "Your step budget is about to run out and this interaction is coming to an end. Do not start any new exploration/action. Please **summarize in a single plain-text sentence** for the user the current progress, the key conclusions, and the suggested next step."

const genericWrapUpDefault = "You are about to be terminated because your budget is exhausted. Please first write back the results you have completed but not yet persisted, then **in a single plain-text sentence** summarize what you did and the key conclusions you reached (this sentence will be shown as the result of this run)."

// WrapupDefault returns the built-in default wrap-up prompt for an agent key —
// used by the admin UI as the "restore default" value and empty-field placeholder.
func WrapupDefault(agentKey string) string {
	if d, ok := wrapupDefaults[agentKey]; ok {
		return d
	}
	return genericWrapUpDefault
}

// WrapupTurnsDefault returns the built-in wrap-up turn budget for an agent key —
// used by the admin UI as the "0 = default N" hint.
func WrapupTurnsDefault(agentKey string) int {
	if n, ok := wrapupTurnDefaults[agentKey]; ok {
		return n
	}
	return genericWrapupTurns
}

// resolveWrapup returns the effective wrap-up prompt: the DB override (if set and
// non-empty) over the built-in default.
func resolveWrapup(agentKey string) string {
	if WrapupOverride != nil {
		if t, ok := WrapupOverride(agentKey); ok && strings.TrimSpace(t) != "" {
			return t
		}
	}
	return WrapupDefault(agentKey)
}

// resolveWrapupTurns returns the effective wrap-up turn budget: a positive DB
// override over the built-in per-agent default.
func resolveWrapupTurns(agentKey string) int {
	if WrapupMaxTurnsOverride != nil {
		if v, ok := WrapupMaxTurnsOverride(agentKey); ok && v > 0 {
			return v
		}
	}
	return WrapupTurnsDefault(agentKey)
}

// wrapupSettlement builds the settlement config for an agent's run. Prompt and the
// turn budget are admin-editable per agent; disabled tools are code-owned policy so
// a user can't edit away the "stop probing" guardrail. Resolved fresh each run
// (reads DB live), so edits apply on the next run without a restart.
func wrapupSettlement(agentKey string, disabledTools []string) *harness.Settlement {
	return &harness.Settlement{
		Prompt:        resolveWrapup(agentKey),
		DisabledTools: disabledTools,
		MaxTurns:      resolveWrapupTurns(agentKey),
	}
}

// ---------- Task-level timeout wrap-up prompts (see docs/task-level-timeout-and-wrapup-design.md) ----------
//
// These are [two separate sets] from the per-run wrap-up prompts: per-run means "your budget
// for this one run is used up"; task timeout means "the whole task has hit its deadline and
// is about to end". Their semantics are often opposite (especially for planner: per-run says
// "don't stop, keep planning", while task timeout says "stop planning at the deadline and make
// the final determination"). Only worker/planner are configured with one.

// WrapupTaskTimeoutOverride / …TurnsOverride: DB overrides for the task-timeout wrap-up prompt
// and turn count (wired to agents.task_timeout_wrapup_prompt / _max_turns, worker/planner only).
var (
	WrapupTaskTimeoutOverride      func(agentKey string) (string, bool)
	WrapupTaskTimeoutTurnsOverride func(agentKey string) (int, bool)
)

var taskTimeoutWrapupDefaults = map[string]string{
	"worker":  workerTaskTimeoutDefault,
	"planner": plannerTaskTimeoutDefault,
}

const workerTaskTimeoutDefault = "**The entire task has reached its timeout limit and is about to end** (this is not your budget for this run, it is the whole exploration hitting its deadline). This is the last chance: (1) persist [all] the content you have identified but not yet written back — new assets via insert_assets, exploration conclusions/facts via record_fact, confirmed vulnerabilities via report_finding; (2) do not start any new command/probe; (3) **finally, in a single plain-text sentence**, summarize your key conclusions on this intent."

const plannerTaskTimeoutDefault = "**The entire task has reached its timeout limit and is about to end** (not this round, but the whole task terminating). Based on [all] the current facts and findings, make one final goal determination: for goals already proven achieved by evidence, call prove_goal to mark them met (don't miss any). **Do not generate any new intents** (dispatching intents now would not execute them anyway). Once the determination is done, wrap up; no summary text is needed."

// TaskTimeoutWrapupDefault returns an agent's built-in default task-timeout wrap-up prompt
// (used by the admin UI as an empty-field placeholder / restore-default value).
func TaskTimeoutWrapupDefault(agentKey string) string {
	return taskTimeoutWrapupDefaults[agentKey] // unconfigured (mainagent/chat) returns an empty string
}

// resolveTaskTimeoutWrapup: DB override (non-empty) > built-in default. An empty string means
// the agent has no task-timeout prompt (not worker/planner), in which case the caller should
// fall back to the per-run prompt.
func resolveTaskTimeoutWrapup(agentKey string) string {
	if WrapupTaskTimeoutOverride != nil {
		if t, ok := WrapupTaskTimeoutOverride(agentKey); ok && strings.TrimSpace(t) != "" {
			return t
		}
	}
	return TaskTimeoutWrapupDefault(agentKey)
}

func resolveTaskTimeoutTurns(agentKey string) int {
	if WrapupTaskTimeoutTurnsOverride != nil {
		if v, ok := WrapupTaskTimeoutTurnsOverride(agentKey); ok && v > 0 {
			return v
		}
	}
	return resolveWrapupTurns(agentKey) // by default, reuse the per-run turn count
}

// wrapupSettlementForTask builds settlement for a worker/planner run that is aware
// of the task deadline. See §5 of the design doc:
//   - clamped=true  → this run was clamped by the task deadline: a Timeout wrap-up = the task hit its deadline → task-timeout prompt;
//     a MaxTurns wrap-up = steps ran out first within the clamped window, with a few minutes left on the task → fall back to the per-run prompt.
//   - clamped=false → the task is still far off: both reasons use the per-run prompt (i.e. it degenerates to wrapupSettlement).
//
// The PromptByReason handed to the harness picks on the spot according to the [actual] reason
// at wrap-up time, so there is no mismatch when there is no build.
func wrapupSettlementForTask(agentKey string, disabledTools []string, clamped bool) *harness.Settlement {
	perRun := resolveWrapup(agentKey)
	st := &harness.Settlement{
		Prompt:        perRun, // fallback (also the value for both reasons when not clamped)
		DisabledTools: disabledTools,
		MaxTurns:      resolveWrapupTurns(agentKey),
	}
	if clamped {
		if tt := resolveTaskTimeoutWrapup(agentKey); tt != "" {
			st.PromptByReason = map[harness.TerminalReason]string{
				harness.ReasonTimeout:  tt,     // task hit its deadline
				harness.ReasonMaxTurns: perRun, // steps ran out first, task still has time left
			}
			st.MaxTurns = resolveTaskTimeoutTurns(agentKey)
		}
	}
	return st
}
