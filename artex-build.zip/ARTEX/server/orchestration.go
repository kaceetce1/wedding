package server

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"strconv"
	"strings"
	"time"

	"github.com/Autumn-27/artex/agent"
	"github.com/Autumn-27/artex/db"
	"github.com/Autumn-27/norma/permission"
	actool "github.com/Autumn-27/norma/tool"
)

// jsonResult marshals v to a JSON tool result.
func jsonResult(v any) (actool.Result, error) {
	b, err := json.Marshal(v)
	if err != nil {
		return actool.Errorf(err.Error()), nil
	}
	return actool.Text(string(b)), nil
}

// This file implements the P2 "cross-task orchestration tool set" (see the cross-task orchestration design doc §2 P2). These are host tools — they need
// access to Manager (any task's Store), Engine (pause), and the task-creation flow, so they live in the server layer.
// The read tools redirect the "existing per-task tools" to run against the target task's store (building a temporary ToolSet
// and calling the corresponding tool), thereby reusing exactly the same logic; the control tools (spawn/pause) call Manager/Engine directly.
// Like the traffic tools, they are seeded into the tools table and bound per-agent (visible only to orchestration agents).

// hostTools is the runtime host-tool provider fed to ToolAugment: traffic tools
// (gated by capture) + cross-task orchestration tools + user-defined custom tools.
// The second return is the names of custom tools flagged `deferred` (schema
// withheld, routed via SearchExtraTools/ExecuteExtraTool). Per-agent binding still
// decides who actually sees any of them.
//
//nolint:unused // used as the hostTools provider in wireAgentAugment
func (s *Server) hostTools() ([]actool.CoreTool, map[string][]string) {
	tools := append(s.m.HostTools(), s.orchestrationTools()...)
	tools = append(tools, s.findingRetestTools()...)
	tools = append(tools, s.platformTools()...) // platform operation tools (create/edit skill/tool/MCP, for Auto)
	custom, err := s.customTools()
	if err != nil {
		log.Printf("[custom-tool] load failed: %v", err)
		return tools, nil
	}
	tools = append(tools, custom...)
	// deferred custom tools → name -> its bound agent keys. ToolAugment turns a
	// name into a deferred entry only for agents it's actually bound to (so we don't
	// advertise a tool the per-agent binding will drop from the callable set).
	deferred := map[string][]string{}
	rows, _ := s.m.pg.ListCustomTools()
	for _, t := range rows {
		if t.Deferred && t.Enabled {
			deferred[t.Key] = t.Agents
		}
	}
	return tools, deferred
}

// orchestrationTools returns the cross-task tool set. Bound per-agent via the
// tools table (default: no binding — opt-in for orchestration agents).
func (s *Server) orchestrationTools() []actool.CoreTool {
	return []actool.CoreTool{
		s.toolListTasks(),
		s.toolListLLMProfiles(),
		s.toolSpawnTask(),
		s.toolPauseTask(),
		s.toolGetTaskGraph(),
		s.toolListTaskFindings(),
		s.toolAddHint(),
		s.toolGetWorkerTrace(),
		s.toolListWorkerTraces(),
		s.toolSearchWorkerTraces(),
		s.toolGetTaskNodeDetail(),
		s.toolUpdateFindingReport(),
		s.toolGetFindingTraffic(),
		s.toolBindFindingTraffic(),
	}
}

// --- schema helpers ---

func strParam(desc string) map[string]any {
	return map[string]any{"type": "string", "description": desc}
}

// parseProfileID reads an LLM profile id from a tool arg that may arrive as a JSON
// number (5) or a numeric string ("5"); returns 0 when absent/unparseable.
func parseProfileID(raw json.RawMessage) int64 {
	if len(raw) == 0 {
		return 0
	}
	var n int64
	if json.Unmarshal(raw, &n) == nil {
		return n
	}
	var str string
	if json.Unmarshal(raw, &str) == nil {
		v, _ := strconv.ParseInt(strings.TrimSpace(str), 10, 64)
		return v
	}
	return 0
}

func objSchema(props map[string]any, required ...string) map[string]any {
	m := map[string]any{"type": "object", "properties": props}
	if len(required) > 0 {
		req := make([]any, len(required))
		for i, r := range required {
			req[i] = r
		}
		m["required"] = req
	}
	return m
}

func roTool(name, desc string, schema map[string]any, run func(context.Context, json.RawMessage) (actool.Result, error)) actool.CoreTool {
	return actool.Build(actool.Spec{
		Name: name, Description: desc, Schema: schema,
		ReadOnly:   func(json.RawMessage) bool { return true },
		Concurrent: func(json.RawMessage) bool { return true },
		Permissions: func(context.Context, json.RawMessage, permission.Context) permission.Decision {
			return permission.Allowed()
		},
		Run: func(ctx context.Context, in json.RawMessage, _ *actool.ToolContext) (actool.Result, error) {
			return run(ctx, in)
		},
	})
}

func wrTool(name, desc string, schema map[string]any, run func(context.Context, json.RawMessage) (actool.Result, error)) actool.CoreTool {
	return actool.Build(actool.Spec{
		Name: name, Description: desc, Schema: schema,
		Permissions: func(context.Context, json.RawMessage, permission.Context) permission.Decision {
			return permission.Allowed()
		},
		Run: func(ctx context.Context, in json.RawMessage, _ *actool.ToolContext) (actool.Result, error) {
			return run(ctx, in)
		},
	})
}

// delegateToTask resolves the `task_id` in the input, builds a ToolSet bound to
// that task's store, strips task_id, and calls the chosen per-task tool — so the
// cross-task read reuses the exact in-task logic against another task.
func (s *Server) delegateToTask(ctx context.Context, in json.RawMessage, pick func(*agent.ToolSet) actool.CoreTool) (actool.Result, error) {
	var head struct {
		TaskID string `json:"task_id"`
	}
	_ = json.Unmarshal(in, &head)
	if strings.TrimSpace(head.TaskID) == "" {
		return actool.Errorf("task_id is required"), nil
	}
	t, ok := s.m.Task(head.TaskID)
	if !ok {
		return actool.Errorf("task not found: " + head.TaskID), nil
	}
	var m map[string]json.RawMessage
	_ = json.Unmarshal(in, &m)
	delete(m, "task_id")
	inner, _ := json.Marshal(m)
	tsx := agent.NewToolSet(t.Store, "orchestrator")
	if s.m.Assets() != nil {
		tsx.SetAssetStore(s.m.Assets(), s.m.Assets().Companies())
	}
	tsx.SetNotify(t.Notify)         // generic wake (write operations without a dedicated callback use it; read tools are a no-op)
	tsx.SetNotifyHint(t.NotifyHint) // add_hint → records "human added N strategic hints: …", which fires and wakes the planner
	return pick(tsx).Call(ctx, inner, nil)
}

// --- tools ---

func (s *Server) toolListTasks() actool.CoreTool {
	return roTool("list_tasks",
		"List all tasks (id/description/goal/status/run duration/parent task/LLM profile); orchestration agents use it to see the whole picture, which tasks have been stuck too long, and which LLM each uses. Run duration: running = created→now, terminal = created→last activity (seconds). llm_profile: the config name the task's planner/worker uses, (active profile) = follows the global active one.",
		objSchema(map[string]any{}),
		func(context.Context, json.RawMessage) (actool.Result, error) {
			lastAct, _ := s.m.PG().LastActivityAll()
			// id -> name to resolve each task's pinned LLM profile.
			profName := map[int64]string{}
			if profs, err := s.m.pg.ListProfiles(); err == nil {
				for _, p := range profs {
					profName[p.ID] = p.Name
				}
			}
			out := make([]map[string]any, 0)
			for _, t := range s.m.List() {
				status := s.deriveTaskStatus(t)
				end := lastAct[t.ExpID]
				if live := s.engine.LastActivity(t.ID); live > end {
					end = live
				}
				dur := int64(0)
				if status == "running" {
					dur = time.Now().Unix() - t.CreatedAt
				} else if end > t.CreatedAt {
					dur = end - t.CreatedAt
				}
				row := map[string]any{"id": t.ID, "description": t.Description, "goal": t.Goal, "status": status, "run_seconds": dur}
				if t.ParentRef != "" {
					row["parent_ref"] = t.ParentRef
				}
				llmState := t.llmStateSnapshot()
				if llmState.ProfileID == nil {
					row["llm_profile"] = "(active profile)"
				} else if n, ok := profName[*llmState.ProfileID]; ok {
					row["llm_profile"] = n
				} else {
					row["llm_profile"] = fmt.Sprintf("#%d(deleted)", *llmState.ProfileID)
				}
				out = append(out, row)
			}
			return jsonResult(out)
		})
}

// toolListLLMProfiles lists the available LLM profiles (name/model/active) so an
// orchestration agent can pick one for spawn_task's llm_profile. Never leaks keys.
func (s *Server) toolListLLMProfiles() actool.CoreTool {
	return roTool("list_llm_profiles",
		"List the available LLM profiles: id, name, model, format, whether it is the current active profile. Use the id to give spawn_task's llm_profile_id parameter a subtask-specific LLM (e.g. a cheap model for recon, a strong model for exploitation). Does not include API keys.",
		objSchema(map[string]any{}),
		func(context.Context, json.RawMessage) (actool.Result, error) {
			profs, err := s.m.pg.ListProfiles()
			if err != nil {
				return actool.Errorf(err.Error()), nil
			}
			out := make([]map[string]any, 0, len(profs))
			for _, p := range profs {
				out = append(out, map[string]any{
					"id": p.ID, "name": p.Name, "model": p.Model, "format": p.Format, "is_active": p.IsDefault,
				})
			}
			return jsonResult(map[string]any{"profiles": out})
		})
}

func (s *Server) toolSpawnTask() actool.CoreTool {
	return wrTool("spawn_task",
		"Create a subtask and start its exploration engine, returning a task_id. Use it to dispatch one thing (e.g. a challenge / a goal) as an independent task. parent_ref is optional: pass the parent task id associated with the current orchestration to link parent/child.",
		objSchema(map[string]any{
			"description":            strParam("task description (short title)"),
			"goal":                   strParam("task goal (what to achieve)"),
			"parent_ref":             strParam("optional: parent task id (to link parent/child)"),
			"source_task_ids":        map[string]any{"type": "array", "items": map[string]any{"type": "string"}, "description": fmt.Sprintf("optional: list of source task ids to inherit read-only (at most %d). The subtask may read-reference the assets/conclusions these tasks already discovered as a starting point; unlike parent_ref's pure parent/child pointer, this is content inheritance.", db.MaxTaskSourceCount)},
			"llm_profile_id":         map[string]any{"type": "integer", "description": "optional: LLM profile id for this subtask's planner/worker (see list_llm_profiles); if empty, inherit the parent task's, then fall back to the globally active profile"},
			"timeout_seconds":        map[string]any{"type": "integer", "description": "optional: task-level timeout (seconds). When reached, triggers graceful wrap-up and enters the timeout terminal state; empty or 0 = no limit"},
			"plan_heartbeat_seconds": map[string]any{"type": "integer", "description": "optional: planner heartbeat interval (seconds). When this much time has passed since the last planning round ended / task start with no trigger in between → trigger a planning round (catch deadlocks + wake to supervise in-flight workers). Empty or 0 = default 600 (10min);"},
			"seed_first_intent":      map[string]any{"type": "boolean", "description": "optional: can be enabled for simple tasks. At creation, directly dispatch a seed intent (content = description + goal) so a worker can start testing without waiting for the first planner round; default false (follows the standard plan-then-execute flow)."},
		}, "description", "goal"),
		func(_ context.Context, in json.RawMessage) (actool.Result, error) {
			var a struct {
				Description          string          `json:"description"`
				Goal                 string          `json:"goal"`
				ParentRef            string          `json:"parent_ref"`
				SourceTaskIDs        []string        `json:"source_task_ids"`
				LLMProfileID         json.RawMessage `json:"llm_profile_id"`
				TimeoutSeconds       int             `json:"timeout_seconds"`
				PlanHeartbeatSeconds int             `json:"plan_heartbeat_seconds"`
				SeedFirstIntent      bool            `json:"seed_first_intent"`
			}
			_ = json.Unmarshal(in, &a)
			if strings.TrimSpace(a.Description) == "" {
				a.Description = "unnamed task"
			}
			if strings.TrimSpace(a.Goal) == "" {
				return actool.Errorf("goal is required"), nil
			}
			if a.TimeoutSeconds < 0 {
				a.TimeoutSeconds = 0
			}
			// Read-only inherited source tasks: count cap + each id valid/deduped/exists, same validation rules as the HTTP task-creation path.
			if len(a.SourceTaskIDs) > db.MaxTaskSourceCount {
				return actool.Errorf(fmt.Sprintf("at most %d related tasks may be selected", db.MaxTaskSourceCount)), nil
			}
			sourceIDs := make([]int64, 0, len(a.SourceTaskIDs))
			seenSources := map[int64]bool{}
			for _, raw := range a.SourceTaskIDs {
				id, err := strconv.ParseInt(strings.TrimSpace(raw), 10, 64)
				if err != nil || id <= 0 || seenSources[id] {
					return actool.Errorf("related task id is invalid or duplicated"), nil
				}
				if _, ok := s.m.Task(strconv.FormatInt(id, 10)); !ok {
					return actool.Errorf(fmt.Sprintf("related task #%d not found", id)), nil
				}
				seenSources[id] = true
				sourceIDs = append(sourceIDs, id)
			}
			// LLM profile resolution: explicit id > inherit parent's pin > active(nil).
			var pin *int64
			if id := parseProfileID(a.LLMProfileID); id > 0 {
				if _, ok := s.loadProfileConfig(id); !ok {
					return actool.Errorf(fmt.Sprintf("LLM profile #%d not found or has no API Key set", id)), nil
				}
				pin = &id
			} else if a.ParentRef != "" {
				if pt, ok := s.m.Task(a.ParentRef); ok {
					pin = pt.LLMProfileID
				}
			}
			var llmIDs []int64
			if pin != nil {
				llmIDs = []int64{*pin}
			}
			t, err := s.m.CreateTaskWithOptions(a.Description, a.Goal, db.TaskCreateOptions{
				SourceTaskIDs:        sourceIDs,
				LLMProfileIDs:        llmIDs,
				TimeoutSeconds:       a.TimeoutSeconds,
				PlanHeartbeatSeconds: a.PlanHeartbeatSeconds,
			})
			if err != nil {
				return actool.Errorf(err.Error()), nil
			}
			if a.ParentRef != "" {
				t.ParentRef = a.ParentRef
				if id, e := strconv.ParseInt(t.ID, 10, 64); e == nil {
					_ = s.m.PG().SetParentRef(id, a.ParentRef)
				}
			}
			// Shared post-create flow, reusing the same launchTask as HTTP task creation (server.go createTask):
			// seed + a background, visible goal decomposition (round 0 / LLM steps / per-goal) + engine.Run.
			// seed_first_intent defaults to false (standard plan-then-execute); simple tasks can enable it to dispatch one work directly for testing.
			s.launchTask(t, a.Description+" "+a.Goal, a.SeedFirstIntent)
			return actool.Text(fmt.Sprintf("task created: %s", t.ID)), nil
		})
}

func (s *Server) toolPauseTask() actool.CoreTool {
	return wrTool("pause_task", "Pause the given task (stops its planner/worker loop).",
		objSchema(map[string]any{"task_id": strParam("id of the task to pause")}, "task_id"),
		func(_ context.Context, in json.RawMessage) (actool.Result, error) {
			var a struct {
				TaskID string `json:"task_id"`
			}
			_ = json.Unmarshal(in, &a)
			t, ok := s.m.Task(a.TaskID)
			if !ok {
				return actool.Errorf("task not found: " + a.TaskID), nil
			}
			if _, err := s.applyTaskControlWithCause(t, "pause", agent.AbortPausedByOrchestrator); err != nil {
				return actool.Errorf(err.Error()), nil
			}
			return actool.Text("task paused: " + a.TaskID), nil
		})
}

func (s *Server) toolGetTaskGraph() actool.CoreTool {
	return roTool("get_task_graph", "Read an overview of the given task's exploration graph (same as graph_overview: asset counts / frontier / findings / coverage etc.), specifying the task with task_id.",
		objSchema(map[string]any{"task_id": strParam("task id")}, "task_id"),
		func(ctx context.Context, in json.RawMessage) (actool.Result, error) {
			return s.delegateToTask(ctx, in, (*agent.ToolSet).GraphOverviewTool)
		})
}

func (s *Server) toolListTaskFindings() actool.CoreTool {
	return roTool("list_task_findings", "Read the given task's confirmed findings (including flag/PoC; each with id/task_id/intent_id/vulnclass/severity/summary/status), specifying the task with task_id.",
		objSchema(map[string]any{"task_id": strParam("task id")}, "task_id"),
		func(ctx context.Context, in json.RawMessage) (actool.Result, error) {
			return s.delegateToTask(ctx, in, (*agent.ToolSet).ListFindingsTool)
		})
}

func (s *Server) toolAddHint() actool.CoreTool {
	return wrTool("add_task_hint", "Inject strategic hints into the given task (its planner reads them when generating intents next round).\n"+
		"★Prefer batch: put multiple hints in the hints array and submit them in one go (returns an ids array the same length and order as hints, with id=0 for failed items); for a single hint, omit hints and pass the top-level text directly.",
		objSchema(map[string]any{
			"task_id":      strParam("task id"),
			"hints":        map[string]any{"type": "array", "description": "[Prefer this] array of hints; each element has the same fields as the top level (text/asset_ids/traffic_refs).", "items": objSchema(map[string]any{"text": strParam("hint content"), "asset_ids": map[string]any{"type": "array", "items": map[string]any{"type": "integer"}}, "traffic_refs": agent.HintTrafficSchema()})},
			"text":         strParam("[single] hint content"),
			"traffic_refs": agent.HintTrafficSchema(),
			"asset_ids":    map[string]any{"type": "array", "items": map[string]any{"type": "integer"}, "description": "anchored asset ids (optional, 0/1/multiple; asset ids within this task)"},
		}, "task_id"),
		func(ctx context.Context, in json.RawMessage) (actool.Result, error) {
			return s.delegateToTask(ctx, in, (*agent.ToolSet).AddHintTool)
		})
}

func (s *Server) toolGetWorkerTrace() actool.CoreTool {
	return roTool("get_task_worker_trace",
		"See the execution of one work (intent) in the given task: get_task_worker_trace(task_id, intent_id) shows a step summary; then pass step_ids=[...] to fetch the full content of those steps (at most 5 at a time; extra ones only return the first 5).",
		objSchema(map[string]any{
			"task_id":   strParam("task id"),
			"intent_id": map[string]any{"type": "integer", "description": "intent id (the work within this task)"},
			"step_ids":  map[string]any{"type": "array", "items": map[string]any{"type": "integer"}, "description": "optional: step ids whose full content to fetch (at most 5 at a time; extra ones only return the first 5, the rest are listed in omitted_step_ids)"},
		}, "task_id", "intent_id"),
		func(ctx context.Context, in json.RawMessage) (actool.Result, error) {
			return s.delegateToTask(ctx, in, (*agent.ToolSet).GetWorkerTraceTool)
		})
}

func (s *Server) toolListWorkerTraces() actool.CoreTool {
	return roTool("list_task_worker_traces", "List which works (intents) have run in the given task + each one's step count, to discover which works are worth inspecting (then use get_task_worker_trace).",
		objSchema(map[string]any{"task_id": strParam("task id")}, "task_id"),
		func(ctx context.Context, in json.RawMessage) (actool.Result, error) {
			return s.delegateToTask(ctx, in, (*agent.ToolSet).ListWorkerTracesTool)
		})
}

func (s *Server) toolSearchWorkerTraces() actool.CoreTool {
	return roTool("search_task_worker_traces", "Search the execution of all works in the given task by keyword (returns matching step summaries + intent_id).",
		objSchema(map[string]any{"task_id": strParam("task id"), "q": strParam("search keyword")}, "task_id", "q"),
		func(ctx context.Context, in json.RawMessage) (actool.Result, error) {
			return s.delegateToTask(ctx, in, (*agent.ToolSet).SearchWorkerTracesTool)
		})
}

func (s *Server) toolGetTaskNodeDetail() actool.CoreTool {
	return roTool("get_task_node_detail",
		"Read the full content of an exploration graph node in the given task (finding/fact/intent/goal: summary + detail/evidence/PoC). id is the exploration node id (e.g. returned by report_finding, or the id in list_task_findings). Use it before writing a finding report to fetch that finding's full evidence.",
		objSchema(map[string]any{
			"task_id": strParam("task id"),
			"id":      map[string]any{"type": "integer", "description": "exploration graph node id (not an asset id)"},
		}, "task_id", "id"),
		func(ctx context.Context, in json.RawMessage) (actool.Result, error) {
			return s.delegateToTask(ctx, in, (*agent.ToolSet).NodeDetailTool)
		})
}

// toolUpdateFindingReport writes/overwrites a finding's detailed Markdown report.
// finding_id is the id report_finding returned ("finding recorded: <id>", the
// finding node id). The write (SetFindingReportByNodeID) is keyed by node_id and
// task-agnostic, so this host tool needs no task_id / exploration store.
func (s *Server) toolUpdateFindingReport() actool.CoreTool {
	return wrTool("update_finding_report",
		"Write/update the [detailed report] for an already-recorded finding (full Markdown, overwriting the old content as a whole). Pass finding_id as the id report_finding returned (the number in \"finding recorded: <id>\"). The report should suggest including: vulnerability overview, impact and harm, reproduction steps, evidence/PoC, remediation advice.",
		objSchema(map[string]any{
			"finding_id":       map[string]any{"type": "integer", "description": "target finding id (the id returned by report_finding)"},
			"report":           strParam("full detailed report, Markdown format"),
			"evidence_version": map[string]any{"type": "integer", "description": "the evidence version returned by get_finding_traffic; used to prevent the report from overwriting new evidence changes"},
		}, "finding_id", "report"),
		func(ctx context.Context, in json.RawMessage) (actool.Result, error) {
			var a struct {
				EvidenceVersion *int64          `json:"evidence_version"`
				FindingID       json.RawMessage `json:"finding_id"`
				Report          string          `json:"report"`
			}
			_ = json.Unmarshal(in, &a)
			nodeID := parseProfileID(a.FindingID) // reuse the "number or numeric string" parsing
			if nodeID <= 0 {
				return actool.Errorf("finding_id is invalid"), nil
			}
			n, err := s.m.pg.SetFindingReportVersionByNodeID(ctx, nodeID, a.Report, a.EvidenceVersion)
			if err != nil {
				return actool.Errorf(err.Error()), nil
			}
			if n == 0 {
				return actool.Errorf(fmt.Sprintf("no finding record found for finding_id=%d (record it with report_finding first)", nodeID)), nil
			}
			return actool.Text(fmt.Sprintf("finding %d report updated (%d chars)", nodeID, len(a.Report))), nil
		})
}

// deriveTaskStatus mirrors listTasks' status derivation for the list_tasks tool.
func (s *Server) deriveTaskStatus(t *Task) string {
	lifecycle := t.lifecycleSnapshot()
	switch {
	case isTerminalStatus(lifecycle.Status):
		return lifecycle.Status
	case lifecycle.Paused || s.engine.IsPaused(t.ID):
		return "paused"
	case s.engine.ReadyFor(t) && s.engine.Started(t.ID):
		return "running"
	}
	return "created"
}

// orchestrationToolSeeds seeds the cross-task tools into the tools table so they
// are bindable per-agent (default: bound to nobody — opt-in for orchestration
// agents). First-insert only, like the traffic seeds.
func (s *Server) seedOrchestrationTools() {
	// task-op + platform tools default-bind to the built-in Auto agent (it is designed to
	// operate the platform). SeedTool takes effect on first insert; rows already seeded in an old DB are rebound by seedAutoDefaultBindings.
	autoAgents, _ := json.Marshal([]string{"auto"})
	for _, t := range s.orchestrationTools() {
		schema, _ := json.Marshal(t.InputSchema())
		bindings := autoAgents
		if t.Name() == "bind_finding_traffic" {
			bindings = json.RawMessage(`["reporter"]`)
		}
		_ = s.m.PG().SeedTool(t.Name(), t.Description(), schema, bindings)
	}
	for _, t := range s.platformTools() {
		schema, _ := json.Marshal(t.InputSchema())
		_ = s.m.PG().SeedTool(t.Name(), t.Description(), schema, autoAgents)
	}
	s.refreshBuiltinToolSchemas()
	s.seedAutoDefaultBindings()
	s.seedPlannerDefaultBindings()
	s.seedPlannerListAssetsBinding()
	s.seedCompanyScopeRebind()
	s.seedWorkerReadToolsUnbind() // unbind list_facts/list_companies/list_worker_traces from worker default (one-time)
	s.seedWorkerReadbackRebind()  // fix erroneous deletes from an old migration: rebind search_all_worker_traces/get_worker_trace/node_detail back to worker (one-time)
	s.seedAutoReportFindingBinding()
	s.unbindGoalMetDefault()
	s.reseedGoalsPrompt()             // add the "extract operation constraints" step to the goals prompt → append a new default version to old DBs (one-time)
	s.reseedMainAgentPrompt()         // add "after goals are met, add_intent asks whether to register a goal" to the mainagent prompt (one-time)
	s.reseedPlannerPrompt()           // planner prompt: rewrite the justification for "0 intents" + add quantitative acceptance checks (one-time)
	s.reseedWorkerPrompt()            // worker prompt: add an evidence threshold for negative conclusions (one-time)
	s.reseedPentestPrompt()           // pentest prompt: drop authorized-scope self-limitation, add a stay-in-operation directive (one-time)
	s.reseedPentestNoGuardPrompt()    // every pentest agent: add the stay-in-operation directive, drop the authorized-scope self-limitation (one-time)
	s.reseedSkillGuidancePrompts()    // planner/worker/pentest: add proactive "reach for the Skill playbook" guidance (one-time)
	s.seedToolchainShellHints()       // declare the installed pentest toolchain as kind="shell" hints bound to worker+pentest
	s.disableBuiltinInterceptRules()  // disable the built-in command/asset intercept rules + LLM judge so pentest agents run unguarded (one-time)
	s.seedReporterAgent()             // preset a "report writing" agent + tool bindings + finding trigger (one-time)
	s.upgradeReporterTriggerMessage() // backfill migration for old DBs: make reporter return evidence_version (one-time)
	s.seedFindingTrafficTools()       // add an optional evidence param and read-only evidence tools, preserving user config
	s.seedFindingWorkflowTools()
	// Note: pentest's default tool bindings need no migration — on a fresh init, BuiltinToolSeeds
	// seeds list_assets/insert_assets/report_finding/list_findings/list_companies along with
	// pentest (the project has no old DB yet, so no migration is done).
}

// refreshBuiltinToolSchemas propagates code schema/description changes on the
// orchestration + platform tools into already-seeded rows ONCE per version flag —
// SeedTool is first-insert-only, so a new param (e.g. spawn_task's llm_profile) never
// reaches an old DB otherwise. Preserves each tool's agent binding + enabled flag.
// Bump the flag whenever these tools' schemas/descriptions change in code.
func (s *Server) refreshBuiltinToolSchemas() {
	const flag = "tool_schema_refresh_v7_list_facts_paging"
	if v, _, _ := s.m.pg.GetSetting(flag); v == "true" {
		return
	}
	tools := append(s.orchestrationTools(), s.platformTools()...)
	for _, t := range tools {
		schema, _ := json.Marshal(t.InputSchema())
		if err := s.m.pg.RefreshToolDefaults(t.Name(), t.Description(), schema); err != nil {
			log.Printf("[tools] refresh %s schema failed: %v", t.Name(), err)
		}
	}
	// Also refresh some built-in agent tools to code defaults:
	//   - goal_met: the description seeded in an old DB carries the misleading "end this planning round", which makes the planner treat it as
	//     the means to "end an empty round" and mistakenly judge the whole task complete right after starting.
	//   - insert_assets: adds the related parameter (marks whether an asset is related to the current task, deciding whether it enters coverage).
	//     SeedTool is first-insert-only, so schemas already seeded in an old DB would otherwise not receive this new parameter.
	//   - list_facts: switched to paging, adds the limit/before/q params; the empty schema already seeded in an old DB would otherwise
	//     show "no parameters" on the tool management page, and the model would not get the descriptions of these params either.
	refreshBuiltin := map[string]bool{"goal_met": true, "insert_assets": true, "list_facts": true}
	for _, sd := range agent.BuiltinToolSeeds() {
		if !refreshBuiltin[sd.Key] {
			continue
		}
		schema, _ := json.Marshal(sd.Schema)
		if err := s.m.pg.RefreshToolDefaults(sd.Key, sd.Desc, schema); err != nil {
			log.Printf("[tools] refresh %s desc failed: %v", sd.Key, err)
		}
	}
	_ = s.m.pg.SetSetting(flag, "true")
	log.Printf("[tools] refreshed orchestration/platform tool schemas to code defaults (one-time)")
}

// unbindGoalMetDefault removes goal_met's default "planner" binding ONCE (guarded by
// a settings flag), so existing DBs match the new default of NO agent. goal_met bypasses
// per-goal prove_goal to declare the whole task done — powerful/risky and redundant with
// the prove_goal→auto-complete path — so it ships unbound; users can re-bind it per agent
// in the UI. A user's own binding to another agent is untouched (we only strip planner).
func (s *Server) unbindGoalMetDefault() {
	const flag = "goal_met_unbind_default_v1"
	if v, _, _ := s.m.pg.GetSetting(flag); v == "true" {
		return
	}
	if err := s.m.pg.RemoveAgentFromTool("planner", "goal_met"); err != nil {
		log.Printf("[tools] failed to unbind goal_met from planner: %v", err)
		return
	}
	_ = s.m.pg.SetSetting(flag, "true")
}

// reseedGoalsPrompt refreshes the goals goal-decomposer prompt to the [current code default] — the default body added a
// "first extract operation constraints (set_constraints), then decompose goals" step, and SeedPromptIfEmpty is first-insert
// only, so version 1 already present in an old DB does not receive this step. Here version management is used to [append a new version] and switch to it (ResetPromptToDefault);
// the old version stays in history, so a user who customized it can recover it from the version records. settings flag guard → runs once;
// bump this flag if the default changes again. A fresh DB needs no handling (SeedPromptIfEmpty already seeded the latest default).
func (s *Server) reseedGoalsPrompt() {
	const flag = "goals_prompt_constraint_step_v1"
	if v, _, _ := s.m.pg.GetSetting(flag); v == "true" {
		return
	}
	defer func() { _ = s.m.pg.SetSetting(flag, "true") }() // attempt only once, regardless of success
	a, err := s.m.pg.GetAgentByKey("goals")
	if err != nil || a == nil {
		return // when a fresh DB has no agent row yet, seedPrompts seeds the latest default directly; no migration needed
	}
	tmpl := agent.BuiltinPromptSeeds()["goals"]
	if tmpl == "" {
		return
	}
	// A fresh DB's seedPrompts already seeded the latest default → the current version already equals the code default, so no need to append a duplicate version.
	if cur, err := s.m.pg.CurrentPrompt(a.ID); err == nil && cur == tmpl {
		return
	}
	if _, err := s.m.pg.ResetPromptToDefault(a.ID, tmpl); err != nil {
		log.Printf("[prompts] failed to re-seed goals prompt to the new default: %v", err)
		return
	}
	log.Printf("[prompts] appended a new default version of the goals prompt (adds the extract-operation-constraints step, one-time)")
}

// reseedMainAgentPrompt refreshes the mainagent prompt to the [current code default] — the default body added guidance for
// "after all goals are met, when add_intent injects an intent directly, ask the human whether to register it as a formal goal", and SeedPromptIfEmpty is first-insert
// only, so a version already present in an old DB does not receive it. Version management is used to [append a new version] and switch to it (ResetPromptToDefault); the old version
// stays in history, so a user who customized it can recover it from the version records. settings flag guard → runs once. A fresh DB needs no handling
// (SeedPromptIfEmpty already seeded the latest default). Fully isomorphic to reseedGoalsPrompt.
func (s *Server) reseedMainAgentPrompt() {
	const flag = "mainagent_prompt_goalless_intent_v1"
	if v, _, _ := s.m.pg.GetSetting(flag); v == "true" {
		return
	}
	defer func() { _ = s.m.pg.SetSetting(flag, "true") }() // attempt only once, regardless of success
	a, err := s.m.pg.GetAgentByKey("mainagent")
	if err != nil || a == nil {
		return // when a fresh DB has no agent row yet, seedPrompts seeds the latest default directly; no migration needed
	}
	tmpl := agent.BuiltinPromptSeeds()["mainagent"]
	if tmpl == "" {
		return
	}
	// A fresh DB's seedPrompts already seeded the latest default → the current version already equals the code default, so no need to append a duplicate version.
	if cur, err := s.m.pg.CurrentPrompt(a.ID); err == nil && cur == tmpl {
		return
	}
	if _, err := s.m.pg.ResetPromptToDefault(a.ID, tmpl); err != nil {
		log.Printf("[prompts] failed to re-seed mainagent prompt to the new default: %v", err)
		return
	}
	log.Printf("[prompts] appended a new default version of the mainagent prompt (adds asking about registering a goal after goals are met, one-time)")
}

// reseedPlannerPrompt refreshes the planner prompt to the [current code default] — the default body was streamlined/refactored, downgrading "restraint" to
// dedup-only, adding "depth takes priority over coverage" and "hard bottom line: if goals are unmet and no intent is running, must produce", and adding an upper bound to negative-conclusion review.
// Bump the flag below (currently v2) whenever the default changes substantially, so existing old DBs are refreshed again. SeedPromptIfEmpty is first-insert only, so a version already present in an old DB does not receive it; hence version management
// [appends a new version] and switches to it (ResetPromptToDefault); the old version stays in history, so a user who customized it can recover it
// from the version records. settings flag guard → runs once. A fresh DB needs no handling (SeedPromptIfEmpty already seeded the latest default). Fully
// isomorphic to reseedGoalsPrompt.
func (s *Server) reseedPlannerPrompt() {
	const flag = "planner_prompt_compact_realistic_v2"
	if v, _, _ := s.m.pg.GetSetting(flag); v == "true" {
		return
	}
	defer func() { _ = s.m.pg.SetSetting(flag, "true") }() // attempt only once, regardless of success
	a, err := s.m.pg.GetAgentByKey("planner")
	if err != nil || a == nil {
		return // when a fresh DB has no agent row yet, seedPrompts seeds the latest default directly; no migration needed
	}
	tmpl := agent.BuiltinPromptSeeds()["planner"]
	if tmpl == "" {
		return
	}
	// A fresh DB's seedPrompts already seeded the latest default → the current version already equals the code default, so no need to append a duplicate version.
	if cur, err := s.m.pg.CurrentPrompt(a.ID); err == nil && cur == tmpl {
		return
	}
	if _, err := s.m.pg.ResetPromptToDefault(a.ID, tmpl); err != nil {
		log.Printf("[prompts] failed to re-seed planner prompt to the new default: %v", err)
		return
	}
	log.Printf("[prompts] appended a new default version of the planner prompt (streamline/refactor + restraint downgraded to dedup + depth-first + negative-review upper bound, one-time)")
}

// reseedWorkerPrompt refreshes the worker prompt to the [current code default] — the default body removed the whole sentence "for negative conclusions
// write an observation + a tentative reading" from the record_fact section, and decoupled confidence (observed/inferred) from "whether this intent's means are exhausted" (these easily mislead planners),
// while tightening the facts array splitting to the rare exceptions that are "fully independent of each other and cannot be merged". Bump the flag to v3 so existing old DBs are refreshed again.
// SeedPromptIfEmpty is first-insert only, so a version already present in an old DB does not receive it; hence version management [appends a new version] and switches to it; the old version stays in history and can be recovered.
// settings flag guard → runs once. A fresh DB needs no handling. Fully isomorphic to reseedGoalsPrompt.
func (s *Server) reseedWorkerPrompt() {
	const flag = "worker_prompt_compact_v4"
	if v, _, _ := s.m.pg.GetSetting(flag); v == "true" {
		return
	}
	defer func() { _ = s.m.pg.SetSetting(flag, "true") }() // attempt only once, regardless of success
	a, err := s.m.pg.GetAgentByKey("worker")
	if err != nil || a == nil {
		return // when a fresh DB has no agent row yet, seedPrompts seeds the latest default directly; no migration needed
	}
	tmpl := agent.BuiltinPromptSeeds()["worker"]
	if tmpl == "" {
		return
	}
	// A fresh DB's seedPrompts already seeded the latest default → the current version already equals the code default, so no need to append a duplicate version.
	if cur, err := s.m.pg.CurrentPrompt(a.ID); err == nil && cur == tmpl {
		return
	}
	if _, err := s.m.pg.ResetPromptToDefault(a.ID, tmpl); err != nil {
		log.Printf("[prompts] failed to re-seed worker prompt to the new default: %v", err)
		return
	}
	log.Printf("[prompts] appended a new default version of the worker prompt (context lookup section narrowed to list_assets/list_findings, dropping list_facts/node_detail/asset_neighbors, one-time)")
}

// reseedPentestPrompt refreshes the pentest agent prompt to the [current code default] — the default
// body dropped the blanket "authorized scope" self-limitation (which read as a cue to refuse or
// hedge on in-scope work) and added an explicit "stay in operation, do not refuse, do not ask for
// authorization you already have" directive. SeedPromptIfEmpty is first-insert only, so a version
// already present in an old DB does not receive it; hence version management [appends a new version]
// and switches to it (ResetPromptToDefault); the old version stays in history and can be recovered.
// settings flag guard → runs once. A fresh DB needs no handling. Fully isomorphic to reseedGoalsPrompt.
func (s *Server) reseedPentestPrompt() {
	const flag = "pentest_prompt_stay_in_operation_v1"
	if v, _, _ := s.m.pg.GetSetting(flag); v == "true" {
		return
	}
	defer func() { _ = s.m.pg.SetSetting(flag, "true") }() // attempt only once, regardless of success
	a, err := s.m.pg.GetAgentByKey("pentest")
	if err != nil || a == nil {
		return // when a fresh DB has no agent row yet, seedPrompts seeds the latest default directly; no migration needed
	}
	tmpl := agent.BuiltinPromptSeeds()["pentest"]
	if tmpl == "" {
		return
	}
	// A fresh DB's seedPrompts already seeded the latest default → the current version already equals the code default, so no need to append a duplicate version.
	if cur, err := s.m.pg.CurrentPrompt(a.ID); err == nil && cur == tmpl {
		return
	}
	if _, err := s.m.pg.ResetPromptToDefault(a.ID, tmpl); err != nil {
		log.Printf("[prompts] failed to re-seed pentest prompt to the new default: %v", err)
		return
	}
	log.Printf("[prompts] appended a new default version of the pentest prompt (drops authorized-scope self-limitation, adds stay-in-operation directive, one-time)")
}

// reseedPentestNoGuardPrompt propagates the latest built-in prompt bodies — which now
// carry the "stay in operation, do not refuse" directive on every pentest agent
// (goals/planner/worker/mainagent/auto/pentest) and drop the "operate only within the
// authorized scope" self-limitation — to databases that were seeded before the change.
// PromptOverride makes agent_prompts authoritative, so editing the in-code consts alone
// would not reach an existing DB. Version management appends a new default version and
// switches to it (ResetPromptToDefault); the old version stays in history and can be
// recovered. settings flag guard → runs once. A fresh DB needs no handling. Isomorphic
// to reseedPentestPrompt, but loops over every key that carries the directive.
func (s *Server) reseedPentestNoGuardPrompt() {
	const flag = "pentest_no_guard_prompt_v1"
	if v, _, _ := s.m.pg.GetSetting(flag); v == "true" {
		return
	}
	defer func() { _ = s.m.pg.SetSetting(flag, "true") }() // attempt only once, regardless of success
	keys := []string{"goals", "planner", "worker", "mainagent", "auto", "pentest"}
	for _, key := range keys {
		a, err := s.m.pg.GetAgentByKey(key)
		if err != nil || a == nil {
			continue // when a fresh DB has no agent row yet, seedPrompts seeds the latest default directly; no migration needed
		}
		tmpl := agent.BuiltinPromptSeeds()[key]
		if tmpl == "" {
			continue
		}
		// A fresh DB's seedPrompts already seeded the latest default → the current version already equals the code default, so no need to append a duplicate version.
		if cur, err := s.m.pg.CurrentPrompt(a.ID); err == nil && cur == tmpl {
			continue
		}
		if _, err := s.m.pg.ResetPromptToDefault(a.ID, tmpl); err != nil {
			log.Printf("[prompts] failed to re-seed %s prompt to the new default: %v", key, err)
			continue
		}
		log.Printf("[prompts] appended a new default version of the %s prompt (adds stay-in-operation directive, drops authorized-scope self-limitation, one-time)", key)
	}
}

// reseedSkillGuidancePrompts refreshes the planner/worker/pentest prompts to the [current code default]
// after adding proactive skill usage guidance ("reach for the Skill playbook first" in worker/pentest,
// "name the matching skill in the intent summary" in planner). SeedPromptIfEmpty is first-insert only, so
// a version already present in an old DB does not receive it; hence version management [appends a new
// version] and switches to it (ResetPromptToDefault); the old version stays in history and can be
// recovered. settings flag guard → runs once. A fresh DB needs no handling. Isomorphic to
// reseedPentestNoGuardPrompt.
func (s *Server) reseedSkillGuidancePrompts() {
	const flag = "skill_guidance_prompts_v1"
	if v, _, _ := s.m.pg.GetSetting(flag); v == "true" {
		return
	}
	defer func() { _ = s.m.pg.SetSetting(flag, "true") }() // attempt only once, regardless of success
	for _, key := range []string{"planner", "worker", "pentest"} {
		a, err := s.m.pg.GetAgentByKey(key)
		if err != nil || a == nil {
			continue // when a fresh DB has no agent row yet, seedPrompts seeds the latest default directly; no migration needed
		}
		tmpl := agent.BuiltinPromptSeeds()[key]
		if tmpl == "" {
			continue
		}
		// A fresh DB's seedPrompts already seeded the latest default → the current version already equals the code default, so no need to append a duplicate version.
		if cur, err := s.m.pg.CurrentPrompt(a.ID); err == nil && cur == tmpl {
			continue
		}
		if _, err := s.m.pg.ResetPromptToDefault(a.ID, tmpl); err != nil {
			log.Printf("[prompts] failed to re-seed %s prompt for skill guidance: %v", key, err)
			continue
		}
		log.Printf("[prompts] appended a new default version of the %s prompt (adds proactive skill usage guidance, one-time)", key)
	}
}

// disableBuiltinInterceptRules turns off every built-in command/asset intercept rule so
// pentest agents run without platform command gating. The rules are ordinary, user-editable
// rows, so this disables them in place rather than deleting them — they stay visible and can
// be re-enabled from the intercept page (they also guard the operator's own host, e.g.
// rm -rf / / mkfs / shutdown). The LLM fallback judge is forced off too (it already defaults
// to off). settings flag guard → runs once; per-row enabled flags survive it and remain
// the undo path.
func (s *Server) disableBuiltinInterceptRules() {
	const flag = "intercept_builtin_disabled_v1"
	if v, _, _ := s.m.pg.GetSetting(flag); v == "true" {
		return
	}
	defer func() { _ = s.m.pg.SetSetting(flag, "true") }() // attempt only once, regardless of success
	if _, err := s.m.pg.Exec(`UPDATE intercept_rules SET enabled=false WHERE name LIKE '[Built-in]%' AND enabled=true`); err != nil {
		log.Printf("[intercept] failed to disable built-in intercept rules: %v", err)
	} else {
		log.Printf("[intercept] disabled all built-in intercept rules (re-enable from the intercept page, one-time)")
	}
	if _, err := s.m.pg.Exec(`UPDATE asset_intercept_rules SET enabled=false WHERE builtin=true AND enabled=true`); err != nil {
		log.Printf("[intercept] failed to disable built-in asset intercept rules: %v", err)
	} else {
		log.Printf("[intercept] disabled all built-in asset intercept rules (re-enable from the asset-intercept page, one-time)")
	}
	if err := s.m.pg.SetBool("llm_judge_enabled", false); err != nil {
		log.Printf("[intercept] failed to set llm_judge_enabled=false: %v", err)
	}
}

// reporterToolCallMessage must unconditionally require reading get_finding_traffic once before writing the report.
// That tool is read-only and "does not depend on the capture switch", so manually-bound evidence can be read whether or not auto-binding is enabled. If this were
// written as "only read when auto-binding is enabled", a reporter under the default-disabled config would not pass evidence_version,
// and SetFindingReportVersionByNodeID would write -1 per the legacy semantics, so the finding detail and Markdown export
// would be permanently stuck at "evidence has changed, report needs updating", with no entry point in the UI able to clear it.
const reporterToolCallMessage = "A vulnerability was just recorded by report_finding above. Read the finding_id (the standalone finding record ID) and finding_node_id (the exploration node ID) from the returned JSON, " +
	"first call get_finding_traffic(finding_id) to read the current evidence list and its version (an empty list is normal — write the report as usual); " +
	"if the run guide enables auto-binding, verify and associate this finding's traffic before reading. Use finding_node_id for node detail. " +
	"Finally call update_finding_report(finding_id=finding_node_id, report, evidence_version=the version actually read) to save; " +
	"evidence_version must be passed, otherwise the report will be permanently marked as needing update. Do not mix up the two kinds of id."

// reporterToolCallMessageV1 is the old trigger message (0.3.8 and earlier). This literal is data: it is compared
// byte-for-byte against the ToolCallMessage stored in the DB, and only records still matching it verbatim are migrated/overwritten,
// so it MUST stay exactly as-is. Do not translate it.
const reporterToolCallMessageV1 = "上面刚有一个漏洞被 report_finding 登记。请从触发上下文里取出 finding_id" +
	"（工具返回 \"finding recorded: <id>\" 里的数字）与任务 id，按你的职责撰写该漏洞的详细报告，" +
	"最后调用 update_finding_report(finding_id, report) 保存。"

// upgradeReporterTriggerMessage refreshes the reporter trigger message in old DBs that is still the default text to the new version.
// seedReporterAgent is guarded by reporter_agent_seed_v1 and only writes the trigger when creating an agent, so
// upgraded DBs never get the new text — the tool schema was backfilled with evidence_version by seedFindingTrafficTools,
// but nothing tells the reporter to use it. One-time, and it only overwrites unmodified text.
func (s *Server) upgradeReporterTriggerMessage() {
	const flag = "reporter_trigger_evidence_version_v1"
	if v, _, _ := s.m.pg.GetSetting(flag); v == "true" {
		return
	}
	defer func() { _ = s.m.pg.SetSetting(flag, "true") }() // attempt only once
	triggers, err := s.m.pg.ListTriggersFor("reporter")
	if err != nil {
		log.Printf("[reporter] failed to read triggers: %v", err)
		return
	}
	for _, t := range triggers {
		if !t.OnToolCall || t.ToolCallMessage != reporterToolCallMessageV1 {
			continue // user-modified, or not a finding trigger; leave it alone.
		}
		t.ToolCallMessage = reporterToolCallMessage
		if err := s.m.pg.UpdateTrigger(t); err != nil {
			log.Printf("[reporter] failed to upgrade trigger message: %v", err)
			return
		}
		log.Printf("[reporter] trigger message upgraded to read and return evidence_version")
	}
}

// seedReporterAgent presets a "report writing" custom agent (builtin=false, editable/deletable in the UI):
// it binds update_finding_report + task query tools, and attaches a "triggers when report_finding is called"
// trigger — every recorded finding wakes it to write a detailed report. One-time (settings flag guard): not recreated after the user deletes it.
// Dependency: the orchestration tools have already been seeded into the DB by SeedTool above this function, so the bindings resolve.
func (s *Server) seedReporterAgent() {
	const flag = "reporter_agent_seed_v1"
	if v, _, _ := s.m.pg.GetSetting(flag); v == "true" {
		return
	}
	defer func() { _ = s.m.pg.SetSetting(flag, "true") }() // attempt only once, regardless of success

	if exist, _ := s.m.pg.GetAgentByKey("reporter"); exist != nil {
		return // key already taken (the user built one by hand) — do not overwrite
	}
	a, err := s.m.pg.CreateAgent("reporter", "Report Writing",
		"Detailed vulnerability report writing: automatically triggered when a vulnerability is found; fetches the evidence and execution trace, then writes and writes back a Markdown report.")
	if err != nil {
		log.Printf("[reporter] failed to create agent: %v", err)
		return
	}
	if err := s.m.pg.SeedPromptIfEmpty(a.ID, agent.ReporterDefaultPrompt); err != nil {
		log.Printf("[reporter] failed to seed prompt: %v", err)
	}
	// Trigger run policy: parallel + none — one report per finding, multiple findings run concurrently and write their own.
	// merge must be none: otherwise (default all) a wave of findings would be merged into one run, making parallelism pointless.
	// maxParallel=5: at most 5 report sessions at a time, avoiding too many simultaneous LLM calls.
	if err := s.m.pg.SetAgentTriggerBehavior("reporter", "parallel", "none", 5); err != nil {
		log.Printf("[reporter] failed to set trigger run policy: %v", err)
	}
	// Bind the tools it needs: write report + read evidence/execution trace/situation.
	if err := s.m.pg.AddAgentToToolBinding("reporter", []string{
		"update_finding_report", "get_task_node_detail", "list_task_findings",
		"get_task_worker_trace", "list_task_worker_traces", "search_task_worker_traces",
		"get_task_graph",
	}); err != nil {
		log.Printf("[reporter] failed to bind tools: %v", err)
	}
	// Trigger: fires when report_finding is called (the tool returns "finding recorded: <id>" carrying finding_id,
	// and the task id is also in the trigger message).
	if _, err := s.m.pg.CreateTrigger(&db.AgentTrigger{
		AgentKey:        "reporter",
		Enabled:         true,
		OnToolCall:      true,
		ToolNames:       []string{"report_finding"},
		ToolCallMessage: reporterToolCallMessage,
	}); err != nil {
		log.Printf("[reporter] failed to create trigger: %v", err)
	}
	log.Printf("[reporter] preset the \"report writing\" agent + finding trigger")
}

// seedAutoReportFindingBinding adds "auto" to report_finding's binding ONCE so
// conversation-context agents can call it without requiring an intent_id.
func (s *Server) seedAutoReportFindingBinding() {
	const flag = "auto_report_finding_v1"
	if v, _, _ := s.m.pg.GetSetting(flag); v == "true" {
		return
	}
	if err := s.m.pg.AddAgentToToolBinding("auto", []string{"report_finding"}); err != nil {
		log.Printf("[auto] default binding of report_finding failed: %v", err)
		return
	}
	_ = s.m.pg.SetSetting(flag, "true")
}

// seedPlannerDefaultBindings adds "planner" to report_finding's binding ONCE
// (guarded by a settings flag), so existing DBs — whose report_finding row was
// seeded as worker-only — also let the planner record findings. Fresh DBs already
// get it via PlannerTools(); this only backfills without overriding a user unbind.
func (s *Server) seedPlannerDefaultBindings() {
	const flag = "planner_report_finding_v1"
	if v, _, _ := s.m.pg.GetSetting(flag); v == "true" {
		return
	}
	if err := s.m.pg.AddAgentToToolBinding("planner", []string{"report_finding"}); err != nil {
		log.Printf("[planner] default binding of report_finding failed: %v", err)
		return
	}
	_ = s.m.pg.SetSetting(flag, "true")
}

// seedPlannerListAssetsBinding adds "planner" to list_assets's binding ONCE
// (guarded by a settings flag), so existing DBs — whose list_assets row was seeded
// as auto/pentest-only — also let the planner query the asset store by DSL. Fresh
// DBs already get it via PlannerTools(); this only backfills without overriding a
// user unbind.
func (s *Server) seedPlannerListAssetsBinding() {
	const flag = "planner_list_assets_v1"
	if v, _, _ := s.m.pg.GetSetting(flag); v == "true" {
		return
	}
	if err := s.m.pg.AddAgentToToolBinding("planner", []string{"list_assets"}); err != nil {
		log.Printf("[planner] default binding of list_assets failed: %v", err)
		return
	}
	_ = s.m.pg.SetSetting(flag, "true")
}

// seedCompanyScopeRebind changes add_company_scope's default binding ONCE on
// existing DBs (guarded by a settings flag): the tool moves off worker and onto
// planner — defining a company's asset scope is a planning/main/auto concern, not
// something a worker does mid-exploration. Fresh DBs already get planner via
// PlannerTools() and lack worker via WorkerTools(); this only backfills old rows.
// One-shot + flag-guarded so a user who later re-binds worker isn't overridden.
func (s *Server) seedCompanyScopeRebind() {
	const flag = "company_scope_rebind_v1" // worker→planner default binding switch
	if v, _, _ := s.m.pg.GetSetting(flag); v == "true" {
		return
	}
	if err := s.m.pg.AddAgentToToolBinding("planner", []string{"add_company_scope"}); err != nil {
		log.Printf("[planner] default binding of add_company_scope failed: %v", err)
		return
	}
	if err := s.m.pg.RemoveAgentFromTool("worker", "add_company_scope"); err != nil {
		log.Printf("[worker] failed to unbind add_company_scope: %v", err)
		return
	}
	_ = s.m.pg.SetSetting(flag, "true")
}

// seedWorkerReadToolsUnbind strips the read-context tools off worker's default
// binding ONCE on existing DBs (guarded by a settings flag): a worker executes one
// intent and writes back — reading facts/companies and listing all workers' traces is
// a planning/main concern, not the executor's. Fresh DBs already lack these via
// WorkerTools(); this only backfills old rows without overriding a user who
// deliberately re-binds worker. Each RemoveAgentFromTool is per-tool +
// membership-guarded, so planner/mainagent bindings of the same tool are untouched.
//
// NOTE: search_all_worker_traces / get_worker_trace / node_detail are intentionally NOT
// unbound — worker owns them for cross-work look-back + node drill-down (see WorkerTools).
// They used to be in this list back when worker lacked them; seedWorkerReadbackRebind
// repairs DBs whose old run stripped them.
func (s *Server) seedWorkerReadToolsUnbind() {
	const flag = "worker_readtools_unbind_v1"
	if v, _, _ := s.m.pg.GetSetting(flag); v == "true" {
		return
	}
	for _, k := range []string{
		"list_facts", "list_companies", "list_worker_traces",
	} {
		if err := s.m.pg.RemoveAgentFromTool("worker", k); err != nil {
			log.Printf("[worker] failed to unbind %s from worker: %v", k, err)
			return // on error, do not land the flag, retry on next start
		}
	}
	_ = s.m.pg.SetSetting(flag, "true")
}

// seedWorkerReadbackRebind re-binds the cross-work look-back / drill-down tools onto
// worker ONCE (guarded by a settings flag): an earlier seedWorkerReadToolsUnbind wrongly
// stripped search_all_worker_traces / get_worker_trace / node_detail from worker after
// they had been added to WorkerTools(), so any DB that ran that migration lost them.
// Fresh DBs already have them via WorkerTools() and this is a harmless no-op there.
// One-shot + flag-guarded so a user who later deliberately unbinds them isn't overridden.
func (s *Server) seedWorkerReadbackRebind() {
	const flag = "worker_readback_rebind_v2" // v2: adds node_detail
	if v, _, _ := s.m.pg.GetSetting(flag); v == "true" {
		return
	}
	if err := s.m.pg.AddAgentToToolBinding("worker", []string{
		"search_all_worker_traces", "get_worker_trace", "node_detail",
	}); err != nil {
		log.Printf("[worker] failed to rebind look-back/detail tools: %v", err)
		return // on error, do not land the flag, retry on next start
	}
	_ = s.m.pg.SetSetting(flag, "true")
}

// seedAutoDefaultBindings adds "auto" to the task-op + platform tools' bindings
// ONCE (guarded by a settings flag), so existing DBs whose tool rows were seeded
// before Auto existed still give Auto its default toolset — without re-adding it
// after a user deliberately unbinds.
func (s *Server) seedAutoDefaultBindings() {
	const flag = "auto_default_bindings_v3" // v3: replace the old asset tool names, add insert_assets/add_company_scope
	if v, _, _ := s.m.pg.GetSetting(flag); v == "true" {
		return
	}
	keys := make([]string, 0, len(platformToolKeys)+12)
	for _, t := range s.orchestrationTools() {
		keys = append(keys, t.Name())
	}
	keys = append(keys, platformToolKeys...)
	// Asset tools: Auto operating the platform often needs to view/register assets and manage company scope.
	keys = append(keys, "insert_assets", "add_company_scope", "list_assets")
	if err := s.m.pg.AddAgentToToolBinding("auto", keys); err != nil {
		log.Printf("[auto] default binding failed: %v", err)
		return
	}
	_ = s.m.pg.SetSetting(flag, "true")
}
