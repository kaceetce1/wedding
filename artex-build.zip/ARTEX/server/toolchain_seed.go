package server

import "log"

// toolchainShellHints declares the pentest toolchain that ships in the container image
// (see Dockerfile.local + the pentest-toolbox skill) as kind="shell" tools. A shell row
// is NOT a callable tool — agent assembly (server/assembly.go) collects the rows bound to
// an agent and appends "- key: description" bullets to that agent's Bash description, so
// the model knows these binaries exist and can call them directly. This complements the
// pentest-toolbox skill: the hints say *what is installed*, the skill says *how to chain it*.
//
// Seeded with INSERT ... ON CONFLICT DO NOTHING, so it runs on every startup (idempotent)
// and a user's later edit/disable of a hint is never overwritten.
var toolchainShellHints = []struct {
	Key  string
	Desc string
}{
	// Subdomain / DNS
	{"subfinder", "Passive subdomain enumeration from public sources (e.g. `subfinder -d example.com -silent`)."},
	{"amass", "Deeper, slower subdomain/asset discovery across multiple modes (`amass enum -d example.com`)."},
	{"dnsx", "Bulk DNS resolution / record probing; pairs with subfinder (`subfinder -d x -silent | dnsx -a -resp`)."},
	{"dnsrecon", "DNS record enumeration and zone-transfer checks."},
	{"dnsenum", "DNS enumeration: records, zone transfers, brute-forced names."},
	{"dig", "Single DNS lookups (A/TXT/MX/NS) and zone-transfer attempts (`dig axfr @ns zone`)."},
	{"nslookup", "Quick DNS lookups for a single host."},

	// Probing / HTTP / TLS
	{"httpx", "Batch-probe hosts for live HTTP(S), titles, tech and status (`httpx -l hosts.txt -title -tech-detect -status-code`)."},
	{"tlsx", "TLS certificate grabbing: SANs, expiry, JARM fingerprint."},
	{"whatweb", "Web technology fingerprinting (`whatweb -a 3 https://target`)."},
	{"wafw00f", "Detect which WAF fronts a target (`wafw00f https://target`)."},
	{"sslscan", "TLS/SSL cipher-suite and protocol audit."},
	{"testssl.sh", "Comprehensive TLS configuration audit (protocols, ciphers, vulns)."},
	{"curl", "Ad-hoc HTTP requests; use `-k` for lab self-signed certs."},
	{"wget", "Ad-hoc HTTP(S) downloads; use `--no-check-certificate` for lab certs."},

	// Ports / services
	{"nmap", "Port scan with service/version detection and NSE scripts."},
	{"naabu", "Fast port discovery across many hosts (`naabu -host target -top-ports 1000`)."},
	{"masscan", "Very fast wide-range port scanning."},

	// Content / paths / fuzzing
	{"ffuf", "Directory/parameter/vhost fuzzing (`ffuf -u https://t/FUZZ -w wordlist.txt`)."},
	{"gobuster", "Dir/DNS/vhost brute force."},
	{"dirb", "Simple directory brute force with built-in wordlists."},
	{"dirsearch", "Web path/directory brute force with extension and recursion handling (`dirsearch -u https://target`)."},
	{"feroxbuster", "Recursive content discovery with filtering (`feroxbuster -u https://target`)."},
	{"wfuzz", "Web fuzzer for paths, parameters and auth (`wfuzz -c -w list -u https://t/FUZZ`)."},
	{"arjun", "HTTP parameter discovery (`arjun -u https://target/endpoint`)."},
	{"katana", "Crawl a site, including JS-rendered routes (`katana -u https://target -jc`)."},
	{"gau", "Pull known URLs from AlienVault/Wayback/Common Crawl."},
	{"waybackurls", "Historical URLs from the Wayback Machine."},

	// Vulnerability scanning / exploitation
	{"nuclei", "Template-driven vuln scan — run early and broad (`nuclei -u https://target -severity high,critical`)."},
	{"sqlmap", "SQL injection detection/exploitation (`sqlmap -u '<url>' --batch --level 3`)."},
	{"dalfox", "XSS scanner (`dalfox url https://target/?q=1`)."},
	{"nikto", "Web server misconfiguration scan."},
	{"searchsploit", "Offline Exploit-DB search for public PoCs (`searchsploit <product> <version>`) — use to find a starting PoC, then verify it yourself."},
	{"hydra", "Credential brute force over HTTP/form/SSH/SMB/RDP/FTP/MySQL (`hydra -l user -P pass.txt ssh://target`)."},

	// AD / SMB / directory / pivoting
	{"impacket", "Python AD/SMB/WinRM protocol tooling (`impacket-*`, e.g. `impacket-secretsdump`, `impacket-psexec`)."},
	{"netexec", "Network/AD swiss-army (SMB/WinRM/LDAP/MSSQL/SSH) — successora to CrackMapExec, `nxc smb target -u u -p p`."},
	{"smbclient", "SMB share enumeration (`smbclient -L //target`)."},
	{"ldapsearch", "LDAP/AD queries (`ldapsearch -x -H ldap://target -b 'dc=...'`)."},
	{"snmpwalk", "SNMP enumeration."},
	{"tcpdump", "Capture traffic for evidence."},
	{"socat", "Relays and listeners for pivoting."},
	{"proxychains4", "Route tools through a chain of proxies for pivoting (`proxychains4 <cmd>`)."},
}

// seedToolchainShellHints registers the toolchain shell hints bound to worker + pentest.
// Runs on every startup (idempotent, insert-if-absent).
func (s *Server) seedToolchainShellHints() {
	agents := []string{"worker", "pentest"}
	for _, h := range toolchainShellHints {
		if err := s.m.pg.SeedShellHint(h.Key, h.Desc, agents); err != nil {
			log.Printf("[tools] seed shell hint %s failed: %v", h.Key, err)
		}
	}
}
