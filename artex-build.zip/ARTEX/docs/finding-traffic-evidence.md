# Finding Multi-Traffic Evidence

The "Linked Traffic" section of a finding detail supports cross-page multi-select, purpose and notes, ordering, and unbinding. The traffic page also supports selecting multiple records and linking them to an existing finding all at once. Finding evidence inherited by a task is read-only; modifying it requires entering the source task.

The "Agent auto-binds traffic" setting in system settings is off by default; the read and modify endpoint is `agent_traffic_binding` under `/api/settings`. Enabling it increases Token consumption from reviewing requests/responses, tool calls, and prompts; the next Agent run uses the new setting. When disabled, the auto-binding parameter and the rebind tool are hidden, no auto-binding guidance is injected, and auto-binding newly submitted by an already-running session is rejected. Manual binding, traffic capture, reading saved evidence, and export are unaffected.

Once enabled, the default flow is "discover and record → automatically trigger the report Agent → verify and bind traffic → write the report against the latest evidence version." The reporter keeps the verification command, key output, any existing real traffic IDs, and their purposes in `evidence`; the report Agent, combining the finding details and execution records, verifies with `traffic_search` / `traffic_get`, calls `bind_finding_traffic`, then reads the latest `version` to save the report. When the switch is off, the report Agent gains no extra raw traffic search/read tools and does not auto-bind; it can still read manually bound snapshots and generate a report.

Compatible with existing callers: `report_finding`'s `traffic_refs` / `evidence_hint_id` can still bind explicitly and immediately. Binding is optional: for non-HTTP findings such as TCP, or when no exact record was collected or can be found, omitting the references still allows normal reporting and report writing; retain other verifiable evidence such as command output and logs, it is recommended to note why nothing was bound, and no new required fields are added. All submitted IDs must be valid and their bodies complete. If any single one fails, the entire binding operation is rolled back; if the explicit bind accompanying a report fails, the whole report submission is rolled back. Repeatedly appending the same snapshot does not add a binding and does not overwrite the note.

## Agent Numbering and Report Versions

`report_finding` adds optional parameters; the array order is the initial evidence order:

```json
{
  "traffic_refs": [
    {"traffic_id": "real traffic ID", "role": "baseline", "note": "normal account request"},
    {"traffic_id": "another real traffic ID", "role": "proof", "note": "reproduction request"}
  ]
}
```

The purposes are `baseline` (normal control), `proof` (vulnerability proof), `verification` (supplementary verification), and `supporting` (auxiliary evidence, the default). Use `traffic_search` / `traffic_get` to verify against real records first; domain and time are only used to filter candidates and do not infer task ownership.

For the prompt, refer to [CyberStrikeAI's vulnerability reporting tool guide](https://github.com/RuoJi6/CyberStrikeAI/blob/54d56774b8bd285817d16d48b70a4a5e6e0963f7/internal/app/vulnerability_tools.go), combined with this project's optional binding conventions; do not introduce a required-field check for the reason a packet is missing. Do not guess IDs, and do not re-probe merely to obtain a missing packet.

The returned first line is still `finding recorded: <exploration node ID>`; the following JSON provides the standalone finding record `finding_id`, the exploration node `finding_node_id`, and a binding summary.

- `get_finding_traffic(finding_id)` uses the **standalone finding record ID** and returns an ordered list with `version`; passing `binding_id`, `side=request|response`, `offset`, `length` reads it in segments of at most 8192 bytes each.
- `update_finding_report`'s `finding_id` **continues to use the exploration node ID**. The newly added `evidence_version` holds the version actually read; evidence changes during generation cause the old version's write to be rejected, requiring a fresh read and regeneration.
- When an old report call does not pass a version, it does not claim to overwrite existing traffic evidence. After a binding, note, purpose, or ordering change, an existing report indicates it is pending update.

With auto-binding enabled, `add_hint` / `add_task_hint` support storing `traffic_refs` in a single hint or in each element of a batch `hints`. A Planner reporting on someone's behalf may pass `evidence_hint_id` to explicitly select references from the hint corresponding to this task; it cannot reference an inherited hint. The system does not guess bindings from domain, time, or browsing history. A failed submission does not create a partial finding or trigger the report early.

When an existing finding has a missed binding, use `bind_finding_traffic(finding_id, traffic_refs)` to rebind without re-registering. `list_findings` / `list_task_findings` / `node_detail` / `get_task_node_detail` return an explicit `finding_id` and `finding_node_id`; the old `id` keeps its exploration node semantics.

At startup, optional properties are added only for old tool schemas; the original default traffic tool binding is extended to the report Agent; the rebind tool is given to the report Agent by default. Custom binding lists, prompts, descriptions, and enabled state are preserved. Guidance is added uniformly after final tool assembly: the reporting role is responsible for handing off existing evidence, and the report Agent is responsible for verifying, binding, and writing the report. When a platform conversation lacks task context, it should hand off to the task Agent via a structured hint rather than reporting directly. Existing evidence should be handed off before deciding a task is complete; a missing packet does not force waiting. A failed `report_finding` does not trigger the report Agent.

## API

Base path: `/api/exploration/findings/{finding_id}/traffic`, using the standalone finding ID. Existing authentication applies; `context_task` validates task visibility and inherited read-only status.

| Method / Sub-path | Request / Response |
| --- | --- |
| `GET` | Ordered summary, evidence version, version adopted by the report |
| `POST` | `{"traffic_refs":[...]}` appends the whole batch |
| `PATCH /{binding_id}` | `{"version":1,"role":"proof","note":"note"}` |
| `DELETE /{binding_id}` | `{"version":1}` |
| `PUT /order` | `{"version":1,"binding_ids":["2","1"]}`, must be the complete list |
| `GET /{binding_id}` | Snapshot metadata and a bounded body preview |
| `GET /{binding_id}/body` | `side`, `offset`, `length`; `download=1` downloads the full raw bytes |

Version/ordering set conflicts and writes during archiving return `409`; inherited writes return `403`; a binding that does not exist or does not belong to the finding returns `404`; traffic/attachment reads and validation failures return explicit errors.

## Storage and Migration

Startup idempotently migrates PostgreSQL: it adds `traffic_evidence_snapshots`, `finding_traffic_bindings`, and `findings.evidence_version` / `report_evidence_version` (default 0). It does not guess rebinds from historical text.

A snapshot stores the original traffic ID, capture time, URL, method, status, request/response headers, body length, and SHA-256. Bodies are stored by hash under `<data>/evidence/blobs/<first two hex digits>/<hash>.bin`, independent of the cleanable `data/traffic`; multiple findings can share a snapshot/body. Snapshots have no content-update endpoint; when validation is inconsistent, reads and exports fail.

The full body is read under the original traffic write lock, including large body blobs and records from old directories. The file is persisted and validated first, then a single PostgreSQL transaction writes the exploration node, intent relations, finding, snapshot, and binding; the planner is notified only after commit. A failure may leave unreferenced files behind, but does not produce partial business records.

PostgreSQL advisory lock `7337741004` coordinates evidence files and SQL references; the task row lock prohibits evidence modifications after a task is queued for archiving. Recovery holds the evidence lock throughout, from installing the body to committing the metadata. Deleting a finding cascades to remove its bindings.

The cleaner runs hourly and reclaims only content that is unreferenced and not part of an in-progress operation, with a delay of at least 24 hours. Ordinary traffic cleanup does not touch the evidence directory. When backing up hot data, back up both PostgreSQL and `data/evidence`.

## Export and Archiving

Markdown includes the ordered evidence list and version; JSON includes metadata; CSV adds counts and binding IDs. `md-zip` preserves the finding Markdown and provides:

```text
evidence/<finding_id>/<binding_id>/
  manifest.json
  request.http
  response.http
  request.bin
  response.bin
```

The Markdown references messages via relative links. Before sending a download, attachment copying, hash validation, compression, disk sync, and a CRC read check of all ZIP entries are completed; a missing/corrupt entry fails the entire download. Full attachments keep the original binary bytes.

Archive v3 collects snapshots and bodies by finding binding relationship, without depending on the original traffic or domain. Hot data is cleaned up only after package validation completes; shared evidence is retained. Restore validates and installs the body first, then transactionally restores metadata and bindings, and supports retry on failure. v1/v2 remain restorable, with missing new fields explicitly filled as 0.

## Verification and Boundaries

Set up an independent, newly created PostgreSQL test database for each test package, specified via `ARTEX_PG_DSN`, to avoid residual task/model fixtures triggering background runs. Run the full tests for the relevant packages and confirm that nothing is skipped due to missing configuration:

```sh
# Before running each package, set ARTEX_PG_DSN to the corresponding independent test database; explicit configuration failures must error.
go test ./<package> -count=1
go test -race -p 1 ./evidence ./db ./agent ./server -run 'TestEvidence|TestFindingTraffic|TestFindingEvidence|TestReportFindingAtomicContract|TestTaskArchive'
```

Frontend verification includes `npx tsc --noEmit`, Biome checks on affected files, a Webpack build, and a `NEXT_EXPORT=1` static export. Use an independent cache directory to avoid overwriting a running development service.

Local end-to-end acceptance uses independent ports, controlled HTTP / domain HTTPS targets, and a temporary data directory, covering both binding entry points, cross-page selection, ordering/notes, error messages, inherited read-only status, download, and export, archiving, hot body reclamation, restore, and hash validation after deleting the original traffic.

The first version uses a global evidence coordination lock; during large batches of binding/export or slow attachment downloads, other evidence operations may wait. Evidence cannot be fabricated when recording records or the full body are missing. This feature does not change the capture switch, nor does it address certificate issues with direct IP access over HTTPS.
