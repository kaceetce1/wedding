---
name: bypass-arsenal
description: Thư viện kỹ thuật bypass theo lớp — encoding/parser-differential/WAF/filter/auth/deser/crypto. Dùng khi user nói "bypass", "绕过", "WAF block", "filter chặn", "bị chặn", "payload không chạy", hoặc khi sanitizer math (skill vuln-reasoning) cho thấy filter sống sót. Kèm dork săn bypass blog TQ.
---

# 🛡️ Bypass-Arsenal — Thư Viện Bypass

Khi skill `vuln-reasoning` §3 (sanitizer math) phát hiện filter sống sót, hoặc WAF/tool chặn payload → vào đây chọn kỹ thuật.
Nguyên tắc: **bypass = khai thác sự khác biệt (differential)** giữa 2 parser (WAF↔backend, app↔DB, encoder↔decoder).

## Tìm bypass nhanh (kết hợp cn-0day-hunt)
```
site:xz.aliyun.com OR site:freebuf.com OR site:anquanke.com  <tech> <vuln_cn> 绕过
site:github.com "<CVE/CWE>" (bypass OR WAF OR filter)
"<WAF-name>" bypass <vuln_cn>   # VD: "Cloudflare" SQL注入 绕过
```

## 1. Encoding / representation bypass (input-validation)
Filter so khớp chuỗi → đổi biểu diễn mà backend vẫn hiểu:
- **Multi-layer encode**: URL `%253C` → server decode 1 lần `%3C` → decode lần 2 `<`. Double/URL-encode.
- **Case / whitespace**: `ScRiPt`, tab/CR/LF/newline giữa token, `/**/` thay space.
- **Unicode/UTF-8 overlong**: `%C0%BC` = `<` (overlong, server cũ chấp nhận).
- **Hex/Base64**: SQL `0x...`, `CHAR()`, `UNHEX()`; payload base64 nếu param decode.
- **Null byte**: `<script\x00>` cắt filter, backend đọc đến `\x00`.
- **Case-insensitive keyword split**: `UN/**/ION SEL/**/ECT`.

## 2. Parser-differential (WAF ↔ backend)
WAF parse khác backend → payload "vô hại" với WAF nhưng có hại với backend:
- **HTTP Request Smuggling**: CL.TE / TE.CL / TE.TE — Front-end vs back-end đọc length khác nhau.
- **Content-Type confusion**: WAF check body JSON, backend đọc `multipart`/`xml`.
- **Chunked transfer**: `Transfer-Encoding: chunked` giấu payload khỏi WAF byte-count.
- **HPP** (HTTP Parameter Pollution): `?id=1&id=UNION...` — WAF thấy `id=1`, backend nối/ghép.
- **Line folding / obs-fold**, Unicode host, backslash-vs-slash path.
- **Method override**: `X-HTTP-Method-Override: PUT` để chạy method bị WAF chặn.

## 3. WAF fingerprint → bypass cụ thể
Dùng `wafw00f` (skill redteam-fuzz) rồi tra bypass theo vendor:
| WAF | Kỹ thuật thường dùng |
|---|---|
| Cloudflare | chunked + oversized param, unicode normalization, IP rotation |
| ModSecurity (OWASP CRS) | comment `/**/`, case, HPP, byte < 0x20 |
| Akamai | header smuggling, slow request, content-type swap |
| F5/Imperva |multipart inconsistency, JSON vs form |

Giảm rate, random UA, IP rotation (proxy pool) khi WAF rate-base.

## 4. Auth / session bypass
- **JWT**: `alg:none` (base64 `eyJhbGciOiJub25lIn0`), weak HS256 secret (hashcat -m 16500, skill redteam-bruteforce), `kid` path traversal/injection, `jku`/`x5u` SSRF.
- **Logic**: đổi role trong body/JWT (`"role":"admin"`), force-browse authed endpoint, OTP reuse, password-reset token leak.
- **Default creds**: searchsploit + cn-0day-hunt + `SecLists/Passwords/Default-Credentials`.
- **OAuth/SAML**: redirect_uri open redirect, state missing (CSRF), SAML XML signature wrapping.

## 5. Filter / sanitizer logic bypass
- **Type juggling**: PHP `==`, `0=="admin"`, `in_array("1",...)` loose.
- **Truncation**: MySQL `admin` + space padding (column unique index cắt), `"admin x"`.
- **Array override**: `?id[]=1` phá `strcmp`/`md5` trả NULL.
- **Regex miss**: filter chỉ match 1 lần → lặp payload; anchoring sai (`^...$` multiline).
- **Integer overflow / boundary**: `-1` id, `MAX_INT+1`, float precision.

## 6. Deserialization filter bypass
- **Gadget selection**: sink sống nhưng gadget chain bị block → đổi chain (xem `phpggc`/ysoserial gadget list).
- **Autotype / type allowlist bypass**: Fastjson `{"@type":"..."}` — L (Ljava.lang) prefix, `$ref`, cache; Shiro đổi gadget khỏi CommonsBeanutils1.
- **Magic method / __wakeup**: dùng gadget không qua magic bị filter.
- Săn chain mới → skill `cn-0day-hunt` (cộng đồng TQ publish deser chain nhanh).

## 7. Crypto / protocol bypass
- **Padding oracle**: PKCS#7 → decrypt từng block (CBC, JWT, .NET ViewState).
- **Nonce/IV reuse**: AES-GCM → forge; ECDSA nonce reuse → private key.
- **Downgrade**: TLS, Kerberoasting (RC4), NTLMv1, SAML signing alg.
- **Weak KDF/RNG**: predictable token, time-seed.

## Quy trình chọn bypass
1. Xác định CHÍNH XÁC filter/WAF (skill version-fingerprint / wafw00f).
2. Tìm differential: WAF/encoder parse khác backend ở đâu?
3. Chọn kỹ thuật §1-7 khớp differential.
4. Mental-simulate payload qua filter → nếu sót sink (skill vuln-reasoning §4) → chạy.
5. Mutate (skill vuln-reasoning §4 mutation engine) cho đến CONFIRMED hoặc cạn kỹ thuật.
