---
name: primitive-harvest
description: AUTO-INVOKE on ANY research task where a finding exists (recon hit, fuzz anomaly, attack byproduct, CVE research, bounty writeup). Record EVERY finding at ANY severity (Info/Low/Medium/High/Critical). Never discard on RCE-only filter. Meta-skill that funnels everything into the framework.
---

# 🌾 Primitive-Harvest — Capture Every Finding

The single biggest failure mode in this lab has been **RCE tunnel vision**: a Medium info-leak or auth-bypass primitive gets discarded because it isn't RCE, then the engagement pivots and the primitive is lost. This skill forces structured capture of every finding, at any severity, and routes them to the rest of the framework (`bugclass-catalog`, `chain-builder`, `cousin-sweep`, `variant-analyzer`).

If a finding exists, it deserves a record. Period.

## 1. Trigger conditions — fire this skill

Invoke `primitive-harvest` (and the **`templates/primitive-card.md`** template) in any of these situations:

1. **Recon output** — an endpoint, header, behavior, or asset shows something unexpected (e.g., `X-Debug: 1`, `/actuator/env` exposed, hidden response header).
2. **Fuzz anomaly** — `feroxbuster` / `ffuf` / `arjun` returns 200 on a path the framework shouldn't, or arjun discovers an undocumented parameter.
3. **Attack byproduct** — while running `redteam-attack` (nuclei, sqlmap, commix, dalfox) you trigger a finding that isn't the primary vector but is real (e.g., detailed error stack on 500, path leak in 404 page).
4. **CVE adaptation** — `oneday-hunt` adapts a CVE to target and during PoC rehearsal you discover a related issue (e.g., sinks reachable through a related code path).
5. **Bounty / external leak** — someone publishes a Medium in HackerOne / cn-sec; even if you don't have the target, the **bug class** matters, file it as a primitive instance.

If you find yourself thinking **"this is just a `Low`/`Info`"**, that's the cue. File it.

## 2. Primitive record schema

The strict contract lives at **`primitives/_schema.md`** (read once before first use). Rendered template: **`templates/primitive-card.md`**.

Minimum viable record (MVR) requires:
- All YAML frontmatter (severity, primitive-class, status, pre-auth, default-config).
- §4 source → sink (even one line is enough).
- §5 PoC sketch (even pseudo-code).
- §6 why-not-RCE justification (mandatory for Medium and below).

Storage path: **`primitives/<target-slug>/<primitive-slug>.md`**. One file per finding. Update `primitives/_index.md` (auto-maintained by this skill) with one line per primitive.

## 3. Severity ≠ value matrix

| Severity | Standalone value | Chained value | Decision |
|---|---|---|---|
| **Critical / High** | RCE-equivalent | Confirm + file + chain | Always file |
| **Medium** | Often "discarded" but pairs with deser-input or auth-bypass | **Important primitive** | Always file, defer chain judgment to chain-builder |
| **Low** | Standalone rarely critical | Pairs with `info-leak` to escalate | File if engagement has accumulated primitives that chain |
| **Info** | Standalone low value | Pairs with chain to set up the next link | File ONLY if engagement is active and Info helps the chain |

**Anti-pattern callout:** "Medium loadClass0 hash-prefix bypass in Apache Dubbo" → Medium severity, but pairs with Hessian2 deserialization → pre-auth RCE. Discarding it as "not RCE" was the documented failure in the Dubbo engagement 2026-07-22.

## 4. Anti-discard heuristics — file BEFORE pivot

Before any "this is too low value" or "let me pivot" decision, run this 4-question checklist on the discard candidate:

1. **Does this chain with an existing primitive in this engagement?** Check `primitives/<target>/_index.md` and `chain-builder` skill. If yes → don't pivot, run chain-builder.
2. **Does this apply to other products from the same vendor?** Run `variant-analyzer` (lineage spread). If yes → don't pivot, file bugclass card.
3. **Could a Minor mutation bypass a sibling filter?** E.g., if a path-traversal filter rejects `../`, a sibling filter rejecting only `..\\` may not. If yes → `bypass-arsenal`.
4. **Is there a published CVE with the same root cause?** If yes → vendor doesn't take this class seriously; you have multiple cousin targets, run `cousin-sweep`.

If **2+ of the 4 are yes**, the discard decision is wrong. File the primitive.

## 5. Storage convention

```
primitives/
├── _schema.md                 # strict contract
├── _index.md                  # auto-maintained: one line per primitive
└── <target-slug>/             # one folder per product
    ├── <primitive-slug>.md    # one file per finding
    ├── <another-primitive>.md
    └── ...
```

Naming: kebab-case for both target (`apache-dubbo`, `ollama`, `jetty`) and primitive (`loadclass0-hash-prefix-bypass`, `cross-host-redirect-ssrf`).

After writing a primitive, update `primitives/_index.md` with one line:

```markdown
- apache-dubbo/loadclass0-hash-prefix-bypass.md — Medium, CONFIRMED, pre-auth — pairs:auth-bypass-to-admin
```

## 6. Auto-pivot to other skills

After filing, route based on primitive count:

| Trigger | Pivot to | Why |
|---|---|---|
| 1st CONFIRMED primitive in a target | `bugclass-catalog` | extract pattern → Semgrep rule |
| ≥2 primitives in same engagement | `chain-builder` | synthesize kill-chain |
| Bugclass card REUSABLE | `cousin-sweep` | sweep cousins |
| Reading any CVE | `variant-analyzer` | trace lineage |
| Static-only blocked ≥1h | `lab-builder` | spin vulnerable app |

This is the **entry point** for the rest of the framework. Every other skill consumes primitives this skill produces.

## Rigor (cross-cuts `vuln-reasoning` §5)

- **Default ≠ vuln** — file primitive only after the runtime finding path is verified; do not file "if X then Y" speculative primitives without a PoC sketch.
- **CONFIRMED needs evidence** — frontmatter `status` flips from UNVERIFIED to CONFIRMED only when PoC ran at the sink and produced observable impact.
- **No fake primitives** — if no PoC and no source-code trace, file nothing. (Better to delay the filing than to flood the index with garbage.)

## Tool integration

- `redteam-recon` §X — auto-classify every recon output with primitive class before discarding.
- `redteam-fuzz` §X — tag every fuzz anomaly (status 200 unusual size, hidden param, etc.) with primitive class.
- `redteam-attack` §X — confirm byproduct primitives as you run nuclei / sqlmap / commix.
- `cn-0day-hunt` §Y — after finding a writeup, file a primitive instance reference even if you don't have a target.
- `oneday-hunt` §Y — when adapting a CVE, also file the variant primitive for any novel sinks discovered.
