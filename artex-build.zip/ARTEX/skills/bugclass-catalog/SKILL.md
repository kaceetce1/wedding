---
name: bugclass-catalog
description: AUTO-INVOKE immediately after ANY CONFIRMED primitive (any source — primitive-harvest, CVE writeup, bounty platform, lab PoC). Extract abstract bug class, file card under catalog/cards/, generate Semgrep or CodeQL rule. HARD GATE before engagement closure — do NOT skip.
---

# 🗂️ BugClass-Catalog — Extract Reusable Patterns

The whole point of finding a primitive in one target is to **sweep it across many**. This skill converts a single finding into a generalized pattern (a "bug class"), expresses it as a static-analysis rule, and persists it as a card that other skills (`cousin-sweep`, `variant-analyzer`, `cve-watch`) can query.

A primitive is a single instance. A bug class is the abstract pattern. The catalog is the layer in between.

## 1. Trigger

Fire `bugclass-catalog` when:

- `primitive-harvest` has flagged a primitive as `CONFIRMED` (status flipped in frontmatter).
- You're reading a CVE writeup and want to capture the class for future sweeps.
- A bug bounty platform publishes a Medium / Low that exemplifies a pattern you haven't cataloged yet.
- A user request says "extract pattern from this finding" or "file a card for this."

Do NOT fire:
- For speculative primitives (status UNVERIFIED with no PoC). Reach CONFIRMED first via `primitive-harvest`.
- For CVEs that are simple "specific version forgot to patch this" — these stay as CVE instances, no card.

## 2. Card template

Rendered card at **`templates/bugclass-card.md`**. Required sections:

- Root cause (one paragraph — the structural vulnerability).
- Sink signature (code shape that triggers it; language-specific).
- Sanitizer analysis table (sanitizer → what it does → known bypass).
- Cousin-target hypothesis (4 types: framework / family / vendor / dep).
- Exploitation primitives observed (instances table, NOT just CVEs).
- Generated rules (Semgrep path + CodeQL path).
- Sweep outcomes history.
- Lifecycle state.

Storage path: **`catalog/cards/bugclass-<slug>.md`**, slug is kebab-case, max 60 chars, matches the rule file basename.

## 3. Rule generation flow

Pick the analysis tool by language of the primitive:

| Primitive language | Primary rule | Secondary |
|---|---|---|
| Java / Kotlin / Scala | Semgrep (java ruleset) | CodeQL (`java/` pack) |
| Python | Semgrep (`python`) | CodeQL (`python/`) |
| JavaScript / TypeScript / Node | Semgrep (`javascript`, `typescript`) | CodeQL (`javascript/`) |
| Go | Semgrep (`go`) | CodeQL (`go/`) |
| Ruby / PHP | Semgrep | (CodeQL where supported) |
| C / C++ | CodeQL | Semgrep (basic) |
| Shell / config | Semgrep (`bash`, `generic`) | – |

**Semgrep-first by default.** CodeQL is reserved for type-system bugs (generics erasure, taint through `Optional`, race conditions) where Semgrep's dataflow is insufficient.

Generated rule goes to **`catalog/rules/semgrep/<slug>.yaml`** or **`catalog/rules/codeql/<slug>.ql`**. Update frontmatter of card with rule path.

## 4. Lifecycle: DRAFT → TESTED → REUSABLE → ARCHIVED

```
DRAFT         (card created, no instances run yet)
   ↓ primitive-harvest CONFIRMS first instance
TESTED        (Semgrep rule run, ≥1 positive + manually verified)
   ↓ ≥3 confirmed cousins OR ≥1 fresh 0-day discovered via rule
REUSABLE      (cousin-sweep can fire on this card)
   ↓
ARCHIVED      (vendor patches landed widely OR FP rate >30%)
```

State transition is recorded in the card's lifecycle section. ARCHIVED cards stay in catalog (audit trail) but `cousin-sweep` skips them.

## 5. Anti-noise rules (CRITICAL)

- **One card per pattern**, NOT per CVE. CVE-2024-AAAA and CVE-2024-BBBB might both be class `hessian2-prefix-allowlist-bypass` — file ONE card linking both.
- **DO NOT file a card for "regression" CVEs** (vendor broke their own fix). Track as instance only, not a new card.
- **DO NOT file speculative patterns** (no CONFIRMED instance). Status DRAFT is acceptable when CONCEPT is documented, but REUSABLE requires ≥1 cousin sweep hit.
- **Watch FP inflation** — if `cousin-sweep` reports >30% false positives, the rule needs tuning before REUSABLE.

## 6. Cousin-target hypothesis (the section that drives `cousin-sweep`)

For every card, fill in four cousin categories. Even speculative — `cousin-sweep` itself will tell you which hypothesizes played out.

| Category | Definition | Example (Hessian2 prefix) |
|---|---|---|
| **Same framework** | different vendor, same major.minor of underlying framework | Apache Dubbo 2.7.x → Tencent PolarDB-RPC, Alibaba Dubbo-2.7-fork, Huawei ServiceComb-Java-Chassis |
| **Same family** | same parser/serializer lib | Hessian2 → kryo (similar prefix allowlist) → XStream (different mechanism) |
| **Same vendor spread** | same company, other products | Apache Dubbo → Apache RocketMQ (Apache RocketMQ Remoting also uses Hessian2 internally) |
| **Same dependency** | products depending on vulnerable pom/requirements | Anything pulling `org.apache.dubbo:dubbo-*` 2.7.x as a dep |

`cousin-sweep` reads these four lists and generates a sweeping checklist.

## 7. Rigor

- A card without a Semgrep rule is INCOMPLETE — file DRAFT → next step MUST be rule gen.
- A card with REUSABLE state and 0 cousin hits in 2 weeks → either the cousins are inert, or the rule has FPs. Re-tune or ARCHIVE.
- Card changes are append-only (no destructive edits). Use markdown comments or git diff to track edits.

## Tool integration

- Triggered by `primitive-harvest` (auto on CONFIRMED gate).
- Consumed by `cousin-sweep` (rule path + cousin list), `variant-analyzer` (pattern matching against CVE feed), `cve-watch` (REUSABLE pattern alert).
- Index file: **`catalog/cards/_index.md`** (state, instance count, hit rate per card).
