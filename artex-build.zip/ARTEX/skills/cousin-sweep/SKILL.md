---
name: cousin-sweep
description: AUTO-INVOKE whenever a bugclass card reaches REUSABLE status. Generate cousin-target list and sweep the Semgrep/CodeQL rule across them. Convert one finding into 5-50 reusable findings. Also fire weekly or on user request "/cousin-sweep".
---

# 🔄 Cousin-Sweep — Cascade One Finding Into Many

A REUSABLE card in `bugclass-catalog` is worthless until it touches cousin code. This skill **identifies** target code that shares the vulnerable pattern, **sweeps** the generated rule against it, and **records** outcomes back into the card.

Engineers: `cousin-sweep` is your "if this exists in product X, it exists in products Y and Z." Security: it's how you turn one 0-day into 10.

## 1. Trigger

- A `bugclass-catalog` card flips to **REUSABLE** (≥3 confirmed cousins OR ≥1 fresh 0-day).
- Weekly cadence or `/cousin-sweep` slash command.
- After a high-impact CVE writeup drops (vars via `variant-analyzer` may push into here).
- User says: "sweep this rule across X / sweep Y targets / same-class search."

Do NOT trigger if card is DRAFT (no rule yet) or ARCHIVED (vendor patches or FP rate too high).

## 2. Cousin identification heuristics

Apply in priority order. Output is a per-sweep checklist (template **`templates/cousin-sweep-checklist.md`**).

| # | Heuristic | What it surfaces | Limitation |
|---|---|---|---|
| 1 | **Same framework, different vendor** | Products using `<framework>` major.minor | Need vendor list; assume competitors exist |
| 2 | **Same parser family** | Products embedding `<parser lib>` version | Lib-level cousins often cross language boundaries |
| 3 | **Same vendor, different product** | Vendor's other products | Vendor's own product matrix |
| 4 | **Same dependency pinned to vulnerable range** | Maven/Gradle/npm/pip/go deps | Need pom.xml scan automation |
| 5 | **Same maintainer's other projects** | Maintainer forks/related repos | Git blame → find related repos |
| 6 | **Forks where upstream patch was reverted** | Old forks rebase skipped | Hunting: `git log --all -- src` for reverted patches |

Apply heuristics 1-4 first; they're cheap. Heuristics 5-6 require GitHub reconnaissance.

## 3. Sweep execution

For each cousin identified:

1. **Reachability check.** Clone the repo (or use existing local copy if already in `0day/<target>/`). Confirm the cousin uses the vulnerable code path.
2. **Rule run.** `semgrep --config catalog/rules/semgrep/<slug>.yaml <cousin-source>` OR `codeql database analyze <cousin-db>`.
3. **Triage.** Per hit: is this REAL (vulnerable) or FP (sanitized, different config)? Manually verify at least 1 of each.
4. **File primitive.** If real, hand off to `primitive-harvest` (this is itself a primitive harvest for the new target).
5. **Update card.** Add instances row, increment hit-rate, bump `TESTED` → `REUSABLE` if applicable.

Sequential across cousins is FINE — they typically share a base, so spreading rate doesn't help much. Parallel if you have ≥5 cousins and want to scan their src/ in parallel (each subagent does one cousin's git clone + semgrep run).

## 4. Hit-rate tracking (post-REUSABLE)

For every sweep, record:
- Run hit-rate: % positives of total cousins run.
- Cumulative since REUSABLE.
- Per-cousin breakdown.

A successful card runs at **≥20% hit-rate** (cousin-sweep produces ≥1 confirmed cousin per 5 attempts). Below this, the card's rule is too narrow or the cousins heuristic is wrong — `bugclass-catalog` should re-tune.

If hit-rate reaches ≥50% across ≥10 cousins → high-impact card; consider treating as critical disclosure batch.

## 5. Stop criteria (any → end sweep)

- FP rate > 30% across last N runs → rule needs tuning.
- Vendor patch lands on all reachable cousins → card → ARCHIVED.
- All reachable cousins exhausted → reschedule in 30 days for new forks.
- ≥10 confirmed cousins OR ≥2 fresh 0-days found → escalate; the card justifies a batch disclosure or vulnerability class paper.

When stopping for any reason, fill in the **Sweep Outcomes** section of the card with summary stats.

## 6. Auto-pivot

| Discovery in sweep | Auto-pivot |
|---|---|
| New primitive in cousin | `primitive-harvest` (file under `primitives/<cousin-name>/`) + `chain-builder` if ≥2 primitives in same cousin |
| Pattern emerges across cousins | `bugclass-catalog` upgrade DRAFT → REUSABLE |
| Vendor responds / patches | `variant-analyzer` regression check on remaining cousins |
| ≥10 confirmed cousins | trigger `chain-builder` if a chain forms (rare but valuable) |

## 7. Rigor (cross-cuts `vuln-reasoning` §5)

- **FP audit per cousin.** Before claiming "real," run the 5-question check from `vuln-reasoning` §5 on each cousin hit. Same framework shield / typing shield apply per cousin.
- **Reachability + Impact shield required.** Don't count a card hit if the cousin's vulnerable code path isn't reachable from a hostile input in default config.
- **No mass disclosure without rigor.** ≥10 cousins sounds impressive but is meaningless if FPs and unreachable. Apply rigor per cousin, not bulk.

## 8. Tool integration

- Consumed from `bugclass-catalog` (card + rule path).
- Routes to `primitive-harvest` (new primitives), `chain-builder` (chain formed), `variant-analyzer` (regression check).
- Workflow helper: `workflows/cousin-sweep.ps1` (auto: clone → semgrep → triage JSON output). Add to `workflows/lib.ps1` for shared `New-EngagementDir` reuse.
