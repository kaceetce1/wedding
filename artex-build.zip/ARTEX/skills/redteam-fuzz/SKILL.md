---
name: redteam-fuzz
description: Content/directory/parameter fuzzing qua proxy — WAF-aware. Dùng khi user nói "fuzz", "brute directories", "tìm endpoint", "hidden param", "content discovery", "enumerate path". Dùng SecLists + feroxbuster/ffuf.
---

# 🌫️ RedTeam-Fuzz — Content & Param Discovery

**Tools chạy DIRECT (không proxy)** — config 2026-07-11. feroxbuster/gobuster/wafw00f/arjun chạy thẳng.
Muốn route qua SOCKS5h: set env `HTTP_PROXY` (feroxbuster/gobuster honor env) hoặc thêm flag thủ công.

## Workflow tự động
```powershell
.\workflows\web-fuzz.ps1 -Url https://target.com
# Batch từ recon:  .\web-fuzz.ps1 -File recon\...\httpx.txt
```
Output: `dirs.txt` (dir), `files.txt` (ext: php/bak/env/git/sql...), `params.txt` (arjun).

## Wordlists (SecLists @ toolkit\wordlists\SecLists)
| Mục tiêu | Wordlist |
|---|---|
| Directories cân bằng | `Discovery/Web-Content/raft-medium-directories.txt` |
| Files mở rộng | `Discovery/Web-Content/raft-medium-files.txt` |
| Nhanh, common | `Discovery/Web-Content/common.txt` |
| API endpoints | `API/*.txt` (Swagger, big-list) |
| Backup/config | `Discovery/Web-Content/raft-*.txt` + ext `.bak,.old,.zip,.tar.gz,.sql,.env,.git` |
| Spring Boot | `Discovery/Web-Content/spring-boot.txt` (actuators) |
| Static CMS | `Passwords/Common-Credentials/*.txt` |

## Chiến thuật

### 1. WAF check trước → `wafw00f -a <url>`
- Có WAF → giảm rate (`-t 10`), random UA, dùng wordlist nhỏ, chunk.
- Cloudflare/Akamai → `feroxbuster --rate-limit 20 --random-agent`.

### 2. Directory fuzz (feroxbuster, proxy qua env)
```
feroxbuster -u <url> -w raft-medium-directories.txt -t 40 -d 2 -k `
  --filter-status 404 -A -o dirs.txt
```
`-d 2` recursive depth. `-A` random UA. Theo dõi status 200/301/403.
**403** = có thứ gì đó → fuzz sâu hơn, thử `X-Forwarded-For`, method override.

### 3. File/backup fuzz (payload vàng cho RCE/info-leak)
```
feroxbuster -u <url> -x php,asp,aspx,jsp,bak,old,zip,sql,env,git,log,conf,swp
```
`.git/HEAD`/`.env`/`backup.zip`/`web.config.bak` → RCE hoặc cred leak.

### 4. Hidden parameter mining → `arjun -u <url>`
Tìm param ẩn (`?debug=`, `?file=`, `?cmd=`) để chuyển sang attack-chain. Kết hợp wordlist
`Discovery/Web-Content/burp-parameter-names.txt`.

### 5. Tech-specific (chuyển sang cn-0day-hunt)
- Spring → `/actuator`, `/env`, `/heapdump`
- Tomcat → `/manager/html`, `/host-manager`
- SharePoint → `/_layouts`, `/api`, `/_vti_bin`
- Exchange → `/autodiscover`, `/ews`, `/ecp`
- OA (Seeyon/Yonyou/Weaver) → check skill cn-0day-hunt (rất nhiều 0day TQ)

## FP audit
- 200 với content-length rất nhỏ và giống nhau = soft-404 (filter `-C` size).
- 403 toàn cục = WAF/virtual-host; thử `Host:` header khác.
- Kết quả phải verify bằng curl qua proxy trước khi báo "found".
