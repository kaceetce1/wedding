---
name: api-recon
description: Call this skill when collecting website API endpoints.
---

# API Recon (Frontend interface reconnaissance)

Under the premise of **being authorized**, discover as completely as possible: **backend APIs** (paths, methods, parameters, response bodies), **frontend routes**, and **UI feature trigger points** (Tabs, modals, table operations, etc.).

---

## Boundaries and Prohibitions (Agent must-read · violation is out-of-bounds)

This skill **only performs API / parameter surface reconnaissance**; it is not a vulnerability-hunting or penetration-exploitation phase.

### Task boundaries

| Scope | Allowed | Forbidden |
|---|---|---|
| **Target** | Enumerate paths, methods, parameters, routes, UI trigger points | SQLi/XSS/privilege escalation/brute force/fuzz vulnerabilities, packet-tampering attacks, destructive operations |
| **Authentication** | Hook + stub/mock to bypass the **client-side** login gate | Asking the user for or guessing account credentials; attempting real login form submission |
| **Runtime** | Hook interfaces without credentials, use mock responses to let the SPA enter the post-login shell | Flows that depend on a real backend session to continue |

### Credential-free dynamic analysis (Phase 3 default)

1. Via `preload.js` / `runtime_harvest.js`, **intercept and stub** bootstrap interfaces such as login, permissions, and menus;
2. For business query interfaces, return a mock body that is **structurally correct, with a success business code, and data that may be empty**;
3. Make the frontend render the post-login page even in a backend-less or 401 environment, thereby triggering more XHR/fetch/WebSocket;
4. **Empty data, blank tables, and placeholder UI are all expected** — do not switch to real login or vulnerability testing because of this.

**In one sentence**: use mocks to prop open frontend routes and component mounting, and **only record outbound requests**; what the backend returns does not matter, what matters is which interfaces the frontend **will still send**.

### Hard process prohibitions

| Prohibition | Alternative |
|---|---|
| Before Phase 1 is complete, grep/curl/Read the main entry `index-*.js` to extract API paths | Run `OUTDIR/harvest_static.py` |
| Hand-writing scripts like `extract_apis.py` to replace harvest | Modify `OUTDIR/harvest_static.py` then re-run |
| Repeating the same grep/command after it has failed ≥2 times | Change strategy: read tool_logs, modify harvest, check the reference |
| Skipping gate A/B and running the original `scripts/` directly | Copy to OUTDIR and modify for the target |
| Real usernames/passwords, OTP, OAuth, or other authentication | stub/mock (see above) |
| Skipping stub on the grounds of "getting real data" to do privilege-escalation/injection tests | Only record outbound; this is within the recon boundary |
| Irreversible operations such as deletion, exporting sensitive data, or bulk writes | Same applies to coverage clicking |
| Claiming all pages and interfaces have been obtained without completing runtime + dynamic enumeration | See "Definition of done" or annotate the limitations |
| Claiming all parameters are known without completing the parameter trigger matrix + diff | Phase 3b matrix + Phase 5 diff |
| Inferring required/optional from a single runtime sample | Multi-sample diff, or validation rules/error reverse-inference |

---

## Two-layer model + run modes

| Layer | Output | Limits |
|---|---|---|
| **Static** (JS bundle) | Full set of endpoint paths, route drafts, candidate fields at the packet-assembly points | No HTTP methods; parameters require Phase 1b; misses URLs concatenated at runtime |
| **Runtime** (live session) | Method + body + response + dynamic URLs + WS/SSE; multi-sample diff to fill in parameters | The page must actually render before it sends requests; a single sample is insufficient to determine required/optional |

| Run mode | Engine | Applicable |
|---|---|---|
| **depth** | `runtime_harvest.js` (Puppeteer) | API inventory, METHOD/params/response body, WS/SSE, reproducible batch runs |
| **coverage** | browser + `preload.js` | Click Tabs/modals/tables, deeper feature-point coverage |
| **both** | depth first, then coverage | Most complete, most time-consuming |

**Parameter methodology** (no universal script): use harvest/regex for paths; for parameters use **anchor window expansion + UI binding chain + multi-sample diff + error reverse-inference** (grep recipes in [reference.md](reference.md) section J).

---

## Definition of done

Only when all are satisfied may recon be claimed complete:

- [ ] **Static**: Phase 1 harvest produces `api_static.txt`, `routes.txt`, `js/`
- [ ] **Runtime**: at least one of depth or coverage; coverage/both require **Hook effective + dynamic enumeration loop**
- [ ] **Into the shell**: accessing business paths does not land on `/login` (mind hash routes)
- [ ] **Parameters**: coverage/both complete the parameter trigger matrix + `param_samples.json`; Phase 5 merges `params_merged.json`
- [ ] **Depth** (if module pages are blank): Phase 4 permission tree restoration and re-run, until **module-level APIs** appear (not just locale/bootstrap)
- [ ] **Delivery**: Phase 5 outputs are complete (see the Phase 5 output table); `insert_assets` writes service and endpoint assets

---

## Scripts and gates

`scripts/` are only reference templates; **do not** run the originals directly and treat them as the final result.

**Rule**: read first → modify for the target → write into `OUTDIR` (e.g. `recon/`) → record in `CHANGES.md`; if it does not match, rewrite per the methodology, borrowing only the structure.

| Gate | When | Reference script → OUTDIR copy | Common required changes |
|---|---|---|---|
| **A (static)** | After Phase 0, before the **first** harvest/spider run | `harvest_static.py` / `spider_mpa.py` | **For most sites the default regex runs directly**; only when the manifest/dialect does not match, change the endpoint regex, webpack/Vite `publicPath`, MPA exclude/cookie |
| **B (runtime)** | After Phase 2, before running depth/coverage | `runtime_harvest.js` / `preload.js` + `config.json` | Cookie/localStorage keys, neutralize success values, stubs, login regex, api prefix, hash/history |

**SPA mandatory order** (not interchangeable; Phase numbering takes precedence over "explore first, script later"):

| Step | Must | Forbidden |
|---|---|---|
| After Phase 0 completes | Next Bash = `python3 OUTDIR/harvest_static.py <URL> OUTDIR` | curl/grep/Read the main entry `index-*.js` (usually >500KB) |
| Gate A | Copy script → make small changes as needed → **run immediately** | Manually extracting APIs first before deciding whether to harvest |
| Before Phase 1 completes | Validate output with `wc -l`; on 404 modify harvest and retry | Hand-writing extract scripts; repeatedly grepping a URL that was not downloaded |
| From Phase 1b onward | grep only `OUTDIR/js/*.js` | Using the main bundle instead of harvest |

- ✅ Copy `harvest_static.py` → (optionally) change regex → **run immediately**
- ❌ curl the main bundle → grep many times → write a temporary extract → only harvest at the end
- **MPA**: after Phase 0, the next Bash = `python3 OUTDIR/spider_mpa.py ...`

---

## Tool and output constraints

| Constraint | Description |
|---|---|
| Large files | `index-*.js` over 100KB **must not** be Read/grepped into context; batch-process with OUTDIR scripts |
| grep output | Must use `\| head -20` or `-m 5`; keep only path summaries in the conversation, do not paste bundle fragments |
| Validation | Use `wc -l`, `ls \| wc -l`; do not Read an entire directory |
| Initial regex probing | Optional, ≤1 time, only on small chunks ≤50KB or HTML; the official static result is harvest |
| reference | For recipes/templates/troubleshooting see [reference.md](reference.md); do not repeat the full text inline |

---

## Execution roadmap

```
Phase 0 classification + OUTDIR
  → Gate A → Phase 1 harvest (★ run immediately ★)
  → Phase 1b parameter reverse-engineering
  → Phase 2 three authentication gates → config.json
  → Gate B → Phase 3 runtime + parameter matrix
  → Phase 4 permission tree (if necessary) → re-run Phase 3
  → Phase 5 merged report + insert_assets to bulk-insert all discovered service and endpoint api assets; when inserting, never omit any discovered asset under any circumstances
```

Tick in order; **the next Phase must not be entered until the previous item is complete**.

1. [ ] **Phase 0**: Initial probe of SPA/MPA; create `OUTDIR` → [Phase 0](#phase-0--classification)
2. [ ] **Gate A + Phase 1**: Copy script → harvest **immediately** → validate with `wc -l` → [Phase 1](#phase-1--static)
3. [ ] **Phase 1b**: Anchor window expansion + binding layer → `param_candidates.json` → [Phase 1b](#phase-1b--parameter-reverse-engineering)
4. [ ] **Phase 2**: Three authentication gates → `config.json` → [Phase 2](#phase-2--the-three-authentication-gates)
5. [ ] **Gate B**: Adjust the runtime script → [Phase 3](#phase-3--runtime)
6. [ ] **Phase 3**: depth / coverage / both; confirm entering the shell; parameter trigger matrix → `param_samples.json`
7. [ ] **Phase 4** (if needed): Permission tree → patch stubs → re-run Phase 3 → [Phase 4](#phase-4--permission-tree-restoration)
8. [ ] **Phase 5**: Merge outputs + report + `insert_assets` → [Phase 5](#phase-5--merge-and-report)

---

## Phase 0 — Classification

Fetch the entry HTML, **create `OUTDIR`** (do not modify `scripts/` inside the skill):

- **SPA**: empty shell + `<div id=app>` + chunk → Phase 1–5
- **MPA**: SSR + `<form>`, no endpoint bundle → after Gate A:

```bash
python3 recon/spider_mpa.py <BASE_URL> <OUTDIR> [--cookie "session=..."] [--max 300] [--depth 5] [--exclude "logout|delete|destroy"]
```

Produces `forms.txt`, `links.txt`, `api_inline.txt`. For SPA, if forms ≈ 0 → switch to Phase 1.

---

## Phase 1 — Static

Comply with [Scripts and gates](#scripts-and-gates) · [Tool and output constraints](#tool-and-output-constraints).

```bash
python3 recon/harvest_static.py <BASE_URL> <OUTDIR>
```

harvest: parse HTML script → webpack/Vite manifest → download all lazy chunks → produce `js/`, `api_static.txt`, `routes.txt`, `chunkmap.txt`.

```bash
wc -l OUTDIR/api_static.txt OUTDIR/routes.txt
ls OUTDIR/js | wc -l
```

- Chunk count vs manifest: on 404 you must modify harvest and retry; do not manually curl chunks one by one
- `api_static.txt` too small → loosen the endpoint regex inside OUTDIR and re-run (see reference)

### Phase 1b — Parameter reverse-engineering

Paths come from Phase 1; parameter fields must be recon'd separately. For grep rules see [Tool and output constraints](#tool-and-output-constraints).

**Completion criteria**: for important interfaces you can answer — field names, transport location, type inference, whether required, sample values, confidence.

#### 1b.0 — Transport form

| Form | Where parameters are | What to look at first statically |
|---|---|---|
| REST JSON | body + query | `(params\|data\|body)\s*:\s*\{` next to a path anchor |
| GraphQL | `variables` | gql templates, `$page: Int` |
| Traditional form | urlencoded | `<form>`, `FormData` |
| File upload | multipart | `FormData.append` |
| Path parameters | `/user/:id` | route table + `useParams` / `$route.params` |
| Encrypted/signed | wrapped in `sign`/`data` | Hook the encrypt function's input (reference section D) |

Output: annotate each interface with `transport: query|json|form|graphql|encrypted`.

#### 1b.1 — Anchor window expansion

Use a known path as an anchor, expand the window to find the packet-assembly object:

```bash
grep -n '"/api/user/list"' OUTDIR/js/*.js | head -20
grep -rhoaE '.{0,120}("/api[^"]+").{0,200}' OUTDIR/js/*.js | head -20
grep -rhoaE '(params|data|body|payload)\s*:\s*\{' OUTDIR/js/*.js | head -20
```

| Wrapper layer | Parameter clues |
|---|---|
| axios instance | `data` / `params` |
| Unified request | Interceptor injects global fields |
| OpenAPI client | Generated method signature |
| React Query / SWR | hook second argument |
| Vue composable | composable input |

Type residue: `yup`/`zod`/rules, `Form.Item name=`, embedded Swagger.

→ `param_candidates.json`: `{ path, fields[], source: "static-callsite", confidence }`

#### 1b.2 — Binding layer

```
Form field → onFinish/handleSubmit → transform → API payload
```

| Binding source | Technique |
|---|---|
| Form submit | Follow submit → transform → API |
| Table search | `getFieldsValue()` → `params` |
| Route | `:id` / `?tab=` |
| Interceptor | Global `tenantId`, pagination, sign |
| Enum select | `options` → API enum values |

DevTools call stack: trace the packet-assembly function upward from `fetch`/`XHR.send`.

#### 1b.3 — The three packet-assembly questions (≠ Phase 2's three authentication gates)

| Question | What to answer |
|---|---|
| **Assembly** | Where the payload is built, traces of transform |
| **Validation** | required, pattern, enum |
| **Transport** | path / query / body / multipart / headers |

The interceptor gate (Phase 2) also reads globally injected fields along the way (Authorization, `X-Tenant-Id`, sign).

#### 1b.4 — Interface with Phase 3

Candidate fields come from static/binding layer; **required/optional/conditional dependency** must come from the Phase 3 parameter matrix + diff + Phase 5 error reverse-inference.

---

## Phase 2 — The three authentication gates

grep in `OUTDIR/js/` (with `head`), write to `config.json` (recipes in reference):

| Gate | Question | Keywords |
|---|---|---|
| **Render gate** | How is logged-in determined? | `isLogin`, `getToken`, Cookie/localStorage |
| **Interceptor gate** | What triggers the redirect to `/login`? | `response_code`, `errno`, axios interceptor |
| **Content gate** | Where do menus/permissions come from? | `menu`, `permission`, `role`, `acl`, `routes` |

Do not treat localStorage key names as credentials — they must be confirmed from the chunk/request chain.

**Exit = Gate B**: conclusions land in `config.json`, and modify `OUTDIR/runtime_harvest.js` / `preload.js`.

### Phase 2b — API observation (optional)

Use `preload.js` inside OUTDIR to confirm session key names, Authorization, and nested API URLs:

| Config | Output |
|---|---|
| `recordDetail: true` | `__API_RECON_DETAIL__` |
| `observe.xhrHeaders: true` | header observation |
| `extractUrlsFromResponse: true` | sub-APIs inside responses |
| `observe.storageReads/cookieReads: true` | backfill config |
| `neutralizeVueRouter: true` | `__API_RECON_ROUTES__` |

coverage exports each round: `__API_RECON_LOG__`, `__API_RECON_DETAIL__`, `__API_RECON_ROUTES__`, `__API_RECON_OBSERVE__`.

---

## Phase 3 — Runtime

Gate B must already be passed; comply with [Boundaries and Prohibitions](#boundaries-and-prohibitions-agent-must-read--violation-is-out-of-bounds) · credential-free mock strategy.

In `config.json` set `"runtimeMode": "depth" | "coverage" | "both"` (template in reference).

### Hook and stub (shared by depth + coverage)

| Layer | Scope | Purpose |
|---|---|---|
| L1 exact | auth/permission/bootstrap stub | Pass first-screen authentication |
| L2 negative correction | All JSON responses | Not-logged-in code → success |
| L3 fallback | `/api` etc. not hit by L1 | Empty success body, prop open the UI |

- **depth**: fake auth + `forward` to change business codes + `stubs`; iterate `routes` (hash/history); produce `runtime_api.json`
- **coverage**: **document-start** injection of `preload.js` (CDP `addScriptToEvaluateOnNewDocument` or Userscript)

Verify: `window.__API_RECON_PRELOAD__` exists; business paths do not return to `/login`.

```bash
cd recon && npm install
node runtime_harvest.js config.json
```

### 3b — coverage dynamic enumeration (mandatory)

1. Main nav/sidebar — click each item, wait 1–3s for the network
2. Tabs — `role=tab`, `.ant-tabs-tab`
3. Tables — view/edit/details on the first row
4. Toolbar — export, filter, create (**avoid irreversible deletion**)
5. Each module entered — merge APIs/routes
6. SPA — controlled `pushState` for paths not covered by `routes.txt` (forbidden for MPA)

**Parameter trigger matrix** (mandatory): record once per operation type per module, **diff multiple samples**:

| Operation | Parameters usually added |
|---|---|
| List first screen | Pagination + default filter |
| Click search | keyword, filter |
| Advanced filter | More optional fields |
| Create/edit | Full entity |
| Bulk/export/sort | `ids[]`, `exportType`, `sortField` |

**Under stubs, outbound body/headers are still real** — go by the request. Recordings → `scan_raw.json`, `param_samples.json`, `api_detail.json`.

- **Vue**: `neutralizeVueRouter: true` + document-start preload
- **React**: `routes.txt` + sidebar clicking + `pushState`
- **both**: 3a depth first, then 3b coverage

---

## Phase 4 — Permission tree restoration

**Trigger**: module pages blank / each route only bootstrap (e.g. locale) → content gate not passed.

| Symptom | Meaning |
|---|---|
| Entered the shell successfully | Render gate + interceptor gate are passed |
| Sidebar items missing / clicks are blank | stub shape or permission codes incomplete |
| Same and very few APIs on every route | `v-if permission` not passed |
| `routes.txt` far fewer than the bundle | Must be completed from the auth module |

```bash
grep -rhoaE '"/api[^"]*(permission|perm|role|menu|acl)[^"]*"' OUTDIR/js/*.js | sort -u | head -30
grep -rhoaE 'userRouteAuth|getResultTree|routeMap|routeLink|menuList|authList' OUTDIR/js/*.js | head -20
```

Typical chain: `role_permissions` (flat codes) + `permissions/all` (tree) → `getResultTree` → `userRouteAuth[CODE].url`.

```bash
python3 recon/extract_route_map.py recon/js recon/
python3 recon/build_perm_tree.py recon/js recon/ --config recon/config.json
```

Intermediate outputs: `route_map.json`, `userRouteAuth.json`, `permissions_tree.json`, `*_stub.json`, `perm_codes_all.txt`.

stub checks: the outer `response_code` matches the interceptor gate; flat codes align with the tree; `routes` covers all links in `route_map`.

After updating `config.json`, **re-run Phase 3**. For large SPAs you can tune `waitUntil`, `routeTimeout`, `perRouteMs` (see reference sections A3/I).

---

## Phase 5 — Merge and report

### Output table

| File | Phase | Content |
|---|---|---|
| `js/`, `api_static.txt`, `routes.txt`, `chunkmap.txt` | 1 | Static bundle and paths |
| `param_candidates.json` | 1b | Static parameter field candidates |
| `config.json` | 2 | Three gates + runtime config |
| `runtime_api.json` | 3a | depth detailed recording (including WS/SSE) |
| `param_samples.json`, `scan_raw.json`, `api_detail.json` | 3b | Multi-sample, click log, detail |
| `route_map.json` etc. | 4 | Permission tree intermediate files (if executed) |
| `params_merged.json` | 5 | Merged parameter fields + confidence |
| `api_merged.txt` | 5 | `METHOD /path [params] [static\|runtime\|both]` |
| `site_map.json` | 5 | Routes, APIs, params, feature points, limitations |
| **insert_assets** | 5 | Write all service and endpoint assets into the asset library |

### 5b — Parameter merge

Diff from `param_samples.json`, **no universal merge script**. Confidence rules see reference J7 (high/medium/low/pending-trigger).

### 5c — Error reverse-inference

Within the authorized scope you may send incomplete requests to read 400 (**this is parameter recon, not vulnerability testing**): `field 'x' is required`, enum errors, etc. Note the `data` wrapper, `variables`, and `bizData` before encryption.

The report must state: runtimeMode, static/runtime API counts, parameter confidence, uncovered modules, and a `CHANGES.md` summary relative to the reference scripts.

Suggested structure of `site_map.json`:

```json
{
  "site": "https://example.com",
  "runtimeMode": "both",
  "appType": "vue-spa",
  "routeGuardStrategy": ["nav-neutralize", "L1-auth", "L2-patch", "forward"],
  "apisFromStatic": [],
  "apisFromRuntime": [],
  "apis": [],
  "params": [{ "method": "POST", "path": "/api/user/list", "transport": "json", "fields": [] }],
  "frontendRoutes": [],
  "routesVerifiedByClick": [],
  "featuresTriggered": [],
  "limitations": ""
}
```

For more fields and grep recipes see [reference.md](reference.md).

---

## General notes

- **Framework-agnostic**: webpack/Vite/Angular lazy load methods are the same
- **Transport**: REST/JSON, GraphQL, WebSocket, SSE; gRPC-web is out of scope
- **SSR**: client-side fetch can be recorded; RSC/Server Actions are not fully enumerable
- **Blind spots**: JSVMP, WASM, strong HMAC/mTLS validation → static + annotate limitations
- **Parameter blind spots**: conditional linkage, hidden params, WASM packet assembly → "pending-trigger" / "unreachable"
- **Static is the safety net**: when runtime is blocked, static can still enumerate endpoints

---

## Additional resources

- Grep recipes, `config.json` template, troubleshooting, Hooks, parameter reverse-engineering section J, site_map template: **[reference.md](reference.md)**
- Reference script paths see the [Scripts and gates](#scripts-and-gates) table
