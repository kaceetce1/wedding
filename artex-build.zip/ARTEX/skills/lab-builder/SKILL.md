---
name: lab-builder
description: AUTO-INVOKE when static-only research is stuck ≥1h, when target is hardened with no exploit path, when no in-scope target exists but PoC confirmation is needed, or when variant-analyzer produces HIGH-confidence candidates needing local verification. Spins vulnerable app in Docker (loopback-only) for dynamic PoC.
---

# 🧪 Lab-Builder — Spin Vulnerable Apps for Dynamic PoC

Static-only research hits a wall when:
- The target is hardened / patched in production → nothing left to confirm.
- No target is in scope (engagement closed or pre-scope).
- A variant needs runtime verification before claiming novelty.
- You're hunting for gadgets and need a real classpath.

`lab-builder` scaffolds a Docker-based vulnerable instance so you can dynamically probe, fuzz, and confirm.

## 1. Trigger

- Static analysis confirmed a class / sink / primitive — but no in-scope target exists → need PoC verification.
- Engagement ended; you want to keep researching the class without a real target.
- `variant-analyzer` produced a HIGH-confidence candidate on an unpatched version — you need a local test before touching any real system.
- A CVE is suspicious and 3rd-party PoCs are too messy to adapt.
- `cousin-sweep` rule hit a real cousin — you need confirmation that the cousin's specific code path actually triggers the bug.

## 2. App identification

For most modern OSS apps, the path is:

1. CVE-XXX or version pin → GitHub repo (e.g., `apache/dubbo`, `eclipse/jetty.project`).
2. Find tagged version at-or-before the fix (e.g., `2.7.21` for Dubbo Hessian2 pre-CVE-2026-XXXX).
3. Check repo for `Dockerfile` or `docker-compose.yml` upstream — many include them.
4. If not, use **template Dockerfiles** (kept in `toolkit/lab-templates/`) for common stacks: Spring Boot, Apache Tomcat, Jetty, Node/Express, Flask, FastAPI, Django, Rails, Go net/http.

For obscure apps, vendor's `docs/installation.md` or release tarball + manual setup.

## 3. Docker-compose layout

`lab/<app-slug>-<version>/docker-compose.yml`:

```yaml
version: "3.9"
services:
  app:
    build: .   # or image: <vendor/image:tag>
    ports:
      - "127.0.0.1:8080:8080"   # bind to LOOPBACK ONLY (no exposure)
    volumes:
      - ./capture:/capture      # mitmproxy/trace
    networks:
      - lab-net
    environment:
      - JAVA_OPTS=-javaagent:/capture/agent.jar   # if needed
  mysql:                          # app deps
    image: mysql:5.7
    networks:
      - lab-net
    environment:
      - MYSQL_ROOT_PASSWORD=lab
  capture:
    image: mitmproxy/mitmproxy:latest
    ports:
      - "127.0.0.1:8081:8081"
    networks:
      - lab-net
networks:
  lab-net:
    driver: bridge
    internal: false               # expose only LOOPBACK; no WAN
```

Bind ports to `127.0.0.1`, never `0.0.0.0`. The lab is for the researcher's local box.

## 4. Determinism

For reproducibility across runs:

- **Pin commit hashes** (`git checkout <sha>`). Never `:latest`.
- **Capture expected runtime logs** — first run baseline. Subsequent runs must match.
- **Snapshot container state** on first run: `docker commit lab_app_v1 lab/snapshot:v1` — roll back if a test mutates state.
- **Disable external network calls** during test (unless testing SSRF) — host firewall or container `--network none`.

## 5. PoC replay local → tunnel to real (optional)

Standard procedure:

1. **Local PoC first.** Reproduce in `lab/<app-slug>-<version>/`. Confirm exploit succeeds.
2. **Adapt to real target** (if scope allows). Adjust base URL, headers, payload.
3. **Submit to real target** via lab proxy (`socks5h://4g:...@unixy.xn--lun-lna.vn:10800 -k`).

For SSRF-targeting primitives, lab traffic is to **your own** side (the vulnerable app calls BACK into your mitmproxy / your own hostname). For deser/RCE primitives, lab traffic is to the local container — never WAN.

## 6. Cleanup policy

- **Auto-rm containers** after 24h idle (`docker-compose down --remove-orphans`).
- **Snapshot rotate** — keep at most 3 snapshots per lab.
- **Disk usage** — `docker system df` weekly; prune dangling images.

Hard rule: if a lab container goes > 7 days without use, tear it down. Lab state rots; pin to commit hash anyway.

## 7. Common templates (kept under `toolkit/lab-templates/`)

Quick-build for:

| Stack | Template | Notes |
|---|---|---|
| Spring Boot 2.7.x | `spring-boot-2.7.Dockerfile` | actuator + debug |
| Apache Dubbo 2.7.x | `dubbo-2.7.Dockerfile` | Hessian2 reachable |
| Jetty 12.x | `jetty-12.Dockerfile` | parser differentials |
| FastJSON / Fastjson2 | `fastjson.Dockerfile` | jsonparser sink |
| Express / Node | `express.Dockerfile` | SSTI/SQLi targets |
| Flask | `flask.Dockerfile` | pickle/jinja2 |
| Go net/http | `go-http.Dockerfile` | parser tests |

Templates are TINY (one Dockerfile + sample app) so they're reproducible.

## 8. Rigor

- **Lab ≠ production.** The lab instance is for confirming the bug class exists at the specified commit; in-scope engagements ALWAYS get the real-target test.
- **Cleanup is part of the discipline.** Don't leave orphan containers consuming disk.
- **Hardening control.** The lab target is intentionally vulnerable. Don't expose to WAN. Bind to loopback only.
- **Time budget.** A lab that takes > 2h to spin is too complicated. Aim for `git clone, docker-compose up, run PoC` in < 30 min.

## 9. Tool integration

- Triggered by `oneday-hunt` (need PoC for adapted CVE), `variant-analyzer` (need local variant verification), `primitive-harvest` (static-only stuck ≥1h), `cousin-sweep` (cousin needs live confirmation).
- Outputs to `lab/<slug>-<version>/` and links back to `primitives/<target>/...` records.
- Optionally: the lab instance becomes a `cousin-sweep` candidate with `lab-confidence: yes`.
