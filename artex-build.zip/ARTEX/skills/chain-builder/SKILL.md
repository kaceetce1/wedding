---
name: chain-builder
description: AUTO-INVOKE the moment ≥2 primitives exist in same target/engagement, OR when a primitive-class combination looks load-bearing. Design and validate kill-chain (primitives → goal). Per-link re-verifies via vuln-reasoning §5. Outputs poc_chain.sh end-to-end PoC script.
---

# 🔗 Chain-Builder — Primitives → Goal

This is the kill-chain thinking from `CLAUDE.md` PHASE 7, formalized into a skill. A primitive alone is value; primitives composed into a chain that reaches a real goal are **value compounded**.

`chain-builder` is responsible for taking `primitives/<target>/*.md` files and constructing a verified DAG from primitive A → primitive B → primitive C → goal, with each link independently re-confirmed.

## 1. Trigger

- ≥2 primitive records exist under `primitives/<target>/` (or the same engagement chain).
- A primitive class combination looks load-bearing (e.g., `[auth-bypass, ssrf]`, `[path-traversal, write]`, `[deser-input, gadget]`).
- Engagement closure protocol detects that primitives weren't chained.
- User says: "compose this primitive + that primitive / chain A and B / kill-chain to goal."

If only 1 primitive exists, do NOT trigger chain-builder. Document the chain-gap rationale and store as a deferred (`reason: needs more primitives`) record.

## 2. Chain-graph template

`templates/chain-graph.md` is the rendered output. Build this for every chain synthesis.

Required sections:
- Goal (final impact, single sentence).
- Prerequisite (attacker position, network, egress).
- Primitive DAG (ordered: 1 → 2 → 3 → GOAL).
- Per-link status (each primitive PoC + FP audit pass + re-verified under chain conditions).
- Compatibility rules applied.
- Order-dependence analysis (why this order, not another).
- Per-link re-verification checklist.
- `poc_chain.sh` script (end-to-end PoC).

Storage:
- Chain script: `notes/engagements/<target>_<ts>/poc_chain.sh`
- Chain report: `notes/engagements/<target>_<ts>/<chain-slug>-report.md`

## 3. Compatibility rules (heuristic shortcuts)

| Primitives | Likely composition | Goal reachable |
|---|---|---|
| `[auth-bypass]` + `[admin action]` | Cross-anon → admin | ATO, priv-esc |
| `[ssrf]` + `[cloud-metadata-cred]` | Internal IP → IMDS read | Cloud takeover (AWS/Azure/GCP/Aliyun) |
| `[deser-input]` + `[gadget-classpath]` | External input → gadget | RCE |
| `[template-inj]` + `[secret-leak-from-template]` | SSTI + env access | RCE (info-first) |
| `[xss]` + `[csrf]` + `[session-cookie]` | Stored-XSS or cookie-less-CSRF | ATO |
| `[idor]` + `[sensitive-resource]` | Other-user ID access | Data exfil |
| `[info-leak]` + `[auth-bypass]` | Disclose component + skip auth on it | Often unlocks pre-auth |
| `[path-traversal]` + `[sensitive-file-confirmed]` | Read DB / config | Often pivots to cred-materials |

These are HEURISTICS. Not every combination yields a goal — some pairs reach dead ends. The skill runs the rules as a candidate generator, not a guarantee.

## 4. Order-dependence analysis

Some primitives MUST come before others, regardless of what they individually do.

- **Auth/credential primitives first** — without auth, IDOR / role-confusion primitives have nothing to mis-target.
- **Read primitives first** — without data, decision primitives can't decide.
- **Decision/state primitives next** — once data is in hand, the primitive that interprets it.
- **Write primitives last** — only after the desired state is known.
- **Side-effect primitives last** — they typically ruin forensically.

Example wrong order: write ID → read state (you've forged before you know the truth).

## 5. Per-link re-verification (mandatory)

For each primitive in the chain, re-run `vuln-reasoning` §5 with new assumption set:

- Attacker state = output of prior primitive (not initial state).
- Network position = post-prior-primitive (after move, e.g., post-exfil).
- Revealed info = union of all prior primitives' outputs.
- Type/framework shield: still holds at the new attacker position?
- Reachability shield: does the chain-induced state satisfy preconditions of this primitive?
- Impact shield: this primitive's output usable as next primitive's input?

A primitive that passes for an external attacker but fails from the post-primitive-1 position is **chain-broken** at link N. Fix primitive before continuing.

## 6. Output: chain report + `poc_chain.sh`

The PoC chain script (top-of-tree) compiles all primitives into a single bash script. It is **the deliverable**. Each step traps on failure (`set -e`, `trap 'echo "FAILED at step $?" >&2' ERR`). Goal is to demonstrate the chain end-to-end.

```bash
#!/usr/bin/env bash
# Chain: pre-auth-RCE-via-loadClass0-hessian2
# Primitives: primitives/apache-dubbo/loadclass0-bypass.md (link 1)
#             primitives/apache-dubbo/hessian2-deser-sink.md (link 2)
# Goal: pre-auth RCE

set -e
trap 'echo "FAILED at step $?" >&2' ERR

# Link 1: loadClass0 hash-prefix bypass
echo "[1] loadClass0 bypass..."
<command-1>

# Link 2: Hessian2 deserialize attacker class
echo "[2] Hessian2 deser with bypassed classloader..."
<command-2>

# Goal: shell marker
echo "[GOAL] demonstrating RCE via DNS OOB..."
<shell-marker>
```

## 7. Failure-mode audit

Even when a chain proves viable, list:

- Each link's failure modes (e.g., "link 2 requires X + Y; X is conditional").
- **Shortest chain alternative.** Can any link be merged/skipped?
- **Pure-primitive count.** How many links could become a single primitive? (Single primitives are preferred — chain signal vs single primitive signal.)

## 8. Auto-pivot

| Chain outcome | Action |
|---|---|
| All links CONFIRMED + goal verified | Disclosure prep (vendor + CVE application if novel). Update card to REUSABLE+ if chain is novel |
| Chain broken at link N | File primitive issue for N, fix link first (don't pivot) |
| Chain not reachable (≤1 primitive) | Document rationale, defer to next primitive |
| Chain too brittle for reliable PoC | Reduce to longest confirmed primitive sub-chain, file that |

## 9. Rigor

- Each link's `CONFIRMED` status must hold under chain-specific assumptions — primitive-harvest's CONFIRMED is from initial attacker state, not chain-induced state.
- Defense-in-depth observations: a chain that depends on every defensive layer failing is fragile. Prefer chains that survive one defensive layer.
- No disclosure with a CONFIRMED-broken chain. Fix chains before disclosing.

## 10. Tool integration

- Triggered by `primitive-harvest` (count ≥ 2 in same target), `cousin-sweep` (when new primitives discovered), or user's request.
- Outputs to `notes/engagements/<target>_<ts>/`.
- Coordination with `vuln-reasoning` §6 attack tree (chain IS the attack tree realized).
