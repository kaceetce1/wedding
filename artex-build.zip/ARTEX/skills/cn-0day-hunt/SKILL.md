---
name: cn-0day-hunt
description: AUTO-INVOKE on any TQ PoC/writeup/0day/CVE/bypass search request. ALWAYS run §Y Pattern Extraction post-writeup — file bugclass-catalog card (or known-match rationale) before exiting. Translate EN/VN → CN keywords, dork across 3 platform tiers + Gitee/GitHub, fetch + extract PoC.
---

# 🐉 CN-0day-Hunt — Săn 0-day từ Blog Trung Quốc

Skill siêu việt để tìm PoC / writeup / bypass / 0-day từ cộng đồng security Trung Quốc —
nơi publish nhanh nhất và chi tiết nhất cho các CVE mới, đặc biệt China-origin tech
(Spring, Shiro, Fastjson, Shenzhen/Zhejiang middleware, OA systems, IIoT, gov stacks).

**Luôn đọc skill này TRƯỚC KHI** trả lời khi user nhắc PoC/CVE/bypass/0-day.

## 0. Quy trình cốt lõi (luôn theo thứ tự)

1. **Dịch** từ khóa EN/VN → CN (Bảng §1) — search bằng tiếng Trung gấp 5-10× hit.
2. **Dork** song song trên 3 tầng platform (§2) + Gitee/GitHub (§3) cho code PoC.
3. **Fetch** top 3-5 kết quả bằng `mcp__web_reader__webReader`, extract PoC/payload.
4. **Verify** PoC qua lens: reachability + sanitization + sink (dùng `<poc_simulation>`).
5. **Adapt** payload cho proxy lab (`socks5h://4g:...@unixy.xn--lun-lna.vn:10800`, `-k`).

## 1. Bảng dịch thuật Security EN→CN (bắt buộc dùng khi search)

| EN / VN | 简体中文 (CN) | EN / VN | 简体中文 (CN) |
|---|---|---|---|
| vulnerability / lỗ hổng | 漏洞 | remote code execution | 远程代码执行 (RCE) |
| exploit / khai thác | 利用 / EXP | arbitrary file read | 任意文件读取 |
| PoC / proof of concept | 复现 / PoC | arbitrary file upload | 任意文件上传 |
| 0-day | 0day / 零日漏洞 | SQL injection / 注入 | SQL注入 |
| bypass /绕过 | 绕过 | XSS / cross-site | 跨站脚本 |
| authentication bypass | 认证绕过 / 未授权访问 | SSRF | SSRF / 服务端请求伪造 |
| deserialization | 反序列化 | XXE | XXE |
| reverse shell /反弹shell | 反弹shell | privilege escalation | 提权 |
| unauthorized access | 未授权访问 | information disclosure | 信息泄露 |
| gadget chain / gadget | 利用链 | sandbox escape | 沙箱逃逸 |
| webshell | webshell / 一句话木马 | persistence /后门 | 后门 |
| path traversal | 目录穿越 / 路径穿越 | command injection | 命令注入 |
| CVE number | CVE-XXXX-XXXXX | fingerprint /指纹 | 指纹识别 |
| OA system | OA系统 | middleware /中间件 | 中间件 |

**Mẹo:** ghép CVE + `漏洞` hoặc `复现` → ra writeup; CVE + `利用` → ra exploit; tech + `未授权` → ra access-bypass.

## 2. Tầng Platform (theo độ tin cậy & chiều sâu)

### Tier S — Chất lượng cao nhất (Alibaba/Seebug/Paper)
| Platform | Domain | Đặc biệt |
|---|---|---|
| **先知社区 XianZhi** | `xz.aliyun.com` | Alibaba SEC, phân tích sâu, chain phức tạp |
| **Seebug Paper** | `paper.seebug.org` | Deep-dive CVE, chính Seebug/Mitreme |
| **安全客 AnQuanKe** | `anquanke.com` | Threat intel + vuln analysis mới nhất |
| **长亭 Chaitin** | `chaitin.com` | WAF vendor, bypass research |

### Tier A — Community writeup dày đặc
| Platform | Domain |
|---|---|
| **FreeBuf** | `freebuf.com` |
| **cn-sec** | `cn-sec.com` |
| **Hacking8** | `hacking8.com` |
| **白帽汇 BMH** | `baimaohui.net` |
| **90Sec** | `90sec.org` |
| **T00ls** | `t00ls.com` (forum, cần login) |

### Tier B — Dev/Q&A (cho logic & config leak)
`blog.csdn.net` · `cnblogs.com` · `juejin.cn` · `segmentfault.com` · `zhihu.com`

### Tier R — Reverse / Payload
| Platform | Domain |
|---|---|
| **吾爱破解 52PoJie** | `52pojie.cn` |
| **看雪 KanXue** | `bbs.kanxue.com` |

## 3. Dork templates (dùng WebSearch — gọi song song)

```
# A. Writeup cho 1 CVE cụ thể (Tier S+A)
site:xz.aliyun.com OR site:paper.seebug.org OR site:anquanke.com <CVE>

# B. PoC code trên Gitee/GitHub
site:gitee.com "<CVE>" (PoC OR exp OR 漏洞)
site:github.com "<CVE>" (POC OR exploit)

# C. Một công nghệ + loại lỗ hổng (rộng)
("<tech>" OR "<product_cn>") <vuln_cn> 复现
# VD: (Confluence) 远程代码执行 复现

# D. Access-bypass / unauthorized (rất hay có ở TQ)
"<product>" 未授权访问 OR 认证绕过

# E. Bypass WAF cụ thể
<tech> <bypass_target_cn> 绕过
```

Khi gọi WebSearch, **chạy 2-3 query song song** (CVE-raw, tech+vuln-CN, Gitee-PoC) trong
cùng một lượt để phủ rộng.

## 4. Fetch & Extract PoC

Dùng `mcp__web_reader__webReader` với `return_format: markdown` cho top kết quả.
Tìm các marker PoC trong bài TQ:
- `curl` / `POST` / `GET` block → raw HTTP PoC
- `python` / `requests` block → script PoC
- `payload:` / `exp` / `shell` → payload string
- screenshot Burp / HTTP history → request gốc để tái tạo
- `fofa:` / `hunter:` syntax → fingerprint để tìm target (rất phổ biến ở TQ)

## 5. Verify ( Devil's Advocate FP audit — BẮT BUỘC )

Trước khi trình bày PoC, chạy `<poc_simulation>`:
- **Reachability**: endpoint có pre-auth? có bị middleware/WAF chặn method không?
- **Sanitizer**: payload có bị filter/encode trước sink không?
- **Sink**: đúng version/config để gadget/payload kích hoạt? (Fastjson autotype, Shiro key, v.v.)
- **Proxy**: nếu lab → payload phải qua `socks5h://...` + `-k`.

Chỉ báo `CONFIRMED` khi PoC chạy được đến sink. Nếu paper TQ thiếu pre-condition → flag `UNVERIFIED`.

## 6. Tích hợp toolkit lab

- Build **nuclei custom template** từ PoC TQ → đưa vào `toolkit\repos` hoặc `-t ./` khi scan.
- Đối chiếu `searchsploit "<keyword>"` cho exploit DB.
- Đối chiếu `payloadsallthethings` local repo (`D:\Security Research\payloadsallthethings`).

## 7. Output format (trả về user)

```
🎯 <CVE/Tech> — <vuln class> | Severity
1. Nguồn TQ: <platform> <url>  (độ tin cậy Tier S/A/B)
2. Tóm tắt kỹ thuật (1 đoạn): source→sink, điều kiện kích hoạt
3. PoC (verify status): CONFIRMED | UNVERIFIED | PARTIAL
   ```<http/script>```
4. Dorks đã dùng + hit count
5. Khuyến nghị lab: nuclei template / sqlmap flag / proxy note
```

## §Y. Pattern Extraction (after writeup found — mandatory)

**This step is mandatory before exiting cn-0day-hunt.** After finding a writeup that introduces a CONFIRMED or near-CONFIRMED exploit, the skill forces a pattern extraction — what's the bug class, does it exist in the catalog, does it need a new card.

### Y.1 Force prompt

After the writeup is read and the PoC is captured, ask (and do not skip):

```
📋 Pattern extraction:
1. What bug class does this exemplify? (1 line)
2. Match against `catalog/cards/_index.md` — known or novel?
3. If novel → run `bugclass-catalog` DRAFT now (file the card before declaring the hunt done).
4. Extract the exploit primitive signature — file a `primitive-harvest` instance reference (even if no target).
```

This is similar to `vuln-reasoning` §9.1 discard-defense — the user's tendency is to "got the PoC, move on" before pattern is extracted. Force the extraction.

### Y.2 Cross-pollination into English CVE feed

If the writeup is from Chinese sources (tier S/A in §2), the pattern often surfaces in English CVE feeds weeks later (NVD, GHSA). When this happens:

1. Note that `cve-watch` should be alerted when the English CVE lands.
2. Add note to the card: "First observed in cn-sec <date>, public CVE-CANDIDATE English."

This gives the lab a lead-time advantage. Future sweeps that catch the CVE under `cve-watch` can backfill to the card.

### Y.3 Card hygiene

When filing a `bugclass-catalog` DRAFT, **always include** at least one instance reference (writeup URL or CVE). Cards without instances are speculative and should NOT go beyond DRAFT.

A card with:
- 1 instance + 0 cousins → TESTED only after `cousin-sweep` runs.
- 3 instances (multi-vendor) → REUSABLE eligible.
- Card stuck at DRAFT for 14+ days → re-evaluate; SPECULATIVE patterns often don't produce novel cousins.

### Y.4 Anti-pattern

DO NOT exit cn-0day-hunt without:
- `catalog/cards/_index.md` updated (or known-match confirmed), OR
- A clearly written rationale: "writeup did not generalize into a card; treated as one-off CVE."

The "rationale: one-off" is acceptable IF backed by analysis (e.g., "specific regression to version X, no class generalization possible"). Without rationale, exit is incomplete.
