---
name: pwn-arsenal
description: AUTO-INVOKE khi audit native/C/C++/Rust/CUDA component của ML & data-infra target (llama.cpp, opencv, ffmpeg, safetensors, protobuf, CUDA kernel) và gặp bug pwn — heap/stack overflow, integer overflow, UAF, double-free, OOB-RW, type confusion, uninit memory, format string, JIT/sandbox escape. Detection (CodeQL/Semgrep/clang-AST/grep + ASan/MSan/UBSan + libFuzzer/AFL harness) + exploitation primitive + chaining (info-leak → ASLR defeat → RCE). Dùng khi user nói "pwn", "tràn bộ đệm", "tràn heap", "tràn số nguyên", "lỗi nhớ", "use-after-free", "native RCE", "chip native", "heap overflow", "integer overflow", "UAF", "double-free", "OOB", "type confusion", "memory corruption", "native exploit", "ASLR leak", "ROP".
---

# 💀 Pwn-Arsenal — Native/Memory-Corruption Exploitation

Bổ sung "lớp native" cho framework: khi audit codebase ML/data-infra (`llama.cpp`, `ggml`, `opencv`, `ffmpeg`, `pillow`, `safetensors`, `protobuf`, `torch.classes`, CUDA/quantization kernels) và sink là **memory-corruption** chứ không phải web/logic bug. Toàn bộ workflow `redteam-attack` (SQLi/XSS/SSRF/deser Java) không áp dụng được — cần detection + exploitation primitive riêng.

**Nguyên tắc ngược (lab rigor):** một parser bug CHỈ là vuln khi (a) sink chạy trên shipped default config của target, VÀ (b) attacker-controlled file/data tới được sink qua API/handler đang mở. `default ≠ vuln`, `fuzz-crash ≠ RCE`. CONFIRMED cần PoC tới sink với impact quan sát được (register/rip control, file write, info leak ra attacker channel).

## AUTO-INVOKE trigger phrases

| Language | Triggers |
|---|---|
| **VI** | pwn, tràn bộ đệm, tràn heap, tràn stack, tràn số nguyên, lỗi nhớ, use-after-free, double-free, đọc/ghi ngoài vùng, native RCE, chip native, ROP, mã hóa native, leak ASLR, tràn codec, parser GGUF, parser safetensors, kernel CUDA |
| **EN** | pwn, heap overflow, stack overflow, buffer overflow, integer overflow, underflow, UAF, use-after-free, double-free, OOB read/write, out-of-bounds, type confusion, uninitialized memory, uninit read, format string, native exploit, native RCE, ASLR leak, info leak, ROP, JOP, stack pivot, heap groom, tcache poison, fastbin dup, GOT overwrite, vtable hijack, JIT escape, sandbox escape, CUDA kernel OOB |
| **CN** | 堆溢出, 整数溢出, 释放后使用, 内存破坏, 越界读写, 类型混淆, 本地提权, 格式化字符串, 原生漏洞 |

Khi match → fire `pwn-arsenal` + `vuln-reasoning` (cho FP audit) + `primitive-harvest` (capture mọi finding kể cả info-leak Low). Khi CONFIRMED → `bugclass-catalog` (HARD GATE).

## 0. Workflow & tooling baseline

Trước khi săn pwn, setup runtime lab (loopback only, xem `[[lab-builder]]`):

```
# Sanitizers — runtime detection (build target với)
ASAN_OPTIONS=detect_leaks=0:abort_on_error=0:halt_on_error=0
UBSAN_OPTIONS=print_stacktrace=1
MSAN_OPTIONS=halt_on_error=0         # build whole dep chain với MSAN, không thì false positive

# Fuzz harness
libFuzzer: clang++ -g -O1 -fsanitize=fuzzer,address -o harness_fuzz harness.cpp
AFL++:     afl-cc -g -O2 -fsanitize=address -o harness_afl harness.cpp && AFL_IOTTY=1 afl-fuzz -i in -o out -- ./harness_afl @@

# Triage runtime
gdb + pwndbg/gef; pwntools (Python); one_gadget; ROPgadget; ropper; angeaille/gwt
```

Lab container bind `127.0.0.1` ONLY. PoC model file / fuzz corpus KHÔNG expose WAN.

## 1. Class A — Model-file / length-prefixed / TLV parser integer-overflow → heap corruption

**Lab CVE lineage (target family):** GGUF parser (`llama.cpp`/`ggml`) **CVE-2026-27940** + **CVE-2026-33298**; safetensors `__header__` JSON length-prefix; protobuf wire varint overflow; ONNX tensor-shape int-mul overflow. Cmn root cause: đọc `uint32 N` từ file → `malloc(N * elem_size)` → `N * elem_size` wraps (32-bit) → tiny alloc → `memcpy(dst, file, N * elem_size)` overflow.

### 1.1 Detection
```sql
-- CodeQL (C/C++): malloc với size là nhân chưa-checked của input
from FunctionCall malloc, FunctionCall mul, RemoteFlowSource src
where malloc.getTarget().hasName("malloc") and mul = anyMulExpr(malloc.getArgument(0))
  and DataFlow::reaches(src, mul)
select malloc, "malloc với attacker-controlled product size"
```
```yaml
# Semgrep (C/C++) — memcpy với size flow từ file/header
rules:
  - id: gguf-read-into-malloc-no-overflow-check
    languages: [c, cpp]
    patterns:
      - pattern: malloc($N * $SZ)
      - pattern-either:
          - pattern-inside: |
              $N = read_$READ(...);
              ...
      - metavariable-regex: {metavariable: $READ, regex: "u32|u64|i32|i64|uint"}
    message: "Alloc size là nhân chưa checked của input — integer-overflow candidate"
```
```bash
# grep/ripgrep — quick sink survey cho GGUF/protobuf-style parser
rg -n 'malloc\([^)]*\*[^)]*\)' --type cpp src/
rg -n 'fread\([^,]+,\s*[^,]+,\s*[a-z_]+\s*\*\s*[a-z_]+' src/
rg -n 'GGML_API\s+\w+\s+\w+_read|gguf_get_|tensor_nelements' ggml/src/
```
- **ASan**: crash log có `heap-buffer-overflow` + `WRITE of size N at 0x...` + alloc trace → primitive confirmed (write size > alloc size).
- **UBSan**: `unsigned integer overflow` warning ở phép nhân (chỉ là UB với signed; unsigned wraparound là well-defined nhưng là bug nếu dev không intend).

### 1.2 Exploitation primitive
- Tiny-alloc + big-memcpy → **controlled heap overflow**. Groom heap để victim object nằm kế chunk overflowed → overwrite vtable / function ptr / length field.
- Nếu overflow size tính từ file mà attacker kiểm soát hoàn toàn → **write-what-where** relative to heap base.
- Lưu ý: **glibc 2.32+** có safe-linking cho fastbin/tcache → fastbin-dup khó hơn; tcache-key double-free detection (glibc 2.29+) → cần leak tcache-key trước double-free.

### 1.3 Chaining
1. **Parser overflow** (Class A) → heap corrupt → overwrite `free`'d chunk's `fd` ptr (tcache poison) → arbitrary alloc.
2. Kết hợp **info-leak** (Class B hoặc cùng parser có OOB-read) → leak libc / heap base → defeat ASLR.
3. Write GOT/hook (glibc <2.34 `__free_hook`/`__malloc_hook`; glibc ≥2.34 cần `ld.so` GOT hoặc stack-ROP).
4. Control `rip` → one_gadget / ROP-chain → native RCE.
- **Sandbox-sealed target**: nếu target chạy trong seccomp/AppArmor/NoExec heap → RCE khó; downgrade goal thành **info-leak/DoS** và file `primitive-harvest` record với `goal: info-leak`.

## 2. Class B — Image/video codec heap overflow + ASLR-leak

**Lab CVE lineage:** OpenCV JPEG2000 `cdef` (component-definition box) → **CVE-2026-22778** heap-overflow; FFmpeg format demuxer (MOV/MP4/AVI/MKV)家族; PIL/Pillow ASLR-leak qua crafted image; libwebp/HAL (CVE-2023-4863 class — heap-buffer-overflow in `BuildHuffmanTable`). Root cause: codec đọc `num_channels`/`width*height*bpp` từ header nhưng skip validate, alloc undersized, write overflow.

### 2.1 Detection
```bash
# CodeQL: image/codec parser đọc dimension-field rồi alloc
rg -n 'cv::imread|imdecode|av_read_frame|avformat_open_input|PIL.Image.open' .
rg -n 'calloc\(|malloc\(\s*[a-z_]+\s*\*\s*[a-z_]+' modules/imgproc/src/  # opencv
rg -n 'GetCVEssential|opj_\w+_read_header|jas_image' 3rdparty/openjpeg/

# Semgrep — dimension-multiply alloc
patterns:
  - pattern: $ALLOC($W * $H * $BPP)
  - metavariable-regex: {metavariable: $ALLOC, regex: "malloc|calloc|new\\[\\]"}
```
- **ASan + libFuzzer harness** cho `cv::imdecode`/`avformat_open_input`:
```cpp
extern "C" int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
  cv::Mat buf(1, size, CV_8UC1, (void*)data);
  cv::Mat img = cv::imdecode(buf, cv::IMREAD_UNCHANGED);  // target sink
  return 0;
}
```
- **OOB-read = info-leak**: nếu ảnh decode sang `cv::Mat` rồi expose pixel cho API (REST return PNG), leak heap bytes kế chunk → defeat ASLR / leak secret.

### 2.2 Exploitation primitive
- Codec overflow thường là **linear heap overflow** trong decode loop → overwrites neighboring cv::Mat metadata hoặc allocator metadata.
- **ASLR-leak primitive**: OOB-read trong codec → pixel data chứa heap/libc ptr → encode ra PNG/JPG → attacker download → parse LSB → recover ptr. Typical 4-byte leak đủ defeat ASLR on x86_64.
- Một số codec (libwebp Huffman, OpenJPEG t2_decode) có **write-what-where** trực tiếp qua malformed codebook.

### 2.3 Chaining
1. Upload crafted image vào target (`/api/upload`, `/v1/embeddings?image=`, OCR endpoint, model-card thumbnail) → codec overflow.
2. Nếu endpoint return processed image/metadata → leak bytes → ASLR defeated.
3. Second upload → heap-groom + UAF/overflow → control `rip` → RCE.
- **Real-world check ML target:** `vLLM`/`TGI`/`llama.cpp` server thường expose `POST /v1/images` hoặc multimodal endpoint (LLaVA, Qwen-VL) → `cv::imdecode`/`PIL.Image.open` sink trên attacker-controlled PNG/JPG2K.

## 3. Class C — Heap UAF / double-free / OOB-RW / type confusion / uninit / format string

Lớp "classic pwn" — không gắn với 1 parser cụ thể, xuất hiện ở native binding, IPC, JNI, RPC handler, custom allocator.

### 3.1 Detection (per sub-class)

**UAF / double-free:**
```sql
-- CodeQL C/C++: use-after-free (free → use, no re-alloc between)
from DataFlow::NodeSource freed, DataFlow::NodeSource used, Function free
where free.hasGlobalName("free") and free.getArgument(0) = freed
  and used = anyVarUseAfter(freed) and controlledByAttacker(used)
select used, "UAF candidate"
```
```bash
# Semgrep: free rồi return/use ptr
- id: use-after-free-pattern
  patterns:
    - pattern-inside: |
        free($P);
        ...
        return $P;
```
- **ASan** log: `heap-use-after-free` với alloc/free/access stack trace → HIGH confidence primitive.
- **Heartbeat:** object lifecycle trong Python binding (`torch.classes`, `pybind11`) rất hay UAF khi Python GC chạy giữa native call.

**OOB read/write:**
```bash
rg -n '\[[^]]+\]\s*=|ptr\s*\+\s*[a-z_]+|memcpy\([^,]+,[^,]+,\s*\w+\s*\*\s*\w+' src/
```
- Lập index-variable không kiểm bounds (`for (i=0; i<N; i++) dst[i] = src[i]` với `N` từ input, `dst` alloc khác size).

**Type confusion** (C++ vtable, Rust `transmute`, JNI class mixup):
```bash
rg -n 'reinterpret_cast<|static_cast<.*\*>|unsafe\s*\{\s*transmute' src/
rg -n 'dynamic_cast|static_cast<.*class' --type cpp --type rust
```
- clang AST: dump class hierarchy (`clang -Xclang -ast-dump -fsyntax-only`), check `downcast` không guard type-id.

**Uninitialized memory:**
```bash
rg -n 'malloc\(' src/      # malloc không zero; calloc có
rg -n '\w+\s+\w+\s*;' --type cpp | rg -v '=\s*'   # uninit stack/heap var
```
- **MSan**: `use-of-uninitialized-value` →HIGH confidence info-leak (uninit heap byte chứa ptr → leak ASLR).

**Format string:**
```bash
rg -n 'printf\(\s*"[^"]*"\s*,\s*\)' src/   # low-hanging (no arg)
rg -n 'snprintf\([^,]+,\s*[^,]+,\s*[a-z_]+\s*\)' --type cpp   # format = var
rg -n 'fprintf\([^,]+,\s*[a-z_]+\s*\)' src/    # format from var
```
- **printf(attacker_str)** = arbitrary read (%x leak stack, %s leak ptr deref) + write (%n).

### 3.2 Exploitation primitives (matrix)

| Bug | Raw primitive | Chuẩn bị cho chain |
|---|---|---|
| UAF | read/write free'd chunk | tcache poison → arbitrary alloc |
| Double-free | same chunk in freelist twice | fastbin/tcache dup → write-where |
| OOB-write | overwrite neighbor heap object | vtable / len / ptr corruption |
| OOB-read | leak neighbor heap bytes | ASLR leak, secret leak |
| Type confusion | treat object A as B → wrong field offset | fake vtable → PC control |
| Uninit read | leak heap/stack bytes | ASLR leak |
| Format string | arbitrary read + %n write | GOT overwrite, stack write |

### 3.3 Chaining
- **UAF + OOB-leak = full RCE** pattern: leak heap layout (defeat ASLR) → free victim chunk → realloc with attacker data (overlap) → corrupt vtable → control PC.
- **Format string + write = GOT/hook overwrite** → PC control → ROP/one_gadget.
- Vài target (Rust + `unsafe` block, C++ binding cho Python) có **type-confusion → arbitrary ptr deref** → write-where-where (chỉ cần 1 primitive này cho full chain).

## 4. Class D — Native deser / sandbox-JIT escape / CUDA-quantization kernel OOB

Lớp "ML-specific" pwn — không phải codec cũng không phải parser thuần.

### 4.1 Native deserialization (C/C++/Rust side)
- **MessagePack / FlatBuffers / Cap'n'Proto / arrow IPC**: зло khi `read(...)` length-field không check →同类 Class A, exploit path same.
- **PyTorch `.pt`/`.pth` (zip + pickle → C++ unpickler)**: pickle thì Java-skill lo, nhưng `torch.classes.load_library(...)` resolve native `.so` path → nếu attacker control `.so` path = **native lib-load RCE** (file-path controlled).
- **ONNX runtime custom-op registry**: attacker-supplied ONNX trỏ tới `domain="ai.onnx.ml"` op không whitelist → gọi custom kernel → memory-corruption bên trong kernel.

### 4.2 Sandbox / JIT escape
- **Python sandbox** (`RestrictedPython`, `ast.unparse`, IPython `safe_exec`): целью là `__import__`/`ctypes.CDLL`/`os.system` escape → native exec. (Cross-link `[[bypass-arsenal]]` §5, `[[litellm-0day-engagement]]`.)
- **LuaJIT / V8 / JS sandbox trong app native**: FFI escape (`ffi.cdef` + `ffi.load`) → native call → RCE.
- **WASM JIT** (wasmtime/wamr): memory-safety bug trong JIT compiler → host memory corruption. CodeQL pack `misc/library-wasm` ít hơn; đọc git log và CVE feed của wasmtime/wamr thường.

### 4.3 CUDA / quantization kernel OOB
- **CUDA kernel** chạy trên GPU nhưng `cudaMemcpy` kết quả về host → host memory corruption cũng possible. Sink: `cudaMemcpy(dst, dev_ptr, size, cudaMemcpyDeviceToHost)` với `size` attacker-controlled.
- **Quantization kernel** (GPTQ/AWQ/INT4-INT8 dequant): `block_size * num_blocks` integer-overflow → alloc undersized → kernel write OOB trên GPU → cudaMemcpy về host → corrupted host data có thể là info-leak.
- **Triton/openAI kernel** JIT-compile từ Python code → nếu attacker control kernel source (sandboxed eval endpoint) →任意 GPU code → dễ leak/corrupt host.
- **Detection:** CUDA code không có native CodeQL pack tốt; dùng `grep` + manual review:
```bash
rg -n 'cudaMemcpy|cudaMalloc' --type cpp --type cu
rg -n '__global__\s+void' kernels/    # check launch bounds, grid-dim multiply overflow
rg -n 'blockIdx\.x\s*\*\s*blockDim\.x' kernels/   # classic dim-mul overflow
```

### 4.4 Chaining
- Native-deser + `torch.classes.load_library` path-controlled = **1-step native RCE** (load attacker `.so` qua `dlopen`).
- Sandbox escape + JIT bug = remote→host native exec (high-impact, thường Critical).
- CUDA kernel OOB → info-leak host (rare nhưng documented trong NVIDIA advisories).

## 5. Rigor — default ≠ vuln (BẮT BUỘC trước CONFIRMED)

Trước khi gán `CONFIRMED` cho pwn finding, trả lời 6 câu (mở rộng `[[vuln-reasoning]]` §5 cho pwn):

1. **Default reachability**: Sink có chạy trên shipped default config? `#ifdef DEBUG`, `--enable-experimental`, opt-in flag, `requires-auth` đều phải check. Build flag nhận diện: `rg -n 'GGML_USE_\|OPJ_HAVE_\|CUDA_ENABLED' CMakeLists.txt`.
2. **Attacker-controlled input**: File/data có thực sự tới sink qua API đang mở (POST endpoint, IPC, file upload) hay cần local access? "Requires attacker to upload .gguf" = không phải pre-auth nếu API không có upload.
3. **Sanitizer-amplified bug**: Bug chỉ crash với ASan nhưng không exploit trên release build (no sanitizer, optimizations, hardened allocator) → ghi rõ; không nhận `CONFIRMED RCE` chỉ từ ASan crash.
4. **Mitigation reality**: PIE/ASLR/NX/RELRO/stack-canary/FORTIFY hardening level? `checksec binary`. Full RELRO = no GOT overwrite; stack canary = need leak. Đoán RCE mà không check mitigations = overclaim.
5. **Allocator reality**: glibc version (tcache 2.26+, safe-linking 2.32+, drop hooks 2.34+), hoặc `jemalloc`/`mimalloc`/`scudo` (different heap-groom entirely) — exploit technique phụ thuộc hoàn toàn.
6. **PoC to sink with impact**: PoC phải chạy tới sink với observable impact (register control, file write, leak channel). "Fuzz crash" alone = `UNVERIFIED`, không phải `CONFIRMED`.

Default = **bug, không phải vuln**, cho tới khi 6 câu pass. Một `Low` info-leak đã verify vẫn file primitive (xem `[[primitive-harvest]]` — không discard Memory/Crash chỉ vì "không phải RCE").

## 6. Tool integration

| Skill | Relation |
|---|---|
| `[[vuln-reasoning]]` | FP audit (§5 mở rộng cho pwn), hypothesis-driven, taint tracking |
| `[[bypass-arsenal]]` | Khi sanitizer/hardening/filter chặn payload — encoding/parser-diff, heap-feng-shui recipes |
| `[[primitive-harvest]]` | Mọi pwn finding (kể cả info-leak Low) phải file primitive record |
| `[[bugclass-catalog]]` | HARD GATE — CONFIRMED pwn primitive → file card + CodeQL/Semgrep rule (C/C++ pack) |
| `[[lab-builder]]` | Spin vulnerable native app (build với sanitizer, pin commit) để PoC dynamic khi target prod hardened |
| `[[variant-analyzer]]` | Sau khi CONFIRMED GGUF/codec bug → trace lineage sang sibling parser (`ggerganov/llama.cpp` → forks, `transformers.js`, `llama.rn`) |
| `[[cousin-sweep]]` | Bugclass card REUSABLE → sweep cousins (tất cả GGUF consumer, tất cả JPEG2000 caller) |
| `[[cn-0day-hunt]]` | Cộng đồng TQ publish pwn writeup ML/AI model-file nhanh — săn `GGUF漏洞`, `模型文件 RCE` |
| `redteam-recon` / `redteam-fuzz` | Phát hiện API endpoint upload model/image → input vector cho pwn |

## 7. Pivot rules (sau khi CONFIRMED hoặc cạn nhánh)

- **CONFIRMED primitive** → `bugclass-catalog` (rule gen) → nếu REUSABLE → `cousin-sweep`.
- **Static-only stuck ≥1h** (CodeQL/Semgrep không reach sink) → `lab-builder` spin dynamic với fuzzer.
- **2 hypotheses liên tiếp không evidence mới** → pivot sang class khác (Class A→B→C→D) hoặc ghi "hardened, no finding".
- **Heap-groom quá phức tạp** (glibc mới + full RELRO + sandbox) → downgrade goal từ RCE sang info-leak/DoS, file primitive Low-Med.

## Rigor (từ memory `vuln-confirmation-rigor`, `confirmed-claim-gate-checklist`)

- **default ≠ vuln** — sink phải chạy trên shipped default + attacker file/data phải reach sink.
- **Sanitizer-amplified ≠ exploit** — ASan crash với `WRITE size > alloc` là primitive, chưa phải RCE.
- **Mitigation-aware severity** — PIE+RELRO+canary+ NX dropping RCE severity; quoting RCE mà không `checksec` = overclaim.
- **CONFIRMED = PoC tới sink với observable impact** — không fabricate, không đoán gadget.
- **Novelty trước severity** — pwn primitive trong ML native stack thường chưa public; verify chưa có CVE/writeup trước khi claim Critical.
