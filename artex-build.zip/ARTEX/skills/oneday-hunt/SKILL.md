---
name: oneday-hunt
description: >-
  Săn & khai thác 1-day / n-day (CVE đã public nhưng target chưa patch).
  Loop: fingerprint version → query CVE-DB → lọc exploitable → lấy PoC →
  adapt → verify. Dùng khi user nói "tìm 1day", "n-day", "check CVE cho
  target", "xem target lỗi CVE gì", "patch gap". Khác cn-0day-hunt
  (0-day=novel/mới).
---

# 🎯 OneDay-Hunt — Săn & Khai Thác 1-Day / N-Day

**1-day/n-day** = CVE đã public, có PoC/patch, nhưng target chưa cập nhật (patch gap). Khác **0-day** (novel, chưa public → skill `cn-0day-hunt`).
Loop 6 bước — **đi theo thứ tự, đừng nhảy**:

## Bước 1 — Fingerprint CHÍNH XÁC version
→ dùng skill **version-fingerprint**. Mục tiêu: `Tech v=X.Y.Z` (≥2 marker hội tụ).
SAI version = sai CVE. Đây là bước quan trọng nhất.

## Bước 2 — Query CVE theo version
Nhiều nguồn song song:
```powershell
# Local exploit DB
searchsploit "<tech>"                      # rồi lọc theo version
# nuclei — match version tự động trong template
nuclei -u <url> -t cves/ -severity critical,high -j -o cves.json
```
- **NVD/ExploitDB**: filter `affected version range` chứa target.
- **GitHub dorks** (PoC): `"<CVE>" (POC OR exploit) language:python`, `site:gitee.com "<CVE>"`.
- **Blog TQ** (→ skill cn-0day-hunt): `"<tech>" <version> 漏洞 复现`, `"<CVE>" 复现`.
- **Vendor advisory / changelog**: diff version target ↔ patched, tìm CVE đã fix.

Tổng hợp list CVE-ứng-viên kèm version-range.

## Bước 3 — Lọc EXPLOITABLE (không phải mọi CVE đều khai thác được)
Mỗi CVE-ứng-viên, trả lời (skill vuln-reasoning):
1. **Pre-auth?** hay cần cred/auth? (pre-auth giá trị hơn).
2. **Default config** kích hoạt sink? hay cần config đặc biệt (autotype, debug, cụm)?
3. **Có PoC public** sẵn hay chỉ paper? (PoC sẵn = trivial; chỉ paper = cần build).
4. **Dependency/gadget** có sẵn runtime? (deser cần lib cụ thể).
5. **WAF** (wafw00f) có chặn signature không? → cần bypass-arsenal.

Giữ lại top theo `(pre-auth × impact × PoC-ready × default-config)`.

## Bước 4 — Lấy / tái tạo PoC
- Nguồn ưu tiên: **cn-0day-hunt** (blog TQ), GitHub, `payloads-all-the-things` (local repo), `phpggc`/ysoserial (deser), nuclei templates.
- Đối chiếu ≥2 nguồn (tránh PoC sai/lỗi).
- Extract: raw HTTP request / python script / payload string / điều kiện kích hoạt.

## Bước 5 — Adapt PoC cho target
PoC public thường cần sửa cho đúng target:
- **Version diff**: endpoint/param đổi tên giữa bản; gadget khác; payload syntax khác.
- **Config diff**: path khác, port khác, prefix (context-path).
- **Auth**: cần cookie/token (lấy từ skill redteam-bruteforce nếu phải brute).
- **WAF**: payload gốc bị chặn → skill bypass-arsenal.
- **Encoding/charset** của target.

Chạy qua **poc_simulation** (skill vuln-reasoning §4) trước khi ném thật.

## Bước 6 — Verify & classify
- Chỉ báo **CONFIRMED** khi PoC chạy đến sink và sinh ra impact quan sát được (file read trả nội dung, RCE trả `id`/DNS OOB, auth bypass vào được).
- Chạy **FP audit** 5 câu (skill vuln-reasoning §5): framework/typing/reachability/impact/detection.
- Phân loại severity trung thực (CVSS + context thật, không thổi).

## Phân biệt 1-day vs 0-day (quan trọng)
| | 1-day / n-day (skill này) | 0-day (skill cn-0day-hunt) |
|---|---|---|
| CVE | đã có | chưa có |
| PoC | public | chưa public / mới research |
| Patch | đã release | chưa |
| Độ khó | low–medium (copy+adapt) | high (research novel) |
| Trigger | "check CVE cho target" | "săn 0day", "tìm vuln mới" |

**Quy tắc novelty** (memory rigor): nếu khai thác đi vào sink MỚI chưa có CVE → đó là 0-day, chuyển cn-0day-hunt + chứng minh novelty trước khi claim severity cao.

## Cheat-sheet lệnh
```powershell
# Auto 1-day sweep cho 1 host (fingerprint + CVE templates)
nuclei -u <url> -t technologies/ -t cves/ -severity critical,high -j -o 1day.json
searchsploit --nmap <nmap-service-xml>     # match CVE từ scan
# Sau khi có Tech+version -> cn-0day-hunt dork PoC, rồi adapt+verify
```

## Rigor
- Version sai = toàn bộ hunt sai. Đầu tư bước 1.
- nuclei hit ≠ exploit — verify thủ công (skill vuln-reasoning).
- Ghi cặp `version → CVE → PoC → CONFIRMED/REFUTED` để audit & tránh lặp.
