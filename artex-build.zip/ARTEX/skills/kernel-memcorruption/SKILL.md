---
name: kernel-memcorruption
description: >-
  AUTO-INVOKE khi gặp bug memory-corruption trong KERNEL space — Linux kernel (UAF/OOB/race/refcount/int-overflow/uninit/type-confusion/logic) hoặc Windows kernel (pool corruption, Win32k UAF, token swap). Bổ sung lớp kernel cho `pwn-arsenal` (userspace). Phủ: săn 1-day/0-day (patch-mining + syzbot + Coccinelle/CodeQL + syzkaller), triage KASAN/KFENCE → primitive, exploitation-primitive matrix (DirtyCred / DirtyPagetable / DirtyPipe / DirtyFrag / USMA / msg_msg / pipe_buffer / cross-cache / page-level UAF / modprobe_path / cred overwrite / Windows token-swap), mitigation-aware routing (KASLR/SMEP/SMAP/KPTI/kCFI/RANDSTRUCT/HVCI/kCFG/XFG), goal = local privilege escalation. Phủ thêm gateway browser/JS-engine (V8/SpiderMonkey/JSC JIT type-confusion → addrof/fakeobj → V8 sandbox escape → kernel LPE). Dùng khi user nói "kernel pwn", "kernel bug", "LPE", "local privilege escalation", "use-after-free kernel", "nf_tables", "io_uring", "netfilter", "syzkaller", "syzbot", "slab", "pool corruption", "DirtyCred", "DirtyPagetable", "DirtyPipe", "token swap", "cred overwrite", "modprobe_path", "Win32k", "EPROCESS", "提权内核", "内核漏洞", hoặc gateway JS-engine: "V8", "SpiderMonkey", "JSC", "JIT", "browser pwn", "addrof", "fakeobj", "V8 sandbox", "EPT", "code pointer table", "WASM", "Mojo", "Chrome", "Firefox", "JavaScript engine"; sandbox escape: "sandbox escape", "broker process", "Mojo IPC", "Chrome sandbox"; lớp dưới kernel: "VBS", "HVCI", "VM escape", "hypervisor escape", "ESXi", "KVM", "QEMU", "Hyper-V", "SMM", "ring -1", "ring -2", "VSOCKpuppet".
---

# 🧬 Kernel-MemCorruption — Kernel Memory-Corruption Hunt & Exploit

Lớp **kernel-space** cho framework. Khi sink memory-corruption nằm trong **Linux kernel** (slab/SLUB, syscall surface, netfilter, io_uring, bpf, fs) hoặc **Windows kernel** (nt/win32k driver, paged/nonpaged pool, session pool), toàn bộ workflow `pwn-arsenal` (userspace libc/glibc heap, model-file parser) **không áp dụng được** — khác allocator, khác mitigation, khác primitive, khác goal (goal kernel = **local privilege escalation → root/SYSTEM**, không phải RCE-over-network).

> **Phân ranh giới (đọc trước):**
> - `[[pwn-arsenal]]` → userspace native (libc heap, codec, ML model-file, CUDA kernel). Allocator = glibc/jemalloc/mimalloc/scudo. Mitigation = PIE/ASLR/RELRO/canary/FORTIFY.
> - **Skill này** → kernel space. Allocator = SLAB/SLUB/SLOB (Linux) / pool (Windows). Mitigation = KASLR/SMEP/SMAP/KPTI/kCFI/RANDSTRUCT/freelist-hardening (Linux) / kCFG/XFG/HVCI/pool-guard (Windows). Goal = **LPE**.
> - **Browser/JS-engine (V8/SpiderMonkey/JSC)** → **gateway** vào kernel trong thực tế (renderer bug → sandbox escape → kernel LPE = full chain, vd IonStack NebuSec). Cover đầy đủ ở `references/js-engine-exploitation.md`; **chain nối vào skill này ở bước kernel LPE**.

**Nguyên tắc ngược (lab rigor, bắt buộc):** một crash/bug kernel CHỈ là vuln khi (a) sink chạy trên **shipped default config** của target kernel (`CONFIG_*` phải on, không phải `EXPERIMENTAL`), VÀ (b) attacker-controlled syscall/data tới được sink qua quyền attacker **thực có** (thường = unprivileged user, có thể cần `CAP_NET_RAW` — phải reachable qua `user namespace` nếu kernel cho phép `CONFIG_USER_NS`), VÀ (c) primitive sống sót qua mitigation thật của target (KASAN-amplified crash ≠ exploitable). `default ≠ vuln`, `KASAN crash ≠ LPE`. CONFIRMED cần PoC tới sink + observable impact (uid=0 / SYSTEM token / root file write / modprobe_path exec).

## AUTO-INVOKE trigger phrases

| Lang | Triggers |
|---|---|
| **VI** | kernel pwn, bug kernel, lpe, leo thang đặc quyền cục bộ, use-after-free kernel, tràn bộ đệm kernel, slab, pool corruption, nf_tables, io_uring, netfilter, bpf, syzkaller, syzbot, KASAN, DirtyCred, DirtyPagetable, DirtyPipe, token swap, ghi đè cred, modprobe_path, core_pattern, win32k, EPROCESS, leo quyền windows |
| **EN** | kernel pwn, kernel exploit, LPE, local privilege escalation, kernel UAF, kernel OOB, out-of-bounds kernel, slab overflow, SLUB, pool corruption, nf_tables, io_uring, netfilter, netqueue, BPF verifier bypass, syzkaller, syzbot, KASAN, KFENCE, KMSAN, KCSAN, DirtyCred, DirtyPagetable, DirtyPipe, DirtyFrag, USMA, msg_msg, pipe_buffer, cross-cache, page-level UAF, cred overwrite, modprobe_path, token swap, Win32k, EPROCESS token, HVCI, kCFG, XFG, V8, SpiderMonkey, JSC, JIT type confusion, browser pwn, addrof, fakeobj, V8 sandbox, external pointer table, code pointer table, WASM RWX, Mojo, renderer exploit, Chrome, Firefox |
| **CN** | 内核漏洞, 内核提权, 本地提权, 释放后使用内核, 越界读写内核, 内存破坏内核, netfilter 漏洞, io_uring 漏洞, 脏凭证, 脏页表, 脏管道, 权限提升 |

Khi match → fire **skill này** + `[[vuln-reasoning]]` (kernel-edition FP audit §7) + `[[primitive-harvest]]` (mọi primitive kể cả info-leak Low). Khi **CONFIRMED** → `[[bugclass-catalog]]` (HARD GATE). Khi static-only stuck ≥1h → `[[lab-builder]]`/`[[native-lab-toolkit]]` spin kernel VM. Khi ≥2 primitive cùng target → `[[chain-builder]]`.

## 0.5 Lớp browser/JS-engine — gateway vào kernel

JS-engine (V8/SpiderMonkey/JSC) memory-corruption là **cánh cửa #1 vào kernel** thực tế: renderer bug → sandbox escape → kernel LPE = full chain (mẫu **IonStack** NebuSec: V8/SM renderer → netfilter stack-UAF GhostLock CVE-2026-43499 → root ~5s + container escape). Skill cover lớp này vì nó là **gateway** tới kernel sink.

- **Bug class:** JIT type-confusion (TurboFan/Maglev/IonMonkey), bounds-check elimination, ArrayBuffer-UAF, interpreter/JIT differential, Baseline IC confusion. CVE mẫu: **CVE-2025-2135** (V8 TurboFan, Zellic), **CVE-2025-4919** (SpiderMonkey, Pwn2Own, Manfred Paul), **CVE-2025-14325** (SpiderMonkey Baseline IC, qriousec), **CVE-2025-6554** (V8 ITW zero-day).
- **Primitive:** `addrof`/`fakeobj` → corrupt JSArray length/elements/backing-store → **arb-R/W trong V8 cage** → (legacy) WASM RWX shellcode → renderer RCE.
- **V8 sandbox (paradigm shift 2023+, Chrome M110+):** heap ptr compressed + **External Pointer Table** + **Code Pointer Table** + trusted-space → heap corruption **không ra cage** → cần **sandbox escape** (residual raw ptr in `WasmIndirectFunctionTable` / Function native ptr / CPT corruption) **trước** code-exec. ⚠️ Claim "renderer RCE từ V8 bug" mà **không** có sandbox-escape step = **overclaim** trên Chrome modern (rigor).
- **Browser → kernel bridge (3-bug kill-chain, norm 2025):** [1] V8/SM memcorruption → renderer RCE → [2] **sandbox escape** (Mojo bug in browser process / OS sandbox logic) → broker (unsandboxed) RCE → [3] **kernel LPE (skill này)** → root/SYSTEM. Sandbox-escape primitive classes + CVE (CVE-2025-2783 Mojo+Windows, CVE-2025-4609 $250k): `references/browser-sandbox-escape.md`. ⚠️ Sandbox escape ≠ kernel LPE (thoát ra broker userspace, rồi mới cần kernel bug).

Chi tiết engine model + addrof/fakeobj pipeline + sandbox-escape writeups + CVE portfolio + hunt pipeline (patch-gap 1-day, Fuzzilli, AI-assisted): `references/js-engine-exploitation.md`. Watchlist researcher/series (calif MAD Bugs, NebuSec IonStack, saelo, veritas501, qriousec, WillsRoot, Notselwin…): `references/researchers-and-series.md`.

## 0.6 Lớp dưới kernel — VBS/HVCI + hypervisor/SMM (ring −1/−2)

Mở rộng privilege ladder xuống dưới kernel: ring 3 (JS/app) → ring 0 (kernel) → **ring −1 (hypervisor/VMM)** → **ring −2 (SMM)**.

- **VBS/HVCI (Windows, Win11 default):** VTL1 secure-kernel làm kernel `.text` read-only → **không patch/run kernel code** → primitive bắt buộc **data-only** (token swap, data-only SSDT hijack). ⚠️ Claim kernel RCE/`SYSTEM` trên Win11 mà không check HVCI = **overclaim**. Detect: `mitigations-cheatsheet.md`. (HVCI đã note ở `windows-primitives.md`; file này cover bypass strategy: Connor McGarr data-only, CVE-2026-23670 VBS feature bypass, VBS enclave weaponization.)
- **VM escape (guest → host, ring −1):** device-emulation bug (QEMU/KVM/VMX) → write host VMM heap → host RCE → (cloud) hypervisor takeover + tất cả co-located VM. Mẫu: **ESXicape** (3-CVE chain ITW + VSOCKpuppet), CVE-2024-6519 QEMU LSI, ITScape KVM/arm64, Project Zero "EPYC escape", Hyper-V CVE-2025-21333.
- **SMM (ring −2, firmware):** mode cao hơn OS → ring −2 persistence (below-OS, survives reboot-to-OS); BERserk-style SMM handler bug; track UEFI/firmware riêng.

Chi tiết + CVE portfolio + hunt (fuzz device emulation, CHIPSEC): `references/hypervisor-vbs-smm.md`.

## 1. Kernel bug taxonomy + 2024-2026 CVE lineage

Mỗi class: root cause → detection smell → primitive. Chi tiết primitive/technique ở `references/`.

### K1 — UAF / double-free (slab) — **lớp giàu nhất**
- **Root cause:** `kfree`/`kmem_cache_free`/`call_rcu` rồi dùng ptr sau khi object có thể bị reclaim; refcount lệch; quên `put` (`of_node_put`, `module_put`, `fget`); list_del không INIT; RCU grace period sai; work_struct re-init race.
- **Lineage mới:**
  - **CVE-2026-23111** — nf_tables UAF do **logic bug**, patch **xoá đúng 1 dấu `!`**. (lesson: bug logic = memcorruption, không cần overflow.) [writeup: securityaffairs]
  - **CVE-2024-1086** — nf_tables UAF, **double-unbind** của chain → reclaim `nf_hook_entries` → netfilter **arbitrary write**, root bypass toàn bộ họ mitigations Linux ≤6.5. (the-Itch / Notselwin writeup — landmark.)
  - **CVE-2023-32233 / CVE-2023-35001** — netfilter/nft Verifier UAF, OPP-alloc.
  - **io_uring UAF family** (2022-2024, "io_uring là bug factory"): `pbuf_ring`, `bundle UAF` (CVE-2025-* Secway), registered buffers lifecycle.
- **Detection smell:** `rg -n 'kfree|kmem_cache_free|call_rcu'` quanh ptr dùng tiếp; `rg -n 'put_|__put|refcount'` thiếu cặp get/put; Coccinelle `kfree|kmem_cache_free` sau dùng.

### K2 — OOB read/write (stack/array/buffer)
- **Root cause:** index không check bounds; `len`/`count` từ userspace (`copy_from_user`/`get_user`) không validate so với alloc; off-by-one; signed/unsigned mismatch.
- **Lineage mới:**
  - **CVE-2025-37752** "Two Bytes of Madness" (syst3mfailure.io) — **2-byte overwrite** packet sockets → LPE. (lesson: 2 byte đủ, không cần big overflow.)
  - **CVE-2025-38617** — packet socket **race**, cần `CAP_NET_RAW` (**lấy qua user namespace**) → full LPE. (lesson: `CAP_*` reachable-via-userns vẫn = unauth-ish trên distro cho userns.)
  - **CVE-2025-40271** — `proc_readdir_de()` 6.18-rc5 LPE.
- **Detection:** `rg -n 'copy_from_user\([^,]+,\s*[^,]+,\s*[a-z_]+'`; so sánh alloc-size vs copy-size; `rg -n 'for\s*\([^)]*<\s*[a-z_]+'` index biến không bounds.

### K3 — Race / TOCTOU / refcount / RCU
- **Root cause:** double-fetch (copy từ user 2 lần, check lần 1 dùng lần 2); lock discipline sai (`mutex` thiếu, `rcu_dereference` không có `rcu_read_lock`); refcount_t integer overflow (post-refcount_t → leak, không overflow nữa); concurrent ioctl.
- **Lineage:** io_uring bundle-UAF (race), CVE-2025-38617 race, netfilter bind race. KCSAN phát hiện.
- **Detection:** KCSAN report; `rg -n 'copy_from_user.*\n.*copy_from_user'` (double-fetch, multiline); `rg -n 'atomic_t'` thay `refcount_t` (legacy overflow-able).

### K4 — Integer overflow trong size/offset calc
- **Root cause:** `a * b` / `a + b` trong alloc size mà không check overflow (`kmalloc(n*size)` wrap → tiny alloc → memcpy overflow). Giống pwn-arsenal Class A nhưng ở kernel.
- **Detection:** `rg -n 'kmalloc\([^)]*\*|kzalloc\([^)]*\*|vmalloc\([^)]*\*'`; check helper `struct_size`, `array_size`, `size_mul` (kernel có sẵn — thiếu = smell); `rg -n 'size_t|__u32' ` trong size expr.

### K5 — Uninitialized memory → info-leak (KASLR bypass)
- **Root cause:** `kmalloc` (không zero, khác `kzalloc`); struct có padding không init; stack var không init trước khi `copy_to_user`. **Leak kernel pointer = KASLR defeat** → mở đường cho mọi primitive cần address.
- **Lineage mới:** **CVE-2025-21922** — KMSAN uninit PPP socket filter (syzbot). KMSAN bắt.
- **Detection:** MSan/KMSAN `use-of-uninitialized-value`; `rg -n 'kmalloc\(' | rg -v 'kzalloc|memset|memset_after'`; padding trong struct `copy_to_user`.

### K6 — Type confusion (BPF verifier / netfilter ops / vtable)
- **Root cause:** BPF verifier sai判断 cho phép out-of-bound access; `container_of` sai kiểu; netfilter ops table trỏ sai handler.
- **Lineage:** BPF verifier bypass nhiều đợt; nft expr ops.
- **Detection:** BPF verifier commits (git log `bpf/verifier`); `rg -n 'container_of'` misuse; kCFI bắt type-mismatch tại runtime.

### K7 — Logic bug → memory effect (KHÔNG cần overflow!)
- **Root cause:** sai điều kiện logic (`!` thừa/thiếu như CVE-2026-23111), reference counting logic, policy bypass dẫn tới free/reuse sai thứ tự.
- **Lesson quan trọng:** bug này **không bị sanitizer bắt** (không overflow, không OOB) → KASAN silent. Phải đọc logic tay, hoặc runtime hiệu ứng (crash sau khi dùng sai path). Đây là gáy 0-day giá trị cao vì tool miss.

### Windows kernel (bên cạnh K1-K7 chung)
- **Win32k UAF** — **CVE-2025-24983** (Win32k subsystem, CVSS 7.0, 2025). Win32k là bug-rich surface (window manager/GDI/User).
- **Pool corruption** — overflow/UAF trong paged/nonpaged/session pool. **CVE-2021-31956** (NTFS+WNF, NCC Group writeup — WNF reclaim primitive).
- **EPROCESS Token swap** — primitive LPE kinh điển Windows (xem `references/windows-primitives.md`).
- **Win32k flag-OOS** — CVE-2021-1732 (GP0 RCA, exploited in-the-wild).

## 2. Exploitation-primitive matrix (kernel) — "ultimative arsenal"

Đây là **trái tim skill**: map bug-class → primitive → goal, **mitigation-aware**. Quy tắc route: **ưu tiên primitive DATA-ONLY** (cred/modprobe/pagetable/token-swap) trước code-control (vtable/ROP) vì SMEP/SMAP/kCFI/HVCI giết code-control.

| Bug class | Raw primitive | Goal-LPE primitive (ưu tiên ↓) | Chặn bởi mitigation nào |
|---|---|---|---|
| UAF/double-free | reclaim freed slab object | **DirtyCred** (cred swap) / **msg_msg spray+DPT** / pipe_buffer reclaim | kCFI (cho func-ptr path), freelist-hardening (cho same-cache poison) |
| OOB-write (small/2-byte) | partial overwrite neighbour | **cred field overwrite** / modprobe_path / cross-cache reclaim | RANDSTRUCT (hardcoded offset), CFI |
| OOB-read | leak neighbour kernel ptr | **KASLR defeat** → mở route cho mọi primitive khác | ít bị chặn (intrinsic) |
| Race/refcount | UAF-on-demand | reclaim control → DirtyCred / DPT | lockdep/KCSAN (detection, không block) |
| Page-level UAF (free cả slab page) | reclaim page cho **page table** / pipe_buffer | **DirtyPagetable (DPT)** = arb physical R/W | DPT gần như bypass mọi mitigation (data-only) |
| Arbitrary write (full) | write-where-where | **modprobe_path / core_pattern / cred** overwrite | HVCI (Windows, nếu write vào kernel .text) |
| Pipe flag bug | overwrite page cache | **DirtyPipe** (clobber read-only file/setuid) | chỉ ≤5.16.11, patched |
| Page-cache corruption | clobber cached page | **DirtyFrag** (2025, chain 2 CVE) | specific lineage |
| Windows pool overflow/UAF | corrupt neighbour / reclaim | **EPROCESS token swap** → SYSTEM | pool-guard, pool-zero, kCFG/XFG/HVCI |

**Decision tree (chọn primitive):**
```
Có UAF/OOB-write?
├── Object = cred hoặc gần cred        → DirtyCred (swap/overwrite cred) [DATA-ONLY, ưu tiên #1]
├── Free được cả page (slab page)      → DirtyPagetable (reclaim PTE page → arb phys R/W) [DATA-ONLY, #1]
├── Có arbitrary write (đủ range)      → modprobe_path / core_pattern / cred [DATA-ONLY]
├── Object reclaim-able cross-cache    → msg_msg/pipe_buffer spray → build arb-R/W rồi về nhánh trên
├── Có OOB-read trước                  → leak KASLR/struct-layout → bật nhánh cần address
└── Còn lại (cần code control)         → ROP/vtable — CHỈ khi SMEP/SMAP/CFI bypass được (last resort)
```
Chi tiết từng primitive + khi nào sống sót mitigation: `references/linux-primitives.md` (Linux) / `references/windows-primitives.md` (Windows).

## 3. Mitigation reality (routing primitive theo hardening thật của target)

**Phải fingerprint target kernel TRƯỚC khi claim primitive khả thi.** Không đoán. Xem `references/mitigations-cheatsheet.md` cách đọc `/proc`, `/sys/kernel`, `CONFIG_*`, `checksec`-style trên vmlinux.

**Linux (route primitive theo mitigation ON):**
- **SMEP + SMAP** (gần như luôn on x86_64) → ret2user chết → **bắt buộc data-only** (cred/modprobe/pagetable) hoặc kernel-ROP. Đây là lý do DirtyCred/DPT/modprobe_path thống trị post-2020.
- **kCFI / Clang CFI** (CONFIG_CFI_CLANG, kernel ≥6.1, Google production) → indirect-call check type → **vtable/func-ptr hijack chết** → đẩy sang data-only. Paradigm shift chính của 2022-2025.
- **KASLR** (CONFIG_RANDOMIZE_BASE) + **randomize_kstack_offset** (≥5.18) → cần info-leak (OOB-read/uninit) trước primitive cần address.
- **RANDSTRUCT** (CONFIG_RANDSTRUCT) → struct layout random → **hardcoded offset chết** → cần leak layout hoặc dùng field-agnostic (DPT).
- **SLAB freelist hardening** (CONFIG_SLAB_FREELIST_HARDENED: ptr mangle XOR + double-free detect; CONFIG_SLAB_FREELIST_RANDOM) → same-cache freelist poison khó → đẩy sang **cross-cache** / **page-level**.
- **hardened usercopy / FORTIFY / KFENCE** → chặn copy-out-of-slub, phát hiện use-after-free có chủ đích (KFENCE sample).
- **KPTI** (CONFIG_PAGE_TABLE_ISOLATION) → chủ yếu ảnh Meltdown-class leak, ít block LPE path.

**Windows:**
- **HVCI / VBS** (Memory Integrity) → kernel .text read-only qua VTL1 → **không chạy/patch kernel code** → bắt buộc **data-only (token swap)**. Win11 mặc định on nhiều SKU → paradigm shift Windows.
- **kCFG / XFG** → indirect-call guard (XFG = type-based) → func-ptr/code control khó.
- **Pool guard pages + pool zeroing + pool randomization** (Win10 RS5+) → pool overflow/UAF kém reliable → cần reclaim chính xác.
- **KASLR** → cần info-leak (object leak, GDI handle leak).

## 4. Hunt methodology (1-day / 0-day)

### 4.1 Patch-mining (1-day, nhanh nhất) — xem `references/hunting-and-syzkaller.md`
```
# git archaeology trên torvalds/linux
git log --oneline --grep='UAF\|use-after-free\|race\|overflow\|double-fetch' --since='6 months'
git log --oneline --grep='Fixes:' -- <subsystem>/      # fixes-tag = bug thật
# diff commit fix → reconstruct bug → check distro kernel đã patch chưa
git show <fix-commit> -- <path>
```
- Đọc `syzkaller.appspot.com` dashboard (syzbot upstream bugs, nhiều chưa CVE).
- `xairy/linux-kernel-exploitation` master-list (update 2 tháng/lần) — săn writeup mới.
- Vendor advisory: Debian/Ubuntu/RHEL `CVE-2025-*` security tracker, `openEuler`/`MiracleLinux` SA (thường leak root-cause trong patch backport trước upstream disclose).
- **kernelCTF** (Google) — fix lag = bug sống; **CVE-2025-38001** đã compromise LTS+COS (WillsRoot "Syzkaller Summer 2025" — 3/ nhiều bug exploitable).

### 4.2 Static analysis
- **Coccinelle** (kernel có sẵn `scripts/coccinelle/`): `make coccicheck M=<subsystem>` — SmPL patterns cho kfree-dùng-tiếp, refcount, double-fetch, RCU, locking.
- **CodeQL** C/C++ pack + custom query kernel idiom: taint `copy_from_user` → `kmalloc` size; free→use trong cùng function.
- **Semgrep** C: refcount get/put不平衡, `kmalloc` không check `== NULL`, `container_of` misuse.
- **Manual review patterns:** `rg` list ở §1 mỗi class.

### 4.3 Dynamic — syzkaller (0-day engine) — xem `references/hunting-and-syzkaller.md`
- **syzkaller/syzbot** = goldmine. Mở harness cho **syscall surface mới/ít fuzz** (new ioctl, io_uring op mới, bpf cmd mới, netfilter set). Viết `syzlang` description cho resource chưa có.
- Build kernel với `KASAN` (use-after-free/OOB runtime), `KFENCE` (sample-based UAF, nhẹ), `KMSAN` (uninit leak), `KCSAN` (race), `LOCKDEP`. Reproduce crash → giảm reproducer → primitive analysis.
- **Triage crash → primitive:** dùng `[[pwn-triage-toolkit]]` (GDB primitive analysis) trên kernel coredump/vmcore.

### 4.4 Triage pipeline
```
crash (KASAN/KFENCE/syzbot) → loại (UAF/OOB/race/uninit) → reachable từ unpriv? (userns CAP?)
  → primitive candidate (matrix §2) → mitigation target check (§3) → PoC LPE | UNVERIFIED
```

## 5. Rigor — kernel edition (BẮT BUỘC trước CONFIRMED)

Mở rộng `[[vuln-reasoning]]` §5 + `[[confirmed-claim-gate-checklist]]` cho kernel. Trả lời 8 câu:

1. **Default config reachability**: `CONFIG_*` cần thiết có on ở shipped kernel target không? (`CONFIG_NFT_*`, `CONFIG_USER_NS`, `CONFIG_BPF_SYSCALL`, `CONFIG_IO_URING`, `CONFIG_PACKET`). Bug trong module chưa load/built-in ≠ reachable. Đọc `zcat /proc/config.gz` / `boot/config-*` / `CONFIG_*` của distro kernel binary.
2. **Capability reality**: primitive cần `CAP_NET_RAW`/`CAP_SYS_*`? → attacker có lấy qua **user namespace** (`unshare -Ur`) không? Distros Debian/Ubuntu/Fedora: `kernel.unprivileged_userns_clone=1` (mặc định on nhiều distro → CAP-via-userns = unauth-ish); RHEL/WSL2 thường giới hạn → phải verify. Userns off = primitive cần thật CAP = không phải unpriv LPE.
3. **Patch reality**: target kernel version có trong range bị ảnh hưởng không? Check `Fixes:` commit backport status trong distro kernel package. "Mainline vuln" ≠ "distro vuln" (distro backport patch mà không bump version).
4. **KASAN-amplified ≠ exploitable**: crash với KASAN/KFENCE ≠ LPE trên production kernel (no sanitizer). Cần primitive sống sót **không** sanitizer. KASAN inject redzone/quarantine → exploit path khác.
5. **Mitigation reality (§3)**: primitive có sống sót SMEP/SMAP/kCFI/RANDSTRUCT/freelist-hardening (Linux) hoặc HVCI/kCFG/XFG/pool-guard (Windows) của target không? Không check = overclaim.
6. **Allocator/version reality**: SLUB vs SLAB vs SLOB; freelist layout phụ thuộc kernel minor + `CONFIG_SLAB_FREELIST_*`; struct layout phụ thuộc `RANDSTRUCT` seed. Groom recipe version-specific.
7. **Info-leak dependency**: primitive cần KASLR/layout leak? Có leak primitive đi kèm không? Không leak + KASLR on = primitive có thể chết.
8. **PoC to sink + impact observable**: PoC phải tới sink + **uid=0** / root file write / modprobe exec / SYSTEM token. "Kernel panic" = DoS, KHÔNG phải LPE.

Default = **bug, không phải LPE-vuln**, tới khi 8 câu pass. Mọi primitive (kể cả KASLR-leak Low) vẫn file `[[primitive-harvest]]` — **KHÔNG discard** info-leak vì "chưa phải root".

## 6. Tool integration

| Skill | Relation |
|---|---|
| `[[vuln-reasoning]]` | FP audit §5 (mở rộng kernel §5 ở đây), hypothesis-driven |
| `[[pwn-arsenal]]` | Userspace complement — khi sink ở userspace native lib, KHÔNG phải kernel |
| `[[bypass-arsenal]]` | Mitigation bypass recipes (CFI bypass, freelist-hardening bypass, KASLR-leak, HVCI bypass) |
| `[[primitive-harvest]]` | Mọi kernel primitive (kể cả KASLR-leak Low) → file record, không discard |
| `[[bugclass-catalog]]` | HARD GATE — CONFIRMED kernel primitive → card + Coccinelle/CodeQL/Semgrep rule |
| `[[cousin-sweep]]` | Bugclass REUSABLE (vd mọi nf_tables consumer, mọi io_uring op) → sweep cousin kernel/distros |
| `[[variant-analyzer]]` | Đọc 1 nf_tables/io_uring CVE → spread theo vendor lineage (Android kernel, distro kernel, forks) |
| `[[oneday-hunt]]` | Săn 1-day: patch-mining → distro chưa patch |
| `[[lab-builder]]` / `[[native-lab-toolkit]]` | Spin kernel VM (QEMU + gdb + kernel build với KASAN) khi prod kernel hardened |
| `[[pwn-triage-toolkit]]` | Crash triage → primitive analysis (dùng GDB primitive trên vmcore) |
| `[[cn-0day-hunt]]` | Cộng đồng TQ publish kernel LPE writeup nhanh — săn `内核提权`, `nf_tables漏洞` |
| `redteam-fuzz` | Không trực tiếp (kernel fuzz = syzkaller, không phải web fuzz) |

## 7. Pivot rules

- **CONFIRMED primitive** → `[[bugclass-catalog]]` (rule Coccinelle/CodeQL) → REUSABLE → `[[cousin-sweep]]` (sweep cousin kernel module/distros).
- **Static-only stuck ≥1h** (Coccinelle/CodeQL không reach sink) → `[[lab-builder]]`/`[[native-lab-toolkit]]` spin kernel VM + syzkaller dynamic.
- **2 hypotheses liên tiếp không evidence** → pivot class (K1→K7) hoặc subsystem (netfilter→io_uring→bpf→fs) hoặc ghi "hardened, no finding".
- **Primitive bị mitigation chặn (vd kCFI giết vtable path)** → route sang data-only (cred/modprobe/pagetable/token) — KHÔNG bỏ, đổi primitive.
- **Info-leak primitive (Low)** → KHÔNG discard — file primitive, nó mở KASLR-defeat cho primitive khác (chain).

## 8. References (đọc khi trigger)

| File | Khi nào đọc |
|---|---|
| `references/linux-primitives.md` | Build exploit Linux — chi tiết DirtyCred/DirtyPagetable/DirtyPipe/DirtyFrag/USMA/msg_msg/pipe_buffer/cross-cache/page-level/modprobe/cred + decision tree mitigation |
| `references/windows-primitives.md` | Build exploit Windows — pool overflow/UAF reclaim/EPROCESS token swap/WNF/Win32k bitmap + data-only dưới HVCI |
| `references/hunting-and-syzkaller.md` | Săn 1-day/0-day — patch-mining git archaeology, Coccinelle/CodeQL/Semgrep patterns, syzkaller syzlang+harness, KASAN/KFENCE/KMSAN/KCSAN triage, kernelCTF |
| `references/mitigations-cheatsheet.md` | Fingerprint mitigation target — đọc `/proc` `/sys` `CONFIG_*`, check vmlinux; route primitive theo hardening |
| `references/cve-portfolio-2024-2026.md` | Kho bug mới — curated CVE 2024-2026 (root cause + primitive + patch + writeup link) |
| `references/js-engine-exploitation.md` | Lớp browser/JS-engine — V8/SpiderMonkey/JSC bug class, addrof/fakeobj, V8 sandbox escape (EPT/CPT), browser→kernel chain, CVE portfolio 2022-2026, hunt (patch-gap/Fuzzilli) |
| `references/researchers-and-series.md` | Watchlist researcher/blog/series — calif MAD Bugs, NebuSec IonStack, saelo, veritas501, qriousec, WillsRoot, Notselwin, chompie, syst3mfailure, xairy + resource repos |
| `references/browser-sandbox-escape.md` | Mắt xích chain renderer→broker — Chrome/Firefox sandbox + Mojo IPC, sandbox-escape primitive classes, 3-bug kill-chain, CVE (CVE-2025-2783/4609) |
| `references/hypervisor-vbs-smm.md` | Lớp dưới kernel — VBS/HVCI data-only bypass, VM escape (ESXicape/KVM/Hyper-V), SMM ring −2; closes privilege ladder ring 3→0→−1→−2 |

## Rigor (recap — từ memory `vuln-confirmation-rigor`, `confirmed-claim-gate-checklist`)

- **default ≠ vuln** — `CONFIG_*` phải on ở shipped kernel; module phải load/built-in.
- **CAP-via-userns ≠ unconditional** — verify `unprivileged_userns_clone` của distro target.
- **KASAN-amplified ≠ LPE** — primitive phải sống sót không sanitizer.
- **Mitigation-aware routing** — SMEP/SMAP/kCFI/HVCI ép data-only; quote primitive mà không fingerprint hardening = overclaim.
- **CONFIRMED = PoC tới sink + observable LPE** (uid=0 / SYSTEM token) — kernel panic = DoS không phải LPE. Không fabricate, không đoán offset.
- **Info-leak Low vẫn file** — primitive-harvest, mở route cho chain; không discard.

