# Browser Sandbox Escape — the missing chain link (renderer → broker → kernel)

Mắt xích **đang thiếu** giữa renderer RCE (V8/SM, `js-engine-exploitation.md`) và kernel LPE (skill chính). Sandbox = OS-level cage quanh renderer; **sandbox escape** = thoát cage → browser/broker process (đặc quyền, unsandboxed) → từ đó chain sang kernel. **Đây là bước #2 trong kill-chain Chrome 3-bug** (V8 + renderer-priv + sandbox escape).

## 1. Chrome/Firefox process model (cần biết)

| Process | Vai trò | Sandbox |
|---|---|---|
| **Browser (broker)** | unsandboxed/privileged — điều phối, filesystem, network, IPC routing | **KHÔNG sandbox** ← mục tiêu escape |
| **Renderer** | Blink + V8/SM, render page | **Sandboxed** (seccomp/AppContainer/sandboxd) ← V8 bug ở đây |
| **GPU** | GPU compositing, ANGLE/GL | sandboxed (looser) |
| **Network / Utility** | net stack, dịch vụ phụ | sandboxed |

- **Site Isolation:** mỗi origin = renderer riêng → cross-origin renderer-exploit không tự qua trang khác (cần thêm bug).
- **Sandbox OS mechanism:** Linux = seccomp-bpf + namespaces + setuid broker; Windows = AppContainer + restricted token + job object; macOS = sandboxd/TCC.

## 2. Mojo IPC — attack surface chính

**Mojo** = Chrome IPC + IDL (`.mojom`). Renderer (sandboxed) ↔ browser (broker) giao tiếp qua **Mojo interfaces**. Renderer bị compromise → gửi Mojo message độc → **bug trong handler của browser process** = sandbox escape.

- Bug surface: `RenderFrameHost`, `RenderViewHost`, `DesktopMedia`, extensions, file/font/GPU broker, IPC validation.
- Bound check / type confusion / UAF ở **browser-side Mojo receiver** → control broker process.
- **MojoJS bindings:** renderer test API (`MojoJS`) cho phép gọi interface trực tiếp — attacker goal = enable MojoJS trong renderer (defense: [Edge VR "Making Mojo Exploits More Difficult"](https://microsoftedge.github.io/edgevr/posts/Making-Mojo-Exploits-More-Difficult/)).

## 3. Sandbox-escape primitive classes

| Class | Idea | Example |
|---|---|---|
| **Mojo UAF in browser process** | browser free object rồi dùng lại qua Mojo msg → reclaim → control broker | [theori Issue 1062091](https://theori.io/blog/cleanly-escaping-the-chrome-sandbox) |
| **Mojo IDL / IPC confusion** | interface abuse, type confusion qua IDL | [GitHub Sec "Fugitive in Java"](https://github.blog/security/vulnerability-research/the-fugitive-in-java-escaping-to-java-to-escape-the-chrome-sandbox/) |
| **OS sandbox logic flaw** | bug ở **giao nhau** sandbox ↔ OS (Windows) → escape mà không cần broker bug | **CVE-2025-2783** (Mojo + Windows sandbox) |
| **Broker logic bug** | broker cấp quyền file/IPC quá rộng, missing permission check | chrome-sbx-db "Logic Bug" entries |
| **Mojo routing secret leak** | leak message-routing token → gửi msg tới process privileged | [Project Zero "Escaping Chrome Sandbox with RIDL"](https://projectzero.google/2020/02/escaping-chrome-sandbox-with-ridl.html) |
| **GPU/ANGLE path** | GPU process sandbox lỏng hơn → stepping stone | Penligent "ANGLE-V8-Mojo kill chain" |
| **Firefox:** IonMonkey type confusion → escape sandbox | ZDI Pwn2Own 2019 (Niklas Baumstark) | [ZDI](https://www.thezdi.com/blog/2019/12/15/syncing-out-of-the-firefox-sandbox) |

## 4. The kill-chain (3-bug, 2025 reality)

```
[1] V8/SM memory-corruption (js-engine-exploitation.md)
      → addrof/fakeobj → arb-R/W (trong cage) → sandbox escape primitive → RENDERER RCE
[2] SANDBOX ESCAPE (file này)
      → Mojo bug in browser process / OS sandbox logic → BROKER (unsandboxed) RCE
[3] KERNEL LPE (skill chính, §2 primitive matrix)
      → token swap / cred / modprobe → root/SYSTEM
```
- **Praetorian insight (2025):** exploit Chrome production thường cần **3 vuln** (V8 + renderer-priv-escalation + sandbox-escape), không phải 2. Source: [Praetorian exploit-chain analysis](https://www.praetorian.com/blog/exploit-chain-analysis/), [Penligent 2025 kill chain](https://www.penligent.ai/hackinglabs/chrome-2025-zero-days-the-angle-v8-and-mojo-kill-chain/).

## 5. CVE portfolio — sandbox escape 2024-2026

| CVE | Engine/Target | Class | Note |
|---|---|---|---|
| **CVE-2025-2783** | Chrome (Windows) | Mojo + Windows sandbox logic | **ITW**, Chrome <134.0.6998.177. [SecureLayer7](https://blog.securelayer7.net/cve-2025-2783-chrome-mojo-ipc-sandbox/) · [Armis](https://www.armis.com/threat-alert/high-severity-chrome-mojo-sandbox-bypass/) |
| **CVE-2025-4609** | Chrome | critical sandbox escape | **$250K bounty** (largest single Chrome bounty). [OX Security](https://www.ox.security/blog/the-aftermath-of-cve-2025-4609-critical-sandbox-escape-leaves-1-5m-developers-vulnerable/) |
| **CVE-2024-4761** | Chrome | sandbox escape zero-day | public PoC. [Dark Reading](https://www.darkreading.com/vulnerabilities-threats/dangerous-google-chrome-zero-day-sandbox-escape) |
| Issue 1062091 | Chrome | Mojo UAF browser process | [theori](https://theori.io/blog/cleanly-escaping-the-chrome-sandbox) (canonical) |
| (Firefox) | SpiderMonkey | IonMonkey type confusion → escape | [ZDI Pwn2Own 2019](https://www.thezdi.com/blog/2019/12/15/syncing-out-of-the-firefox-sandbox) |

## 6. Hunt & tooling
- **Patch-gap 1-day:** Chrome stable ↔ fix commit (Mojo `.mojom` + browser-process handler diff). `git log third_party/blink/public/mojom/`, `content/browser/`.
- **Static:** audit `.mojom` interface receiver trong browser process (UAF/logic/missing validation); cross-reference IPC handlers với renderer-reachable interface.
- **Dynamic:** enable MojoJS trong renderer (test build) → fuzz interface trực tiếp; syzkaller-style Mojo fuzzer; ClusterFuzz repros.
- **DB:** [allpaca/chrome-sbx-db](https://github.com/allpaca/chrome-sbx-db) — curated sandbox-escape PoCs/exploits.
- **Learn:** theori, GitHub Security, Project Zero, OpZero 101 Chrome (Part 2), Edge VR defense.

## Pattern lessons
1. **3-bug kill-chain là norm 2025** — V8 + renderer-priv + sandbox-escape; săn cả 3 nhánh.
2. **Mojo = attack surface #1** sau renderer RCE; browser-side handler bug = escape.
3. **OS sandbox logic flaw** (CVE-2025-2783) = escape không cần broker bug → intersection bug cao giá trị.
4. **Sandbox escape ≠ kernel LPE** — thoát sandbox ra broker process (unsandboxed userspace), rồi mới cần kernel bug để root. Đừng gộp.
5. **Defense moving target:** site isolation, Mojo hardening, V8 sandbox → chain dài dần → bounty lớn ($250k CVE-2025-4609).
