# Kernel Mitigation Cheatsheet (fingerprint → route primitive)

**Phải fingerprint target TRƯỚC khi claim primitive.** Route primitive theo hardening thật (SKILL.md §3). Không đoán — đo.

## Linux — detect mitigation

| Mitigation | Cách detect | Ảnh hưởng primitive |
|---|---|---|
| **KASLR** (`CONFIG_RANDOMIZE_BASE`) | `cat /proc/cmdline \| grep nokaslr` (có = off); `/sys/kernel/` ; default on x86_64 | Cần info-leak trước primitive cần address (DPT/cred-modprobe/ROP) |
| **SMEP** | `grep smep /proc/cpuinfo` (flag có = on); `cat /proc/cpuinfo` | ret2user chết → kernel-ROP hoặc data-only |
| **SMAP** | `grep smap /proc/cpuinfo` | kernel không read user page (unbugged) → ROP không reference user mem, pivot kernel stack |
| **KPTI** (`CONFIG_PAGE_TABLE_ISOLATION`) | `dmesg \| grep -i kpti`; `/sys/...` | Chủ yếu Meltdown-class leak; ít block LPE path |
| **kCFI / Clang CFI** (`CONFIG_CFI_CLANG`, ≥6.1) | `zcat /proc/config.gz \| grep CFI_CLANG`; kernel built with clang; Google production on | **Indirect call check type → vtable/func-ptr hijack chết → data-only bắt buộc** (paradigm shift 2022-2025) |
| **RANDSTRUCT** (`CONFIG_RANDSTRUCT`) | `zcat /proc/config.gz \| grep RANDSTRUCT`; check `pahole` vs known | Hardcoded struct offset chết → cần leak layout hoặc field-agnostic (DPT) |
| **randomize_kstack_offset** (`CONFIG_RANDOMIZE_KSTACK_OFFSET_DEFAULT`, ≥5.18) | `/proc/sys/kernel/randomize_kstack_offset` (=1 on) | Per-syscall stack offset → ROP stable harder |
| **SLAB freelist hardening** (`CONFIG_SLAB_FREELIST_HARDENED` + `RANDOM`) | `zcat /proc/config.gz \| grep SLAB_FREELIST` | Same-cache freelist poison/ptr-mangle khó → **cross-cache/page-level reclaim** |
| **hardened usercopy / FORTIFY** (`CONFIG_HARDENED_USERCOPY`, `CONFIG_FORTIFY_SOURCE`) | config grep | copy ra khỏi slab object bị chặn |
| **KFENCE** (`CONFIG_KFENCE`) | `/sys/module/kfence/parameters/sample_interval` | Detect UAF có chủ đích (sample) — detection, không block exploit nhưng có thể báo |
| **refcount_t** (vs legacy `atomic_t`) | source; kernel ≥5.x default | refcount overflow → leak (không wrap to 0) → một số primitive bị triệt |
| **static_call / RO .text** (`CONFIG_STRICT_KERNEL_RWX`, static_call) | config | Patch kernel .text (USMA) bị chặn nếu RO text enforced |

### Quick config read
```bash
zcat /proc/config.gz | grep -E 'KASAN|KFENCE|KMSAN|KCSAN|CFI_CLANG|RANDSTRUCT|SLAB_FREELIST|HARDENED_USERCOPY|RANDOMIZE_KSTACK|PAGE_TABLE_ISOLATION|STRICT_KERNEL_RWX|USER_NS|IO_URING|NFT|BPF_SYSCALL|PACKET'
# hoặc
cat /boot/config-$(uname -r) | grep ...
# distro: /lib/modules/$(uname -r)/build/.config
# userns (rất quan trọng cho CAP-reachability):
cat /proc/sys/kernel/unprivileged_userns_clone   # 1=on (Debian/Ubuntu mặc định), 0=off (RHEL/WSL2)
sysctl kernel.unprivileged_userns_clone
```

### checksec-style trên vmlinux
```bash
# KASLR/CFI/RANDSTRUCT presence trên kernel binary:
file vmlinux; readelf -S vmlinux | grep -i cfi
checksec --file=vmlinux   # (nếu có checksec-verbose; PIE/RELRO không apply kernel nhưng flag CFI)
```

## Windows — detect mitigation

| Mitigation | Cách detect | Ảnh hưởng |
|---|---|---|
| **HVCI / VBS** (Memory Integrity) | `bcdedit`; `Get-CimInstance -ClassName Win32_DeviceGuard -Namespace root\Microsoft\Windows\DeviceGuard` (`VirtualizationBasedSecurityStatus`, `CodeIntegrityPolicyEnforcementStatus`); Settings → Device Security → Core Isolation | **Kernel .text RO qua VTL1 → không patch/run kernel code → data-only (token swap) bắt buộc** |
| **kCFG** (kernel Control Flow Guard) | `Get-CimInstance ... CodeIntegrity`; `nt!_KSYSTEM_GATE` flags; Win10+ | Indirect call guard → func-ptr/vtable chết → data-only |
| **XFG** (eXtended CFG, type-based) | build flag; Win11 some | Stricter than kCFG → data-only |
| **KASLR** | default on; `boot.ini`/bcdedit `nokslr` | Cần info-leak (pool/GDI/SystemInformation) trước token swap |
| **Pool guard pages + zeroing + randomization** (Win10 RS5+) | segment-pool behavior; `!pool` WinDbg | Adjacent pool corruption kém reliable → reclaim chính xác (WNF/Bitmap) |
| **SMEP/SMAP** | default on x64 | ret2user chết |
| **SEHOP / stack cookie** | kernel `__security_cookie` | ROP harder |

```powershell
# VBS/HVCI status (PowerShell)
Get-CimInstance -ClassName Win32_DeviceGuard -Namespace root\Microsoft\Windows\DeviceGuard |
  Select-Object VirtualizationBasedSecurityStatus, CodeIntegrityPolicyEnforcementStatus, SecurityServicesConfigured, SecurityServicesRunning
# VirtualizationBasedSecurityStatus=2 (running), SecurityServicesRunning có 2 (HVCI) = HVCI on
bcdedit /enum {current} | Select-String -Pattern 'hypervisorlaunchtype|vsmlaunchtype'
```

## Routing matrix (mitigation → primitive khả thi)

```
MITIGATION ON                     → BLOCK primitive            → ROUTE primitive sống sót
─────────────────────────────────────────────────────────────────────────────────────────
SMEP + SMAP                       → ret2user                   → kernel-ROP / DATA-ONLY (cred/modprobe/DPT/token)
kCFI / XFG (Linux+Win)            → vtable/func-ptr hijack     → DATA-ONLY (cred/modprobe/DPT/Bitmap-data/token)
HVCI/VBS (Win)                    → patch/run kernel code      → DATA-ONLY (EPROCESS token swap) — Win11 default
KASLR                             → primitive cần addr         → thêm OOB-read/uninit LEAK primitive trước
RANDSTRUCT                        → hardcoded offset           → field-agnostic (DPT) hoặc leak layout (pahole target build)
SLAB freelist hardening (Linux)   → same-cache poison          → cross-cache / page-level reclaim
Pool guard/zero/random (Win)      → neighbour corruption       → reclaim chính xác (WNF/Bitmap size-match)
strict .text RO / static_call     → USMA code patch            → data-only primitive khác
```

**Quy tắc:** primitive QUOTE mà không fingerprint mitigation target = **overclaim**. Luôn: đo mitigation (table trên) → route (matrix) → rồi claim.
