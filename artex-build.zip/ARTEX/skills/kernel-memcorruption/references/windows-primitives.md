# Windows Kernel Exploitation Primitives (deep reference)

Mục tiêu Windows kernel = **LPE → NT AUTHORITY\SYSTEM** (khác Linux `uid=0`, Windows dùng **token** trong EPROCESS). Allocator = **NT pool** (paged/nonpaged/session pool, Win10+ segment-based pool). Mitigation = **kCFG/XFG + HVCI/VBS + KASLR + pool guard/zero/random**.

> **Routing rule Windows:** HVCI/VBS (Memory Integrity, Win11 default nhiều SKU) + kCFG/XFG → **không patch kernel .text, không fake indirect call** → **bắt buộc DATA-ONLY (token swap)**. Code-control gần chết trên Win11 production.

## 0. Building blocks

### Pool layout & reclaim primitives
- **Paged pool / Nonpaged pool / Session pool (Win32k)** — Win10 RS5+ dùng **segment-based pool** với guard-ish, randomized, zeroed. Trước đó là classic pool (adjacent object corruption dễ).
- **Spray/reclaim objects:** Named Pipe attributes, ALPC, Registry transactions, **WNF** (Windows Notification Facility — `NtCreateWNF`/`NtUpdateWNFStateData`, robust size-controlled spray), **Bitmap (GDI)** `CreateBitmap` (session pool, classic arb-R/W), `STANDARD_RIGHTS_REQUIRED`.
- **Reclaim size:** Win10+ pool object size phải match victim pool bucket → dùng size-tunable object (WNF/Bitmap/NamedPipe).

### Info-leak (KASLR defeat)
- Leaked kernel pointer qua GDI handle, **NtQuerySystemInformation** (SystemBigPoolInformation/SystemHandleInformation — list pool alloc với addr, **lộ pool addr**; trên version cũ không require privilege; modern hơn cần admin một số class — verify), bitmap surface data, paged-pool tag scan.
- **KASLR on** → cần leak `nt!PsInitialSystemProcess` / SYSTEM EPROCESS addr trước token swap.

## 1. EPROCESS Token swap (DATA-ONLY, ưu tiên #1)
- **Điều kiện bug:** arb-write (hoặc controlled write at known offset) tới `EPROCESS.Token` (Win10/11: token ở offset biến theo build, struct `_TOKEN*` + EX_FAST_REF).
- **Cơ chế:**
  1. Leak KASLR → SYSTEM EPROCESS addr (`PsInitialSystemProcess`).
  2. Đọc SYSTEM `Token` value (qua arb-read primitive, hoặc copy).
  3. Arb-write `Token` của attacker EPROCESS = SYSTEM Token (hoặc spliceToken/overwrite `_EX_FAST_REF` pointer).
  4. Tạo child process → kế thừa SYSTEM token → SYSTEM shell.
- **Sống sót:** HVCI/VBS (data-only — ghi EPROCESS token, không patch .text ✓), kCFG/XFG (data ✓), KASLR (cần leak), pool-guard (reclaim-side, không token-side). → **Sống sót gần hết Win11 production.** Primitive lý tưởng.
- **Pitfall:** Win10 1709+ **token prefix** + Win11 ** hardened token** → dùng `_EX_FAST_REF` pointer swap thay overwrite whole token. Offset token biến theo build → phải đo (`dt nt!_EPROCESS Token`) cho chính xác target build.
- **Reference:** classic token-swap LPE pattern (OffSec LPE series), exploited in-the-wild nhiều lần.

## 2. Pool overflow → adjacent object corruption
- **Điều kiện:** overflow pool object (vd driver ioctl, Win32k object) → overwrite **neighbor pool object** cùng bucket.
- **Pre-RS5:** corrupt neighbour arbitrary → classic. **Post-RS5:** pool guard + randomization + zeroing → cần reclaim chính xác (overflow vào chính object mình spray, không hy vọng neighbour).
- **Cơ chế hiện đại:** overflow không vào neighbour random, mà free+reclaim pattern (như cross-cache Linux) — corrupt size/type field của victim → type confusion → arb-R/W → token swap.
- **Ví dụ:** CVE-2021-1732 (Win32k flag OOS, pool), CVE-2019-1364 (win32k ClearTypeFilter pool font).

## 3. UAF reclaim → type confusion / fake vtable
- **Điều kiện:** free pool object, reclaim với size-matching attacker object (WNF/Bitmap/NamedPipe) → victim dùng lại → type confusion.
- **Trước kCFG:** fake **vtable** (vd GDI object `SURFACE->hdev`/`pSurface` ops) → control PC. **Post-kCFG/XFG:** vtable func-ptr check type → fake vtable chết → chuyển sang **data-only** (corrupt bitmap data pointer → arb-R/W → token swap).
- **GDI Bitmap arb-R/W:** classic primitive — `SetBitmapBits`/`GetBitmapBits` write/read; corrupt `SURFACE->surfobj.pvScan0` (data ptr) → arb-R/W. Post kCFG vẫn dùng được vì **data-only**.

## 4. WNF (Windows Notification Facility) spray/reclaim
- `NtCreateWNFStateName` + `NtAllocateWNFStateData` → spray size-controlled object in paged pool. **Stable reclaim primitive** — dùng thay NamedPipe/Bitmap khi cần size chính xác.
- NCC Group CVE-2021-31956 writeup dùng WNF cho NTFS pool UAF → LPE. Kỹ thuật chính cho modern Windows pool reclaim.

## 5. Win32k-specific surface (bug-rich)
- **Win32k** (`win32k.sys`) = window manager + GDI + User. UAF/type-confusion phổ biến (CVE-2025-24983 Win32k UAF 2025, CVSS 7.0; CVE-2021-1732 flag OOS exploited in-the-wild).
- **Surfaces:** menu (`MENU`), window (`WINDOW`), bitmap/DC, `SetWinEventHook`, `NtUser*` syscalls, font parsing (TTF → pool, CVE-2019-1322/1364 family).
- **Win32k Filter / pool separation** (Win10) giảm classic attack nhưng surface vẫn bug-rich — săn patch-mining win32k.
- **Goal path:** Win32k UAF → WNF/Bitmap reclaim → arb-R/W → token swap.

## 6. Code-control (last resort) — gần chết trên Win11
- **ROP / shellcode trong kernel** → cần bypass **HVCI** (VTL1 enforce kernel .text RO) + **kCFG** (indirect call guard) + **KASLR** + **SMEP/SMAP**.
- **HVCI bypass** khó (cần logic bug trong VTL1/SMM, hoặc exploit data-only). Production Win11 = HVCI on → code-control gần như không khả thi → **data-only (token swap) là default**.
- Chỉ khi HVCI off (legacy/VDI/some SKU) hoặc có HVCI-specific bypass → ROP token steal.

## Decision tree (Windows, mitigation-aware)

```
BUG                              → HVCI on? → PRIMITIVE
────────────────────────────────────────────────────────────────────────
arb-write (any)                  → bất kỳ     → EPROCESS token swap [DATA-ONLY, #1]
Pool overflow / UAF reclaim      → bất kỳ     → GDI Bitmap arb-R/W (corrupt pvScan0) → token swap
WNF/Bitmap size-controlled spray → bất kỳ     → reclaim victim → arb-R/W → token swap
Win32k UAF                       → bất kỳ     → reclaim (WNF/Bitmap) → type-confusion data-only → token swap
vtable/func-ptr (legacy)         → HVCI off   → fake vtable/ROP (last resort, cần bypass kCFG+HVCI)
```

## Tooling
- **WinDbg** (`dt nt!_EPROCESS Token`, `!process`, `!pool`, `!token`), **IDA/Ghidra** trên `ntoskrnl.exe`/`win32k.sys`.
- **HEVD** (HackSysExtreme Vulnerable Driver) — lab học mọi primitive (pool overflow/UAF/UAF-unlink/type-confusion/arb-write) trên driver cố ý yếu — load + exploit local (tắt VBS để học code-control path; bật VBS để học data-only).
- **PIDA / pdbex** — parse PDB lấy struct offset chính xác cho target build.
- **kdmapper / KDU** — load unsigned driver (lab, để inspect/patch). Ngoài scope engagement → chỉ lab.

## Writeup/library nguồn
- NCC Group CVE-2021-31956 (NTFS+WNF pool): https://www.nccgroup.com/.../cve-2021-31956-exploiting-the-windows-kernel-ntfs-with-wnf-part-2/
- GP0 RCA CVE-2021-1732: https://googleprojectzero.github.io/0days-in-the-wild/0day-RCAs/2021/CVE-2021-1732.html
- White Knight Labs 2025 (UAF kernel driver + custom vuln driver): https://whiteknightlabs.com/2025/06/03/understanding-use-after-free-uaf-in-windows-kernel-drivers/
- OffSec Windows kernel LPE: https://offsec.rokibulroni.com/blog/07-windows-kernel-lpe
- CVE-2025-24983 Win32k UAF writeup: https://medium.com/@ajithkumara545454/cve-2025-24983-windows-kernel-use-after-free-vulnerability-explained-...
- SentinelOne vuln DB, exploit-db (classic pool: CVE-2019-1364 win32k).
