# Hypervisor / VBS / SMM — the ring −1 / −2 layer (below kernel)

Lớp **dưới kernel** — mở rộng privilege ladder: ring 3 (app/JS) → ring 0 (kernel) → **ring −1 (hypervisor/VMM, VMX root)** → **ring −2 (SMM, System Management Mode)**. Skill cover vì: (a) **VBS/HVCI** (Windows) đã **thay đổi kernel exploit paradigm** (bắt buộc data-only, đã note ở `windows-primitives.md`), và (b) **hypervisor escape (VM→host)** là primitive kết thúc chain trên cloud/VM (mục tiêu ring −1).

## 1. Privilege ladder & isolation model

```
ring 3   user app / JS renderer          ← pwn-arsenal, js-engine-exploitation
ring 0   OS kernel (Linux/Windows)       ← skill chính
ring −1  hypervisor / VMM (VMX root)     ← file này §3 (VM escape), §2 (VBS/VTL)
ring −2  SMM (firmware, above OS)        ← file này §4
```
- **VMX root/non-root** (Intel VT-x) / **VMX** (AMD-V): hypervisor ở root, guest ở non-root. Escape = guest kernel bug → write host VMM memory → host RCE.
- **VBS (Virtualization-Based Security, Windows):** 2 Virtual Trust Levels — VTL0 (normal kernel) / VTL1 (secure, chạy HVCI/secure-kernel). HVCI = kernel .text **read-only** qua VTL1 → **code execution trong kernel bị chặn** → bắt buộc data-only (token swap).

## 2. VBS / HVCI bypass (Windows) — data-only paradigm

VBS/HVCI on (Win11 default nhiều SKU) → **không patch/run kernel code** → primitive phải **data-only**:

| Strategy | Idea | Source |
|---|---|---|
| **Token swap / EPROCESS credential** | arb-write EPROCESS.Token (data-only, không patch .text) | `windows-primitives.md` §1 (primary) |
| **Data-only SSDT hijack** | manipulate SSDT pointers (data) thay vì hook code | [ExploitPack SSDT hijack under HVCI](https://www.exploitpack.com/blogs/news/bypassing-kernel-code-execution-a-data-only-ssdt-hijack-under-hvci-but-how) |
| **No-code-exec data corruption** | primitive → corrupt data structure (token, ACL, process list) thay vì ROP | [Connor McGarr — No Code Execution? No Problem](https://connormcgarr.github.io/hvci/) ⭐ |
| **VBS feature bypass** | logic flaw trong chính VBS enforcement | [CVE-2026-23670 VBS security feature bypass](https://windowsforum.com/threads/cve-2026-23670-windows-vbs-security-feature-bypass-and-why-it-matters.412648/) |
| **VBS enclave weaponization** | abuse VBS enclave isolation | [Virtualization-Based (In)security: Weaponizing VBS Enclaves](https://www.youtube.com/watch?v=obSm8mv-vmQ) |

> Rigor: claim kernel RCE/`SYSTEM` trên Win11 mà **không** check HVCI = overclaim. Route sang data-only (token swap) khi HVCI on. Detect HVCI: `Get-CimInstance Win32_DeviceGuard` (xem `mitigations-cheatsheet.md`).

## 3. Hypervisor / VM escape (guest → host, ring −1)

Guest kernel bug trong **device emulation** / **KVM kernel module** / **VMX handling** → write host VMM memory → host RCE → (trên cloud) thoát VM → compromise hypervisor + tất cả co-located VM.

### Bug surface
- **QEMU device emulation** (LSI/SCSI, USB, virtio, virglrenderer/GPU, e1000) — UAF/OOB trong emulate.
- **KVM kernel module** (Linux) — VM exit handler, shadow page table, vGIC-ITS (arm64).
- **VMware VMX** sandbox, **Hyper-V** vmbus/hypervisor, **Xen**.
- **AMD SEV / Intel TDX** confidential-VM side (separate track).

### CVE portfolio — VM escape 2024-2026
| Event/CVE | Platform | Class | Note |
|---|---|---|---|
| **ESXicape** (Mar 2025) | VMware ESXi | **3-CVE chain, ITW**, VSOCKpuppet | [Huntress](https://www.huntress.com/blog/esxi-vm-escape-exploit) · [DoublePulsar](https://doublepulsar.com/use-one-virtual-machine-to-own-them-all-active-exploitation-of-esxicape-0091ccc5bdfc) |
| — CVE-2025-22224 (9.3) | ESXi | TOCTOU → OOB write | most severe of trio |
| — CVE-2025-22225 (8.2) | ESXi | arb-write, VMX sandbox → ESXi kernel | |
| — CVE-2025-22226 (7.1) | ESXi | auth bypass / privesc | |
| **CVE-2024-6519** | QEMU | UAF LSI53C895A SCSI HBA | [Red Hat](https://access.redhat.com/security/cve/cve-2024-6519) |
| **ITScape** | KVM/arm64 | vGIC-ITS race → **first KVM/arm64 escape** | [nofire.ai](https://nofire.ai/blog/ITS-arm64-escape) |
| 16-yr KVM UAF | KVM | shadow-page bug → guest→host | [The Hacker News](https://thehackernews.com/2026/07/16-year-old-linux-kvm-flaw-lets-guest.html) |
| **"An EPYC escape"** | KVM (AMD) | VM exit / SEV | [Project Zero — Felix Wilhelm](https://projectzero.google/2021/06/an-epyc-escape-case-study-of-kvm.html) (canonical) |
| **3D Red Pill** | QEMU/KVM virtio | virglrenderer heap overflow (CVE-2019-18389) | [Black Hat Asia PDF](https://i.blackhat.com/asia-20/Thursday/asia-20-Shao-3D-Red-Pill-A-Guest-To-Host-Escape-On-QEMUKVM-Virtio-Device-wp.pdf) |
| **CVE-2025-21333 / 21335** | Hyper-V | critical RCE 2025 Patch Tuesday | WindowsForum |
| **CVE-2024-49117** | Hyper-V | RCE | [SentinelOne](https://www.sentinelone.com/vulnerability-database/cve-2024-49117/) |
| Pwn2Own 2024/2026 | ESXi/Workstation | memcorruption escape | STARLabs SG / VMware patches |

### Primitive & post-exploitation
- **Primitive:** OOB-write/UAF trong device-emulation → corrupt host VMM heap → control host (giống userspace heap exploit nhưng ở VMM).
- **VSOCKpuppet:** sau escape, dùng **vsock** (VM socket, guest↔host channel) để communication/persistence trên host — landmark ESXicape post-exploitation.
- **Goal escalation:** host RCE → (cloud) hypervisor takeover → tất cả co-located tenant VMs = full infra compromise.

### Hunt & resource
- **Fuzz device emulation:** syzkaller virtio descriptions, libAFL/honggfuzz trên QEMU device; KVM selftests.
- **Audit:** QEMU `hw/` device models, KVM `arch/x86/kvm/`, Hyper-V vmbus.
- **DB:** [winmin/awesome-vm-escape](https://github.com/winmin/awesome-vm-exploit) (curated writeups/exploits).
- **Foundational:** [Tencent Keen Lab — "A Bunch of Red Pills: VMware Escapes"](https://keenlab.tencent.com/en/2018/04/23/A-bunch-of-Red-Pills-VMware-Escapes/).

## 4. SMM / UEFI (ring −2, firmware)

System Management Mode = mode đặc biệt của CPU, **cao hơn OS**, chạy code SMM isolated. Attack = exploit SMM handler → **ring −2 persistence** (below kernel, survives reboot-to-OS, Below-the-OS rootkit).

- Bug surface: SMM handler trong UEFI/BIOS (SPI flash), SMRAM protection, SMI handler OOB.
- **BERserk** (MSI firmware) — SMM escape exemplar. Dòng research UEFI/SMM riêng (EDK2, NIST).
- Typically **không** là vector VM-escape trực tiếp; là layer persistence/firmware-separate.
- Hunt: UEFI firmware diff, fuzz SMI handler (Hardware-based fuzzing), CHIPSEC for config audit.

## Pattern lessons (ring −1/−2)
1. **HVCI ép data-only** — Windows kernel exploit dưới VBS = token-swap/SSDT-data, không ROP/code-patch. Cao giá trị primitive còn sống.
2. **VM escape = device emulation bug** — QEMU/KVM/VMX device model là goldmine; primitive giống heap exploit nhưng host-side.
3. **ESXicape = mẫu 3-CVE chain ITW** + VSOCKpuppet persistence — học full guest→hypervisor→tenant chain.
4. **SMM = persistence layer** — below-OS, survives; track riêng firmware/UEFI.
5. **Chain ladder:** V8 → renderer → sandbox-escape → kernel LPE → (HVCI data-only) SYSTEM → (optional) VM escape / SMM. Skill giờ phủ tròn ring 3→0→−1→−2.
