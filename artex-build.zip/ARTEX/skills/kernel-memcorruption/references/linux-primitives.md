# Linux Kernel Exploitation Primitives (deep reference)

Áp dụng sau khi đã (1) xác định bug-class (SKILL.md §1), (2) fingerprint mitigation target (SKILL.md §3 / `mitigations-cheatsheet.md`). Mỗi primitive: **điều kiện bug** → **cơ chế** → **sống sót mitigation nào** → **flow tối thiểu**.

> **Quy tắc routing tuyệt đối:** ưu tiên **DATA-ONLY** (cred / modprobe_path / core_pattern / pagetable) trước code-control (vtable / ROP). Lý do: SMEP+SMAP giết ret2user, kCFI giết vtable/func-ptr — code-control chỉ là last resort.

## 0. Building blocks (dùng chung cho mọi primitive)

### msg_msg spray — primitive reclaim + arb-read nền tảng
- `msgsnd(msqid, msg, size, 0)` → kernel alloc `struct msg_msg` (48B header x86_64) + 1 list `msg_msgseg` (8B next + data) nếu size > DATALEN_MSG (~4048B). **Kích thước attacker-controlled** → spray reclaimed object bất kỳ size phù hợp.
- **Arb-read trick:** UAF một `msg_msg` → overwrite `msg_msg.m_ts` (message size) + `next` ptr (→ fake `msg_msgseg`) → `msgrcv` copy ra **beyond data** = **arbitrary kernel read**. Trụ cột nearly mọi modern arb-read.
- **Arb-write:** dùng `msg_msg` reclaim victim, ghi data qua `msgsnd` → overwrite victim field.

### pipe_buffer reclaim — reclaim 40B + func-ptr path
- `pipe()` + `splice()` → alloc `struct pipe_buffer` (40B) mảng; `ops` ptr trỏ `anon_pipe_buf_ops` (func-ptr). Reclaim freed object bằng pipe_buffer → control `ops` → **func-ptr control** (cần bypass kCFI) hoặc dùng cho arb-free (`pipe_buf_release`).
- Dùng trong DirtyPipe (CVE-2022-0847) family. Post-kCFI: pipe_buffer path chuyển sang data-only thay vì ret `ops->release`.

### cross-cache reclaim — vượt ranh cache
- Freelist hardening (CONFIG_SLAB_FREELIST_HARDENED) làm same-cache poison khó. **Cross-cache:** drain cache A (free hết object → page trả về page allocator) → reclaim page cho cache B (đúng size/order) → object A giờ là object B (type confusion across cache).
- Cần control heap để drain: `setxattr`/`msgsnd`/`add_key` để fill slab. Đây là **default primitive** post-2022 (sau freelist hardening).

### page-level UAF — vượt mọi per-cache protection
- Free **cả slab page** (không chỉ object) → page về page-allocator → reclaim cho **page table** (PTE page → DirtyPagetable), pipe_buffer, hay msg_msg page.
- Bypass cả freelist-hardening lẫn cache separation (vì ở page-allocator level). **Primitive mạnh nhất** hiện đại.

## 1. DirtyCred — cred swap/overwrite (DATA-ONLY, ưu tiên #1)
- **Điều kiện bug:** UAF hoặc OOB-write tới object chứa/trỏ `struct cred` (vd free một `file`/`msg_msg`/`cred` rồi reclaim).
- **Cơ chế (2 variant):**
  - **Swap:** chạy 2 thread — (A) unpriv process mở file read-only → `struct file` với `f_cred` unpriv; (B) privileged process. Free `file` A, reclaim bằng `file` B privileged → khi A dùng lại `file` (đã bị swap) → A mang cred của B. Hoặc swap `struct cred` trực tiếp.
  - **Overwrite:** arb-write đè `cap_effective`/`uid`/`euid` trong cred hiện tại.
- **Sống sót:** KASLR (không cần address nếu swap-only), SMEP/SMAP (data-only), kCFI (không func-ptr), freelist-hardening (dùng cross-cache/page-level reclaim). → **Sống sót gần như mọi mitigation production 2024-2026.** Đây là primitive lý tưởng.
- **Flow:** bug → cross-cache/page-level reclaim `struct file`/`cred` → swap/overwrite → `setuid(0)`/`commit_creds(prepare_kernel_cred(0))` hoặc đơn giản `open("/etc/shadow")` thành công.
- Paper: Z. Lin "DirtyCred" (Black Hat) — [pdf](https://zplin.me/papers/DirtyCred.pdf). CVE mẫu: CVE-2022-2588 (route4_change UAF → DirtyCred).

## 2. DirtyPagetable (DPT) — arb physical R/W qua PTE (DATA-ONLY, #1)
- **Điều kiện bug:** page-level UAF — free một page mà sau đó reclaim được thành **page-table page** (PTE/PMD).
- **Cơ chế:** reclaim freed page làm PTE page → attacker kiểm soát nội dung PTE → ánh xạ **bất kỳ physical page nào** vào userspace → arb physical read/write. Từ đó ghi `cred`/`modprobe_path`/bất cứ đâu.
- **Sống sót:** KASLR (DPT tìm phys page bằng cách scan, hoặc combine leak), SMEP/SMAP (data-only, không exec user page), kCFI (data), RANDSTRUCT (truy cập phys trực tiếp không care layout), freelist-hardening (page-level). → **Gần như bypass toàn bộ** — "universal primitive".
- **Khó khăn:** cần page-level free + đúng timing reclaim page-table. Recipe phức tạp (xem writeups: "Dirty Pagetable" series).
- **Flow:** page-level-UAF bug → groom để freed page trở thành PTE → ghi PTE trỏ tới cred/modprobe page → arb write → LPE.

## 3. modprobe_path / core_pattern overwrite (DATA-ONLY, khi có arb-write)
- **Điều kiện bug:** arb-write (hoặc arb-write đủ range) tới known symbol.
- **Cơ chế:**
  - `modprobe_path` (`/sbin/modprobe` string in kernel) → overwrite thành `/tmp/x` → trigger `unknown binfmt` exec (chạy file với magic lạ) → kernel run `/tmp/x` **as root** → LPE.
  - `core_pattern` (`|/path` ) → crash một process → kernel pipe exec `/path` as root.
- **Sống sót:** KASLR (cần leak `modprobe_path` addr — `KASLR` on → cần leak), SMEP/SMAP/kCFI (data-only), HVCI Linux? (không có). → Sống sót khi đã có arb-write + KASLR leak.
- **Flow:** arb-write primitive (từ cross-cache/msg_msg/pipe/DPT) → leak modprobe_path addr → overwrite → trigger binfmt → root.

## 4. cred overwrite trực tiếp (DATA-ONLY)
- **Điều kiện:** arb-write tới `current->real_cred`/`cred` → set `uid=euid=fsuid=0`.
- Cần leak addr của `current` task's cred (KASLR + `task_struct` layout — RANDSTRUCT cản). DPT route dễ hơn (scan phys page tìm cred pattern).

## 5. DirtyPipe — CVE-2022-0847 (page-cache clobber, lineage cụ thể)
- **Điều kiện bug:** `PIPE_BUF_FLAG_CAN_MERGE` flag còn set trên pipe buffer sau splice → khi `write()` vào pipe, ghi đè **page cache** của file được splice vào (kể cả read-only file).
- **Cơ chế:** splice file read-only vào pipe → `write` pipe → clobber page cache → ghi đè `/etc/passwd` hoặc setuid binary → LPE.
- **Patch ≤5.16.11** (fixed). Linage riêng, không general primitive — nhưng lesson: **page-cache = writable surface**.

## 6. DirtyFrag — 2025 page-cache chain (lineage mới)
- Chain **2 CVE** để corrupt **page cache** → escalate root. (edera.dev writeup "Dirty Frag: The Linux Kernel Exploit That Turns Your Page Cache Against You".)
- Lesson: page-cache corruption là họ primitive đang phát triển 2025 — theo dõi để thêm vào portfolio.

## 7. USMA — User-Space Mapping Attack (data-only code patch)
- **Điều kiện:** primitive map **kernel page** vào userspace (qua bug cho phép `vm_area_struct`/PTE manipulation) → patch **kernel .text từ userspace**.
- Vượt SMEP/SMAP (vì kernel code nằm ở kernel addr, không phải user page) — bản chất **patch code kernel**, không exec user code. Nhưng nếu **kCFI/static_call** enforce immutable .text → chặn (read-only text, `CONFIG_STRICT_KERNEL_RWX`).
- (r1ru.github.io USMA series.) Dùng khi data-only không đủ và .text chưa immutable.

## 8. Code-control (vtable / ROP) — LAST RESORT
- **Điều kiện:** có func-ptr control (vd pipe_buffer `ops`, vtable) HOẶC stack pivot.
- **Bypass cần:** SMEP (ROP trong kernel, không ret user), SMAP (không read user page từ kernel ROP — pivot tới kernel stack), kCFI (indirect call check type → cần call target đúng type, hoặc bypass CFI), stack-canary (kernel has `CONFIG_STACKPROTECTOR_STRONG`).
- **Flow:** leak KASLR + kernel base → ROP chain (commit_creds(prepare_kernel_cred(0))) → kpti trampoline return userspace → uid=0.
- Chỉ khi mọi data-only path bị block (hiếm, vì DPT/cred hầu như luôn khả thi).

## Decision tree (recap — chọn primitive theo bug + mitigation)

```
BUG                                  → KASLR on? → MITIGATION        → PRIMITIVE
─────────────────────────────────────────────────────────────────────────────────
UAF cred/file-adjacent               → không cần   → bất kỳ            → DirtyCred (cred swap)
UAF page-level (free cả page)        → leak help   → bất kỳ            → DirtyPagetable (PTE→arb phys R/W)
OOB-write small (2-byte/partial)     → leak addr   → RANDSTRUCT chặn   → cred partial / cross-cache
arb-write full                       → leak addr   → data-only ok      → modprobe_path / core_pattern / cred
OOB-read                             → self-leak   →                   → KASLR defeat → mở route cho primitive trên
Race/refcount → UAF-on-demand        → như UAF     → như UAF           → DirtyCred/DPT
pipe flag (lineage ≤5.16.11)         → không cần   →                   → DirtyPipe (page cache)
vtable/func-ptr control              → leak base   → kCFI chặn         → (last resort) ROP if kCFI bypassed
```

## Grooming helpers (recipe chung)
- **Spray size N:** `msgsnd` (msg_msg, ~48B+), `add_key` (user_key_payload), `setxattr` (tmp buffer, transient), `sendmsg` (sk_buff), `pipe`+`splice` (pipe_buffer), `socket`+`setsockopt` (various).
- **Drain (cross-cache):** free toàn bộ object cache → spill page → page-allocator reclaim.
- **Stable reclaim:** pin object (vd giữ msg_msg không free) → race determinism.
- **Tool:** `pahole` (struct layout/offset, nhưng RANDSTRUCT → cần target's actual build), `vmlinux-to-elf` (strip KASLR symbols), `ropper`/`ROPgadget`/`pwntools` cho ROP, kernel `gdb` scripts (pwndbg kernel mode).

## Writeup/library nguồn (theo dõi liên tục)
- xairy/linux-kexploi­tation master-list (2-tháng/lần update): https://github.com/xairy/linux-kernel-exploitation
- the-Itch / Notselwin (CVE-2024-1086 nf_tables), syst3mfailure (CVE-2025-37752), WillsRoot (Syzkaller Summer 2025 / CVE-2025-38001), r1ru (USMA, modern technique), chomp.ie (io_uring), lkl, ret2.
