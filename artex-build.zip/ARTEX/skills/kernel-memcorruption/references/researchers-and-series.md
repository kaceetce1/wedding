# Researchers, Series & Blogs — Kernel + Browser Memory-Corruption (watchlist)

Ai-publish-gì, để săn nhanh + học pattern. Organized theo: **(A) AI-driven kernel bug labs** (calif, NebuSec), **(B) individual kernel researchers**, **(C) browser/JS-engine researchers**, **(D) resource repos/collections**, **(E) org/vendor blogs**. Cập nhật định kỳ.

> Rigor: mọi entry verify link thật. Handle chưa xác định → ghi `UNVERIFIED`, không bịa.

## A. AI-driven kernel bug-hunting labs (mảng đang bùng 2025-2026)

### calif — "MAD Bugs" series (blog.calif.io) ⭐
- AI (Claude/LLM) discover + writeup kernel bug. Hub: https://blog.calif.io/t/madbugs
- Chạy bởi thaidn (@XorNinja, @calif_io).
- Entries: "An AI Audit of FreeBSD" (3 LPE incl. setcred), **"First public macOS kernel memory corruption exploit"**, "MAD Bugs: All Your Reverse Engineering", **"A Race Within A Race — Exploiting CVE-2025-38617"** (packet socket race → LPE, xem `cve-portfolio-2024-2026.md`).
- **Lesson:** LLM-assisted patch-diff/hunting đang trở thành channel chính → theo dõi liên tục.

### NebuSec (Nebula Security) — "IonStack" chain + "VEGA" pipeline ⭐
- YC-backed. Browser→kernel full-chain + AI pipeline "VEGA". Blog: https://nebusec.ai/research/ · buglist: https://nebusec.ai/buglist/ · GitHub: https://github.com/NebuSec/CyberMeowfia
- **CVE-2026-43499 "GhostLock"** — stack-UAF 15 năm (mọi distro từ 2011), root ~5s + **container escape**. Writeup: https://nebusec.ai/research/ionstack-part-2/
- **CVE-2026-23274** — netfilter `xt_IDLETIMER` uninit → kernelCTF **$10.5k bounty**. Chain: prefetch leak → kernel base → kmalloc-256 payload.
- **IonStack = mẫu browser→kernel chain** (đối tượng học cho `js-engine-exploitation.md` §bridge).

### Wiz Research
- **CVE-2026-46300 "Fragnesia"** — ESP-in-TCP LPE. **CVE-2026-31431 "Copy Fail"** — logic flaw since 2017.
- Pattern: đặt tên codename cho chain (giống IonStack/DirtyCred) — dễ track lineage.

## B. Individual kernel researchers

| Handle/Blog | Known for | Link |
|---|---|---|
| **WillsRoot** (William Liu) | kernelCTF, "Syzkaller Summer 2025" (CVE-2025-38001), Android/kernel exploit | https://www.willsroot.io |
| **Notselwin / the-Itch** | CVE-2024-1086 nf_tables arb-write (landmark modern LPE) | (writeup via xairy list) |
| **syst3mfailure** | "Two Bytes of Madness" CVE-2025-37752 (2-byte LPE) | https://syst3mfailure.io |
| **chompie** | io_uring UAF LPE walkthrough | https://chomp.ie |
| **r1ru** | USMA, modern kernel technique (data-only code patch) | https://r1ru.github.io/categories/linux-kernel-exploitation/ |
| **xairy** | master-list kernel exploitation (update 2 tháng/lần) — STARTING POINT | https://github.com/xairy/linux-kernel-exploitation |
| **lkl / ret2 / hxp** | CTF + kernel writeups | varies |

## C. Browser / JS-engine researchers

| Handle/Blog | Known for | Link |
|---|---|---|
| **saelo** (Samuel Groß, Google V8 sec) | **"Attacking JavaScript Engines"** (Phrack 0x47 — canonical), V8 Heap Sandbox (OffensiveCon 2024), Ignition/TurboFan exploitation | https://saelo.github.io · https://saelo.github.io/presentations/offensivecon_24_the_v8_heap_sandbox.pdf |
| **veritas501** | browser pwn tutorials (35C3 Chrome, canonical foundation) | https://veritas501.github.io |
| **qriousec** | SpiderMonkey CVE-2025-14325 (Baseline JIT inline-cache type confusion, AI-assisted fuzzing) | https://qriousec.github.io/post/cve-2025-14325/ |
| **Manfred Paul** | Pwn2Own Firefox (CVE-2025-4919 IonMonkey) | https://www.thezdi.com/blog/2025/7/14/cve-2025-4919-corruption-via-math-space-in-mozilla-firefox |
| **jhalon** | "Chrome Browser Exploitation" series (V8 intro → exploit) | https://jhalon.github.io/chrome-browser-exploitation-1/ |
| **Anvbis** | "Code Execution in Chromium's V8 Heap Sandbox" | https://anvbis.au/posts/code-execution-in-chromiums-v8-heap-sandbox/ |
| **theori** | V8 sandbox escape in ITW exploit (WasmIndirectFunctionTable raw ptr) | https://theori.io/blog/a-deep-dive-into-v8-sandbox-escape-technique-used-in-in-the-wild-exploit |
| **Numen Cyber (Wang Ding Qian)** | V8 sandbox bypass via Function native pointer (issue 1378239) | https://medium.com/@numencyberlabs/use-native-pointer-of-function-to-bypass-the-latest-chrome-v8-sandbox-exp-of-issue1378239-251d9c5b0d14 |
| **Zellic** | "Pwning V8CTF" CVE-2025-2135 TurboFan type confusion | https://www.zellic.io/blog/pwning-v8ctf |
| **Hackyboiz** | Chrome exploitation series (TurboFan type confusion, 2025) | https://hackyboiz.github.io/2025/09/26/OUYA77/Chrome_part3/en/ |
| **m1ghtym0** | browser-pwn curated repo (Chromium/Firefox/Safari/Edge) | https://github.com/m1ghtym0/browser-pwn |
| **xv0nfers** | V8-sbx-bypass-collection (sandbox escape/violation links) | https://github.com/xv0nfers/V8-sbx-bypass-collection |

> **"Wix"** — UNVERIFIED: handle/blog chưa pin được qua search (không bịa). Có thể user ý researcher khác (jhalon/Numen/…). Khi clarify handle thật → add vào bảng. (Rigor `UNVERIFIED`, không fabricate.)

## D. Resource collections & org blogs

| Source | Value | Link |
|---|---|---|
| **Project Zero — In-the-Wild series** | canonical addrof/fakeobj V8 ITW analysis | https://projectzero.google/2021/01/in-wild-series-chrome-exploits.html |
| **V8 official sandbox doc** | EPT/code-pointer-table design (defender view) | https://v8.dev/blog/sandbox |
| **yaklang/hack-skills** | browser-exploitation-v8 skill (pipeline/addrof/fakeobj/WASM/sandbox) | https://github.com/yaklang/hack-skills/blob/main/skills/browser-exploitation-v8/SKILL.md |
| **SpecterOps — V8 Heap Archaeology (2026)** | forensic artifacts of V8 exploits (detection/defense + understanding) | https://specterops.io/blog/2026/02/11/v8-heap-archaeology-finding-exploitation-artifacts-in-chromes-memory/ |
| **GitHub Security Blog** | CVE-2023-3420 V8 JIT side-effect (canonical RCE-in-renderer) | https://github.blog/security/vulnerability-research/getting-rce-in-chrome-with-incorrect-side-effect-in-the-jit-compiler/ |
| **ZDI blog** | V8 JIT intro ("Two Birds One Stone") + Pwn2Own writeups | https://www.thezdi.com/blog/2021/12/6/two-birds-with-one-stone-an-introduction-to-v8-and-jit-exploitation |
| **syzbot dashboard** | upstream kernel bugs (1-day goldmine) | https://syzkaller.appspot.com/ |
| **kernelCTF** | Google bug-bounty, fix-lag = bug sống | https://google.github.io/security-research/kernelctf/ |
| **MetaXploit (2025)** | paper — exploit "previously unexploitable" kernel bugs | https://lujie.ac.cn/files/papers/MetaXploit.pdf |

## E. Theo dõi định kỳ (cadence)
- **Hàng tuần:** xairy list, nebusec.ai/research, blog.calif.io/t/madbugs, syzbot dashboard, oss-security.
- **Hàng tháng:** Project Zero tracker, ZDI Pwn2Own, OffensiveCon/BlackHat materials, kernelCTF submissions.
- **Trigger event:** Chrome/Firefox stable patch-gap (ITW zero-day → 1-day window), kernel CVE with `Fixes:` tag pre-distro-backport.
