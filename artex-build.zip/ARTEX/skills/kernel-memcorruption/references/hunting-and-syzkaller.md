# Hunting 1-day / 0-day kernel memory-corruption (deep reference)

3 engine: **patch-mining** (1-day, nhanh nhất, distro chưa patch), **static analysis** (Coccinelle/CodeQL/Semgrep, chủ động), **syzkaller/syzbot** (0-day, fuzz). Tích hợp `[[oneday-hunt]]` cho 1-day, `[[cn-0day-hunt]]` cho writeup TQ.

## A. Patch-mining (1-day)

### A.1 Git archaeology trên torvalds/linux
```bash
# clone full history (shallow không đủ cho archaeology)
git clone https://git.kernel.org/pub/scm/linux/kernel/git/torvalds/linux.git

# fix-commit theo pattern bug-class (Fixes: = bug thật, có commit gốc để reconstruct)
git log --oneline --grep='use-after-free\|UAF\|double free\|race condition\|out-of-bounds\|overflow\|double-fetch\|uninitialized' --since='12 months ago' -- <subsystem>/

# trace chain Fixes: → gốc
git log --oneline --grep='Fixes:' -- net/netfilter/   # vd nf_tables
git show <fix-commit>                                 # xem patch = mô tả bug
git log --oneline <fix-commit>^..<fix-commit>         # context

# subsystem giàu bug (target ưu tiên)
net/netfilter/  net/ipv4/  io_uring/  kernel/bpf/  fs/  drivers/  mm/  net/packet/
```

### A.2 Tái dựng bug từ patch
1. Đọc diff fix → xác định **root cause** (free-dùng-tiếp, race, overflow, logic `!`).
2. Checkout commit **trước fix** (`git checkout <fix>^`).
3. Build kernel affected → verify bug tồn tại (reproduce crash với reproducer syzbot hoặc tự viết).
4. Map bug → primitive (SKILL.md §2) → check distro đã backport patch chưa.

### A.3 Check distro backport (bug còn sống không?)
```bash
# Debian/Ubuntu: package changelog có CVE + upstream commit backport
apt changelog linux-image-$(uname -r) | grep -i 'CVE-2025\|CVE-2026'
# Ubuntu security: ubuntu.com/security/cves
# RHEL: access.redhat.com/security/data/csaf
# openEuler/MiracleLinux/Android: SA thường leak root-cause trong patch TRƯỚC upstream disclose (goldmine)
# Android kernel: source.android.com/docs/security/bulletin + AOSP common kernel branch
```
**Insight:** distro backport patch mà **không bump version** → `uname -r` trông cũ nhưng đã fix. Phải check changelog/CSAF, không check version.

### A.4 Feed patch-mining
- **syzkaller.appspot.com** — upstream bugs syzbot, nhiều chưa có CVE (syzbot reproducer public → 1-day golden).
- **xairy/linux-kernel-exploitation** master-list (2-tháng/lần): https://github.com/xairy/linux-kernel-exploitation
- **kernel.org CVE feed** / **NVD kernel filter** / `cve.org` CNA list (kernel CNA).
- **Google kernelCTF** — fix lag intentional = bug sống; exploit submit bounty.

## B. Static analysis

### B.1 Coccinelle (kernel có sẵn SmPL)
```bash
make coccicheck M=net/netfilter/ MODE=report     # chạy patterns builtin
# scripts/coccinelle/ có: kfree, null-assign, refcount, double-fetch, RCU, locking, pool
# custom SmPL cho pattern mới — viết .cocci file
```
Coccinelle mạnh cho **free-dùng-tiếp, refcount get/put, RCU discipline, locking** — semantic, ít FP hơn regex.

### B.2 CodeQL (C/C++ pack + custom kernel query)
```sql
-- copy_from_user size flow vào kmalloc không check overflow
from FunctionCall cfu, FunctionCall alloc, RemoteFlowSource src
where cfu.getTarget().hasName("copy_from_user")
  and alloc.getTarget().hasName(["kmalloc","kzalloc","vmalloc"])
  and DataFlow::reaches(src, alloc.getArgument(0))
select alloc, "alloc size attacker-controlled — overflow candidate"
```
```sql
-- kfree rồi dùng ptr trong cùng fn
-- (dùng CodeQL kernel taint: free arg → subsequent deref)
```

### B.3 Semgrep (C)
```yaml
rules:
  - id: kernel-copy-from-user-no-size-check
    languages: [c]
    patterns:
      - pattern-inside: |
          if (copy_from_user($DST, $SRC, $LEN)) ...
      - pattern: kmalloc($X, ...)
      - metavariable-pattern: {metavariable: $X, pattern-either: [...]}
  - id: refcount-get-without-put
  - id: container_of-misuse
  - id: atomic_t-instead-of-refcount_t   # legacy overflow-able
```

### B.4 Manual ripgrep smells (per bug-class — SKILL.md §1)
```bash
rg -n 'kfree|kmem_cache_free|call_rcu|kvfree' <sub>/    # quanh ptr dùng tiếp
rg -n 'copy_from_user\([^,]+,[^,]+,[a-z_]+'              # size var
rg -n 'kmalloc\([^)]*\*|vmalloc\([^)]*\*'                # size mul (overflow)
rg -n 'atomic_t' | rg -v 'refcount_t'                    # legacy refcount
rg -n 'for\s*\([^)]*<\s*[a-z_]+'                         # index không bounds
rg -n 'kmalloc\(' | rg -v 'kzalloc|memset'               # uninit leak candidate
rg -n '!'                                                # logic ! (CVE-2026-23111 class) — review tay
```

## C. syzkaller (0-day engine) — fuzz kernel

### C.1 Setup (lab)
```bash
# build kernel với sanitizer (KASAN là chính)
./scripts/config -e KASAN -e KASAN_INLINE -e DEBUG_INFO -e RANDOMIZE_KSTACK_OFFSET_DEFAULT \
  -e KFENCE -e KCSAN -e LOCKDEP -e FAILSLAB    # KMSAN riêng (xung đột KASAN)
make -j$(nproc) bzImage modules
# QEMU + syz-manager chạy fuzz
```

### C.2 syzlang — mô tả syscall surface
- Mở harness cho **syscall/op mới chưa fuzz đủ**: new io_uring op, netfilter setexpr, bpf cmd, driver ioctl.
- Viết `.txt` description (syzlang syntax: resource, syscall, type) vào `sys/linux/` → `make generate` → `make`.
- Resource quản lý (fd, socket, nft chain/handle) cho stateful fuzz — **gap OSS-Fuzz-style raw-wire fuzz không có** (giống lesson msquic/quic).

### C.3 Crash → reproducer → primitive
```
crash (KASAN: BUG: KASAN: slab-use-after-free ...)
  → syz reproducer C program (syz-manager repro)
  → minimize reproducer
  → primitive analysis (pwn-triage GDB trên vmcore)
  → map primitive (SKILL.md §2) → PoC LPE
```

### C.4 Sanitizer ý nghĩa
| Sanitizer | Bắt gì | Caveat |
|---|---|---|
| **KASAN** | UAF/OOB/double-free runtime (quarantine + redzone) | **Amplify** — bug có thể không exploit trên no-KASAN prod; KASAN inject delay/quarantine thay timing |
| **KFENCE** | UAF/OOB sample-based (1/100000 alloc), nhẹ | Phát hiện production-ish; không crash steady |
| **KMSAN** | uninitialized-value leak | Xung đột KASAN, build riêng |
| **KCSAN** | data-race (concurrency) | Race → UAF-on-demand |
| **LOCKDEP** | locking-inversion/deadlock | Không phải memcorruption nhưng flag race path |

**Rigor:** KASAN/KFENCE crash = primitive **candidate**, chưa phải LPE. Primitive phải sống sót **không sanitizer** (xem SKILL.md §5 câu 4).

## D. kernelCTF & research follow
- **kernelCTF** (Google, LTS + COS): fix lag → bug sống, exploit bounty. WillsRoot "Syzkaller Summer 2025" — 3/ nhiều bug exploitable, CVE-2025-38001 compromise LTS+COS.
- Subscribe: syzkaller mailing list, oss-security, xairy list, lkc (Linux Kernel CVEs) feed, Project Zero bug tracker.
- CN: săn `内核提权`, `nf_tables漏洞`, `io_uring漏洞` trên Sec-News/Seebug/QiAnXin blog (`[[cn-0day-hunt]]`).
