---
name: redteam-recon
description: AUTO-INVOKE on any recon request ("recon", "quét subs", "probe", "map surface"). ALWAYS run §X Primitive Mining at end — every endpoint/header/anomaly classified + recorded, no discard. Subdomain → DNS → HTTP probe → port scan → crawl → wayback. ALL traffic via SOCKS5h proxy.
---

# 🔭 RedTeam-Recon — Recon Kill-Chain

**Tools chạy DIRECT (không proxy)** — config 2026-07-11. Workflow `recon-full.ps1` không truyền flag proxy.
Muốn route qua SOCKS5h: set env `HTTP_PROXY` hoặc thêm flag `-proxy`/`-http-proxy` cho từng tool Go.

## Workflow tự động
```powershell
# Full chain cho 1 domain
.\workflows\recon-full.ps1 -Domain example.com
# Thêm port scan top-1000: -TopPorts 1000
# Bỏ port scan (chỉ web): -NoPortScan
```
Output → `D:\Security Research\recon\<domain>_<ts>\{subs_all,httpx,ports,katana,gau}.txt`

## Kill-chain & cách đọc kết quả

### 1. Subdomain enum (passive, không chạm target)
```
subfinder -d <dom> -all -recursive   # 30+ nguồn, tốt nhất
assetfinder --subs-only <dom>        # bổ sung
amass enum -passive -d <dom>          # chậm nhưng sâu
```
Merge + dedupe (`anew`). **Thêm bruteforce** nếu cần: `alterx -l subs.txt -p` + dnsx resolve.

### 2. DNS resolve → `dnsx -a -aaaa -cname -resp`
CNAME chain = phát hiện alias, cloud, takeover candidate. CNAME → `*.azurewebsites.net`/S3/Heroku unclaimed = **subdomain takeover**.

### 3. HTTP probe → `httpx` (proxy)
```
-status-code -title -tech-detect -content-length -follow-redirects -threads 30
```
- `tech-detect`: fingerprint (wappalyzer) → định hướng attack (Spring? Shiro? Exchange? OA?).
- Redirect 302 → `/login`: auth surface. Title tiếng Việt/internal name → internal app lộ.
- Lọc `[200]` để có live hosts; title trùng = cùng stack.

### 4. Port scan → `naabu` (connect-scan, **proxy-aware**, không cần admin/Npcap)
```
naabu -list subs.txt -top-ports 1000 -proxy socks5://... -verify
```
nmap (docker) chỉ cho SYN-scan nhưng **không qua proxy được** (raw socket). Mặc định dùng naabu.

### 5. Crawl + wayback → katana (JS-aware) + gau
- katana `-jc` → extract endpoints từ JS bundles (API routes ẩn).
- gau → wayback URLs = endpoint cũ vẫn sống, params đã quên.

## Quy tắc xác nhận (rigor)
- Luôn `Test-ProxyAlive` trước; report exit IP.
- `tech-detect` ≠ ground truth — verify bằng header/body thật (curl qua proxy).
- Subdomain "live" trong httpx ≠ "attackable" — cần fuzz/param (→ skill redteam-fuzz).

## Pivot
- httpx.txt → `web-fuzz.ps1 -File httpx.txt`
- tech-detect ra CVE stack → `cn-0day-hunt` skill săn PoC TQ.

## §X. Primitive Mining During Recon (mandatory — fires `primitive-harvest`)

The recon step is not done until **every endpoint, header, behavior anomaly has been classified by primitive class** and (for non-LOW-severity-Looking items) filed as a primitive record. Recon without primitive mining leaks findings.

### X.1 Classification taxonomy (during recon)

Tag every recon output with the most-primitive-class. Use the same enum as `primitive-harvest` skill:

| Marker seen | Primitive class to consider |
|---|---|
| `/actuator/*` open, `/info` exposing version | `info-leak` |
| `X-Debug: 1`, `Server: nginx/x.y` revealing version | `info-leak` |
| `?url=`, `?target=`, `?file=` parameter accepted | `ssrf` candidate |
| `/api/v1/user/<id>` with arbitrary id accepted | `idor` |
| `Set-Cookie: rememberMe=...` / deser endpoints | `deser-input` candidate |
| SSO/SAML endpoints, OAuth redirect_uri | `auth-bypass` candidate |
| Body parser mismatch (JSON parsed as form) | `protocol-abuse` candidate |
| Stack trace in error response | `info-leak` |
| Path traversal in URL | `path-traversal` candidate |
| Public S3 / blob storage URL | `info-leak` (config leak) |

Items not in the list still get tagged with `other:` and a note.

### X.2 Mandatory step at end of recon-full.ps1

Append to the workflow output a `primitives-raw.md`:

```markdown
# Primitive Mining — <target> <date>

| # | Endpoint / header / behavior | Primitive class | Severity (initial) | Filed? |
|---|---|---|---|---|
| 1 | /actuator/env | info-leak | Medium | yes → primitives/<target>/info-actuator-env.md |
| 2 | X-Debug: 1 | info-leak | Info | pending → review chain potential |
| ... | | | | |
```

Default rule: **anything tagged as anything ≥ Low OR pairs-with-an-existing-primitive → file**. Info-only items are tagged for chain potential but only filed if a chain becomes plausible.

### X.3 Cross-ref against catalog

For each tag, check `catalog/cards/_index.md`:
- If the tag matches a REUSABLE card → mark "known class", file anyway to track incidence.
- If the tag is novel → mark "candidate class", pass forward to `bugclass-catalog` DRAFT.

### X.4 Anti-pattern

DO NOT exit recon until `primitives-raw.md` exists. If exhausted (no anomalies), document why (e.g., "Apache hardened config; no `/actuator`; no version reveal; backend behind WAF") — the negative result is itself informative for future analyst re-entry.

### X.5 Why this matters (failure-mode prevent)

The documented failure mode: recon returned 15 interesting endpoints, attack phase picked 2 to test, 13 got discarded because they "didn't look exploitable in 5 minutes." Adding primitive mining forces a record of every anomaly; later, when a chain becomes plausible (e.g., primitive 3 + 7 = goal), the file evidence survives.

Recon without primitive mining is half the work.
