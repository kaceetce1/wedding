# ARTEX `/btw`

Plain chat, a task MainAgent, and the current task's own Workers all support independent side questions. Type `/btw question` in the main input box to submit; an empty `/btw` or the "side question" button opens the history. The desktop uses a resizable-width sidebar, and mobile uses a Drawer.

Side answers are generated from the Agent context snapshot captured at submission time, and support streaming display, follow-up questions, stop, and clear. Closing the panel, refreshing the page, or disconnecting the SSE does not cancel the model request. Stop affects only the current side question; clear cancels the side question and deletes the side history while keeping the main context snapshot.

## Implementation Boundaries

Built on Go, norma v0.3.7, Next.js, and the existing Markdown / ResizablePanel / Drawer / AlertDialog components; no norma source changes and no dependencies added for side questions. Planner, Workers inherited from other tasks, and tool-type subtask escalation are out of scope for this work.

```mermaid
flowchart LR
    A[Main Agent QueryDeps] --> B[Actual Provider binding]
    B --> C[Immutable structured snapshot]
    B --> D[Main Agent normal tool loop]
    C --> E[(PostgreSQL latest snapshot)]
    E --> F[Snapshot + recent successful side Q&A + question]
    F --> G[SideQuestionService single Provider request]
    G --> H[(Independent side history and usage)]
    H --> I[Cumulative answer SSE / side panel]
```

- `capture.go` marks main-loop requests only at `Options.Deps.CallModel / CallModelSync`. The Provider decorator sits inside the concrete model, after outer routing-pool selection, so it records the actually selected model; compaction and summarization requests do not overwrite the snapshot.
- Snapshots are published at request start, on a complete model reply, and on the run's terminal state. In-progress partial replies are not published; tool calls stay paired via norma's `MessagesForAPI`, and tool results enter the snapshot on the next main model request or the run's terminal state. A streaming abort keeps the last valid boundary.
- The snapshot preserves structured messages, the system prompt, tool definitions, and generation parameters via a JSON deep copy. Model inference holds neither the snapshot lock nor a database transaction.
- `SideQuestionService` calls the concrete Provider; it first generates a side summary when needed, and the final answer is allowed a single reduced retry only when the first attempt exceeds the context limit and has not yet emitted text/tool calls. It creates no agent session, wires into no tool executor, main transcript, activity stream, or task graph, and bypasses the task model-switching chain. Answers keep tool definitions for compatibility with the existing structured tool context; summarization requests provide no tools. Newly returned tool calls have no execution path.
- One running request per parent session, at most four per service process, with a 120-second timeout each. Side questions use an independent cancellation context under the service lifetime.
- Side requests keep a model-config reference and a non-sensitive identity digest; credentials are fetched from the existing config at request time. If the config is deleted, or identity fields such as model, protocol, or address change, a main Agent run is required first to update the snapshot. Tests do not change the product default model.

## Persistence and Recovery

`db/schema.sql` automatically creates `side_question_sessions` and `side_question_requests`. The former stores the parent resource, latest snapshot, run number, version, and clear version; the latter stores the question, cumulative answer, status, model, snapshot time, usage, event ordinal, and paging ordinal.

The parent session key uses the conversation ID, or task ID + exploration ID + intent ID. Workers do not use reusable execution-slot naming.

Snapshots are merged and written per parent session, refreshed every 250 ms, and the database compares `(run_id, version)` to prevent an older version from overwriting a newer one. The selected snapshot is saved again before a side question is submitted. After a successful save, the large in-memory snapshot is released; on failure, the pending version is kept. The cumulative answer is written at most once per 250 ms as streaming events arrive, saved immediately on the terminal state, and retried a limited number of times on database errors.

On service startup, leftover `running` requests are marked `interrupted`, keeping the partial answer and usage already persisted, and requests are not automatically replayed. The most recently saved context can be used directly for the next question. When an old session has no snapshot, a main Agent run is required first; the context is not rebuilt from UI activity records.

A clear operation increments the clear version and deletes requests; a conditional update prevents a late callback from writing them back. Physical parent resource deletion relies on foreign-key cascade, while a Worker logical deletion removes the side data in the same transaction and rejects subsequent late snapshots. Task archiving first blocks new requests, waits for the main flow to stop, then cancels and waits for side questions to be persisted; the archive format is v3 and remains compatible with v1/v2, which contain no side tables.

History is kept in full, returning at most 20 items per page via an ordinal cursor. Model requests replay at most the most recent 20 successful Q&A pairs verbatim, with the replay volume capped by a token budget; older Q&A maintains an independent rolling summary. When the main context exceeds budget, only the older parts of the side copy are summarized, keeping recent structured tool calls and results. Summarization and preparation progress are included with usage under the side question's concurrency, cancellation, and 120-second timeout limits. See [Context Budget and Open-Source References](CONTEXT_BUDGET.md).

## HTTP Contract

The following paths serve as `{parent}` and reuse the existing authentication and resource validation:

- `/api/conversations/{id}`
- `/api/tasks/{id}/chat`
- `/api/tasks/{id}/intents/{iid}`

| Request | Response and behavior |
| --- | --- |
| `GET {parent}/side-questions?before={ordinal}` | `items` ordered newest-first, an independent `current` run status, `snapshot` metadata, `next_cursor`; a cursor of 0 means the latest page / no next page |
| `POST {parent}/side-questions` | JSON `{ "question": "…", "client_request_id": "UUID" }`; a new request returns 202 with the request object; the same ID and question returns the existing object with 200 |
| `DELETE {parent}/side-questions` | Cancel and clear the current parent session's side Q&A |
| `GET /api/side-questions/{requestID}/events` | `snapshot` SSE events, `id` an increasing ordinal, `data` the full cumulative request object; sends `cleared` when cleared |
| `POST /api/side-questions/{requestID}/cancel` | Explicit cancel; the terminal state can be read from history or SSE |

Questions are capped at 4000 characters. A missing snapshot, a changed model config, a busy same-parent session, or an idempotency ID conflict returns 409; exceeding the global concurrency limit returns 429. Every SSE connection first sends the cumulative state and does not depend on text fragments the client previously received. The frontend merges by request ID + ordinal and discards old callbacks when switching parent sessions or clearing.

## Validation and References

See [VALIDATION.md](VALIDATION.md) for automated checks, actual model usage, and known limitations.

Independent-request reference: [Grok CLI side-question.ts (pinned commit)](https://github.com/superagent-ai/grok-cli/blob/fb97af83f06dca873281d60168430f06c8de6324/src/utils/side-question.ts); run-isolation reference: [OpenCode (pinned commit)](https://github.com/anomalyco/opencode/tree/b3f1a96c6dd7adeb28b36dd11add1998fc84d67b). ARTEX's context uses norma's structured messages and does not adopt the approach of stitching text together from frontend logs.
