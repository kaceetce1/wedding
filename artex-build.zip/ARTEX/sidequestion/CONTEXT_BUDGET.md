# Side Long Conversations and Context Budget

Fixed 2026-09-11. The original implementation treated the character count of the request JSON directly as tokens and inherited the main task's 32K output reservation, so side questions that were otherwise normal were rejected early when HTML, JS, and tool results were abundant.

## Open-Source Implementation Review

- [Grok CLI side context](https://github.com/superagent-ai/grok-cli/blob/fb97af83f06dca873281d60168430f06c8de6324/src/agent/agent.ts#L739): extracts fragments from recent user and assistant text, with a character budget of about 2000 and at most 400 characters per item. No continuous side Q&A history is maintained on this path.
- [Grok CLI independent request](https://github.com/superagent-ai/grok-cli/blob/fb97af83f06dca873281d60168430f06c8de6324/src/utils/side-question.ts): independent cancellation signal; output cap of 2048 tokens when the model supports it; no tools provided.
- [Grok CLI main-session compaction](https://github.com/superagent-ai/grok-cli/blob/fb97af83f06dca873281d60168430f06c8de6324/src/agent/compaction.ts): estimates tokens, keeps recent content, folds new content into the old summary, and handles cross-turn truncation.
- [OpenCode session compaction](https://github.com/anomalyco/opencode/blob/b3f1a96c6dd7adeb28b36dd11add1998fc84d67b/packages/core/src/session/compaction.ts): full-request estimation, output/buffer reservation, recent content plus a rolling summary, and a tool-free summarization request; this implementation defaults to a recent budget of 8000 and a summarization output cap of 4096 tokens.
- [OpenCode overflow recovery](https://github.com/anomalyco/opencode/blob/b3f1a96c6dd7adeb28b36dd11add1998fc84d67b/packages/core/src/session/runner/llm.ts): attempts overflow recovery only when no assistant output has started yet, and the recovered call does not re-enter the same overflow-recovery path.

ARTEX borrows the practices of an independent output budget, recent content plus a rolling summary, and limited recovery. It keeps norma v0.3.6's structured messages and tool pairing, and does not copy Grok's text extraction; it does not write OpenCode's main-session compaction events into the ARTEX main transcript.

## Request Budget and Execution

- Messages use norma's per-content-block UTF-8 byte estimation with a 4/3 margin; the system prompt, tool schemas, and message-wrapping overhead are counted additionally. The estimate is not an exact model token count.
- Side output defaults to at most 8192 tokens and does not exceed the output cap already set in the main config. The service environment variable `ARTEX_BTW_MAX_OUTPUT_TOKENS` can set a cap from 256 to 32768; it does not change the product default model or main task parameters.
- The input budget is the context window minus the output cap and a safety margin; an unknown window uses the platform default of 200K. The safety margin is 5% of the window, at least 128 and at most 8192 tokens.
- Successful Q&A is loaded in batches of at most 20 pairs by increasing ordinal. At most 20 pairs are kept verbatim, with a token budget of at most 1/4 of the input budget and no more than 16K.
- Excess Q&A is folded into the rolling summary. The summary carries its history source and context time; a historical assistant answer does not count as new tool evidence, and on conflict the latest main snapshot takes precedence.
- When the main context is still too long, only the older messages in the copy are summarized, keeping the most recent 8K tokens; the cut point does not split a tool call from its result. An oversized single pair goes into the summary in full.
- Summary input is split into UTF-8-safe chunks based on the actual remaining window, with an output cap of 2048 tokens; an empty summary, truncation, tool call, or exceeding the summary budget all skip writing the cache. A single side question performs at most 12 summarization calls, under the same 120-second timeout; reaching the cap fails explicitly rather than looping forever.
- If the model first returns a context-overflow error and has not yet emitted text or tool calls, it is retried at most once after further reduction; if the estimated size has not decreased, recovery stops immediately. Other model errors and partial streaming output do not trigger this recovery.
- All usage obtained, including for summarization, failed attempts, and cancellation, is accumulated into the same side request. When the Provider returns no usage, only zero can be recorded; estimates must not be disguised as actual usage.

## Persistence and Interface

`side_question_sessions.memory` stores the old Q&A summary, the covered ordinals, and the main-context summary cached by snapshot identity. `side_question_requests.context_info` stores the preparation stage, the actual number of replayed pairs, summary usage, and the budget estimate.

Summaries are saved only while the original request is still running and the clear version matches; clearing also purges the cache, and late writes do not restore cleared data. A new snapshot does not reuse the old snapshot's summary. Summary fields are saved with the v3 task archive; when a restored old v3 is missing fields, an empty object is filled in, and v1/v2 remain compatible.

POST accepts and returns the request first, and preparation and compaction run in the background without holding the admission lock or a database transaction. SSE/history show the preparation, Q&A arrangement, copy compaction, and answer stages; a compaction failure is saved as the side request's failed terminal state. The frontend keeps the error and restores the draft of the failed question, without covering the input box with a floating notification; history polling no longer clears the submit error.

## Validation Record

- Replay of 19/20/21/50 pairs, retention of old conclusions across 20 pairs, and reuse of the summary cache after restart: automated, passed.
- Very long Chinese answers and code contexts, chunked request budget, tool pairing, snapshot immutability, and cache invalidation for a new snapshot: automated, passed.
- Summary failure/cancellation/truncation/oversize/tool return, clear races, call cap, only-once overflow recovery, and no retry on partial stream: automated, passed.
- Paging, restart, v1/v2/v3 archiving, summary cache and budget metadata archive recovery, old v3 missing new fields, and 20 parent sessions sharing four concurrency slots on an independent PostgreSQL: passed.
- Go candidate service build, frontend TypeScript check, Biome check of the modified components, and a Next.js production build in an independent directory: passed.
- Built-in browser with an independent UI fixture, verified at 1280×720 and 390×844: the arrangement stage, summary-scope hint, draft recovery after failure, absence of floating error notifications, no horizontal overflow, and no console errors. The temporary fixture has been removed.
- Read-only replay of the machine's existing Worker snapshots: the new budget check passes; for example, Worker #3's 293085-character snapshot is no longer misjudged and rejected by the local character count. This item made no external model calls.
- Sending private Worker snapshots to Grok in a real conversation test this time was rejected by automated approval review, was not executed, and does not count as a pass.
- 2026-09-11 00:37: restarted the local backend as requested by the user, reusing the original database, data directory, and login config. The running file matches the candidate binary's SHA-256; `/api/health` returns normal for both the backend and the frontend proxy.

Validation commands (using only the independent test DB):

```sh
go test -race ./sidequestion ./db ./server -run 'TestSide|TestCheckpoint|TestSnapshot|TestBuildRequest|TestService|TestMainSide|TestTaskArchive' -count=1
go build ./cmd/artex
npx tsc --noEmit
npm run build -- --webpack
```

The frontend production build uses an independent copy to avoid overwriting the `.next` of the current preview. The candidate service is at `/private/tmp/artex-btw-budget-candidate`, copied to `/private/tmp/artex-btw-preview/artex` and started; the original binary is backed up as `artex.before-context-budget` in the same directory.
