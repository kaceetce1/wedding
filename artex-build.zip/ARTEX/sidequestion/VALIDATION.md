# `/btw` Validation Record

Date: 2026-09-10. Branch: `codex/btw-side-question`. Baseline: `8dae851b9b622f2ff2631f332fde9719d0b16fba`.

An independent PostgreSQL test DB and data directory were used; real model credentials were injected only into the independent test environment, were not written into the code or this record, and did not modify the product default model. Go 1.26.3, norma v0.3.6, Next.js 16.2.9.

The actual model conversations, returned objects, engineering assertions, and Qwen's raw review text are saved in [validation-2026-09-10.json](validation-2026-09-10.json), which contains no API credentials.

## Engineering Checks

| Scope | Result | Evidence |
| --- | --- | --- |
| Structured messages, deep copy of tool arguments | Passed | `TestCheckpointDeepCopyAndBoundaries` |
| Summarization / compaction requests do not overwrite; complete replies and terminal states are published; partial replies excluded | Passed | `TestCheckpointDeepCopyAndBoundaries`, `TestSnapshotExcludesPartialStreamAndSelectsPoolMember` |
| Actual model pool member identity | Passed | `TestSnapshotExcludesPartialStreamAndSelectsPoolMember` |
| Tool pairing, 20-pair replay, budget trimming and overflow errors | Passed | `TestBuildRequestCompactionToolPairingAndBudget` |
| Main and side questions in parallel, bidirectional cancellation isolation | Passed | Blocking Provider, `TestMainSideConcurrencyAndIndependentCancellation` |
| No tool execution, streaming / non-streaming, existing usage on failure | Passed | `TestServiceNoToolsAndUsageOnFailure` |
| Real norma ChatAgent + local Read tool, isolation from main transcript / activity | Passed | `TestSideActualChatCheckpointToolResultAndTranscriptIsolation`, streaming and non-streaming subtests |
| Persistence, paging, idempotency, retention of partial answers after restart | Passed | `TestSideHistoryIdempotencyPagingAndRecovery` |
| Clear racing with late writes, parent resource deletion, version comparison | Passed | `TestSideClearLateWritersAndDeletedParent` |
| MainAgent / Worker archiving and recovery, v1/v2/v3 | Passed | `TestSideTaskArchiveVersions` |
| Three parent interfaces, authentication, resource ownership, Worker logical deletion | Passed | `TestSideHTTPGlobalLimitTaskWorkerAndDeletion`, `TestSideCheckpointPersistsBeforeAdmissionAndRestart` |
| Side questions allowed while the main session is busy, independent SSE reconnect / disconnect, cancel, clear | Passed | `TestSideHTTPBusyIsolationClearAndReconnect` |
| 1 per parent session / 4 global concurrency | Passed | the two `TestSideHTTP…` cases |
| Snapshot persisted before submission, continued questions after restart, old sessions cannot forge a snapshot | Passed | `TestSideCheckpointPersistsBeforeAdmissionAndRestart` |
| Continue is refused after a cached config is deleted or the model changes | Passed | `TestSideRejectsDeletedOrChangedCachedProfile` |
| Cancel before archiving and wait for the final answer and usage to be persisted | Passed | `TestSideTaskDrainPersistsBeforeArchive` |
| Usage and side-question attribution recorded only once when a streaming consumer cancels early | Passed | `TestSideUsageRecordedOnceOnConsumerCancellation` |
| A Worker / deadline run context auto-restored after restart keeps publishing new snapshots | Passed | `TestSideRestoredWorkerRuntimePublishesNewCheckpoint` |
| Race check for the relevant packages | Passed | the command below |
| TypeScript and production build | Passed | `npx tsc --noEmit`, `npm run build` |
| Biome for new frontend modules | Passed | `biome check`, 3 new modules |

After configuring `ARTEX_PG_DSN` in a separate disposable database, the automated checks can be reproduced (do not point it at the production DB):

```sh
go test -race ./agent ./db ./server ./sidequestion ./llmrec ./llmpool \
  -run 'Test(Side|Checkpoint|Snapshot|BuildRequest|Service|MainSide|CaptureRun|TaskArchive|CompleteForwards|StopIntent|CancelIntent)' -count=1
cd web
npx tsc --noEmit
npx biome check src/lib/side-questions.ts src/hooks/use-side-questions.ts src/components/side-question-workspace.tsx
npm run build
```

The full Go regression is not all green: two pre-existing tests in the `server` package fail during temp-directory cleanup, both reporting `TempDir RemoveAll … directory not empty`:

- `TestInheritedActivityDetailAndRelationDeletion`
- `TestTaskMetadataPatchReturnsRenameAndPin`

Exporting the source from the unmodified baseline above and rerunning the `server` package in the same isolated environment reproduced these two cleanup failures as well. The baseline run additionally showed a target-node-count assertion failure in `TestCoreTaskLifecyclePG`; the final modified `server` regression did not have that assertion failure. Other packages passed, and this work's side-question cases and race check passed. Baseline issues were not marked as passing this acceptance, and no existing assertion was modified to hide a problem.

The Next.js build output had pre-existing multiple-lockfile / workspace-root inference warnings; the build completed and all pages generated successfully.

## Browser Checks

Using the Codex In-app Browser connected to an independent local Go service and Next.js dev server. On desktop and a 390 × 844 narrow screen, the following manual automated operations were performed, checking screenshots and browser logs:

- Typing `/btw` while plain chat is running: main content and the side question display at the same time; the desktop sidebar works normally.
- Consecutive follow-up questions; after the side question is stopped, the generated part is kept; the main flow continues.
- Closing the panel lets the request continue, and reopening restores the completed answer; after refreshing the page, an empty `/btw` restores the history.
- The narrow-screen Drawer's input, buttons, history, and close operation work normally, with no horizontal overflow.
- Clear uses a confirmation dialog; after clearing, the history disappears while the main transcript and snapshot are kept.
- A task MainAgent and two Workers each asked questions and were switched between; Agent labels and histories did not get crossed.
- A blocking local model fixture keeps the Worker running; submitting `/btw` from the Worker's main input box, after stopping the side question the Worker still shows a live run and its own pause button, and the side question saves the partial answer.
- Browser error / warning logs were empty.

The controllable fixture is used to precisely verify concurrency timing, without depending on the real model's output speed. During debugging, two Worker runtime checks formed no valid concurrency window (task already ended / answer ended early); after fixing the fixture, the checks were redone and passed; these initial operations are not counted as valid passes.

## Real Model Conversations

Probing `grok-4.6` first, via the OpenAI-compatible endpoint `http://127.0.0.1:12580/tingly/openai`. The probe returned HTTP 200, model name `grok-4.6`, and `READY`, taking 2.82 seconds. The first choice was available, so the Tingly `glm` or Zhipu `glm-5.3` fallback chain was not enabled; these two fallback services were not validated this time.

| Scenario | Actual result |
| --- | --- |
| Asking about assets, targets, and markers while the main session runs | Returned `redhaze.top`, the homepage fetch and a summary of the target, and `BTW-REAL-0910`; the side question completed in 16.97 seconds |
| Asking about the tool basis after the main session finished fetching the homepage | Correctly cited WebFetch 200, curl redirect 301 → 302 → 200, and the page title; 7.24 seconds |
| The side question asked Bash to create a test file | Refused to execute, target file not created; 7.74 seconds |
| A completed side question does not change the main context | The main transcript SHA-256 matched the main activity record; side tool execution count was 0 |
| Follow-up after truly stopping / restarting the Go service | Kept the previous 3 side history entries, answered directly from the persisted snapshot about assets, markers, and the title, without rerunning the main Agent |
| A new session using the Grok non-streaming config | Correctly answered the asset and `ATOMIC-0910`; returned and saved usage: input 11734, output 138, cache_read 11520 |

The asset case's main session used WebFetch and Bash/curl to fetch a public homepage; the landing page was `https://id.redhaze.top/home`, titled "红幕科技 RedHaze Group · 全球综合集团门户". Bash cached the response in a local test file; no write was executed against the remote. This fact was verified separately from "the side question executed no tools."

Main transcript checksum: `e7e61f135a4a120954b539f357e8c4205d7d5cd7460dcaf3dc0fd066463e1d00`.

**Usage limitation:** Tingly's Grok streaming response returns no usage. Verified separately by sending `stream_options.include_usage=true` directly: HTTP 200, 12 data frames, 0 usage frames. Therefore the 0 in the streaming tests means the endpoint provided no usage and cannot be interpreted as no billing. Non-streaming usage and the fixture's failure / cancellation usage were all saved correctly.

## Qwen Review

Review model `qwen-flash`, OpenAI-compatible endpoint `https://dashscope.aliyuncs.com/compatible-mode/v1`, HTTP 200. The first three real side conversations, the main session's tool basis, and the engineering assertions were provided; it returned `verdict: accept` and `concerns: []`, finding the answers consistent with the assets, markers, and page-fetch evidence, and the side question's tool refusal compliant with the constraints. Review usage: prompt 6625, completion 312, total 6937.

This Qwen review scope did not include the later-appended service restart and non-streaming tests. Qwen's generalization of "no writes" was too broad: the main session's curl did create a local temporary file for the response, as already recorded explicitly above. Concurrency, zero tool execution, and transcript isolation are judged by the engineering assertions; the model review only assisted in evaluating answer quality.
