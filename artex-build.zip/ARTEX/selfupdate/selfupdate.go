// Package selfupdate implements ARTEX's one-click update from the web page: it pulls the
// new binary from a GitHub Release, verifies it, stages it, and atomically installs it on
// the next startup.
//
// Overall division of labour (see start.sh / start.bat):
//
//	startup script = a dumb supervision loop, only responsible for "deciding whether to
//	                 relaunch after the process exits, based on the exit code"
//	this package   = all the error-prone logic (download / SHA256 verification / smoke
//	                 test / install / failure rollback)
//
// The install step lives in Go rather than the script because sha256 verification and the
// smoke test would have to be written twice for sh and bat (sha256sum / shasum / certutil),
// and that is precisely the step that must not fail — install a binary that cannot run and
// the supervisor will faithfully relaunch it over and over while the user can only rescue
// the machine by hand.
//
// One full upgrade goes through three process startups:
//
//	(1) the old server receives /api/update/apply -> download and verify -> stage artex.new -> exit 75
//	(2) the script relaunches the old version -> Bootstrap finds artex.new -> verify + smoke test -> install -> exit 75
//	(3) the script relaunches, now the new version -> Bootstrap records one attempt -> clears the marker after a successful start
//
// Any failed step falls back to the old version: in (2), if verification fails the staged
// file is deleted and the old version keeps running; in (3), if three consecutive startups
// fail to reach the point of clearing the marker (it crashes on startup), artex.old is
// swapped back automatically.
package selfupdate

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

// ExitRestart is the exit code that means "supervisor, relaunch me" (EX_TEMPFAIL). When
// the startup script sees it, it reruns immediately without counting it toward crash
// backoff. 0 means the user stopped the service normally (the script exits its loop); any
// other value is treated as a crash.
const ExitRestart = 75

// maxAttempts is the number of startup attempts allowed after an install. Each startup of
// the new version increments the count, and surviving settleDelay clears the marker;
// crashing maxAttempts times in a row means the new version cannot start at all, so it is
// rolled back automatically.
const maxAttempts = 3

// Paths is every file involved in one upgrade, all anchored under **the directory the
// executable resides in**. CWD is deliberately not used: when running as a service the
// working directory may be / or any arbitrary path, and using CWD would drop the staged
// files somewhere else and break the install logic entirely.
type Paths struct {
	Dir     string // directory the executable resides in
	Current string // currently running binary   artex      / artex.exe
	New     string // staged new version          artex.new  / artex.new.exe
	Sum     string // sha256 of the new version (hex)  artex.new.sha256 / artex.new.exe.sha256
	Old     string // old version backed up before install  artex.old  / artex.old.exe
	Marker  string // upgrade state marker        artex.upgrade.json
}

// ResolvePaths derives all upgrade paths from the current executable.
//
// On Windows the .new/.old files must also carry the .exe suffix, otherwise both the smoke
// test and execution after the install fail; so the suffix is stripped first and appended
// when joining, keeping the naming symmetric across both platforms.
func ResolvePaths() (Paths, error) {
	exe, err := os.Executable()
	if err != nil {
		return Paths{}, fmt.Errorf("locate executable: %w", err)
	}
	if resolved, err := filepath.EvalSymlinks(exe); err == nil {
		exe = resolved
	}
	dir := filepath.Dir(exe)
	name := filepath.Base(exe)
	ext := filepath.Ext(name) // ".exe" on Windows, usually empty on Unix
	stem := strings.TrimSuffix(name, ext)

	join := func(suffix string) string { return filepath.Join(dir, stem+suffix+ext) }
	return Paths{
		Dir:     dir,
		Current: exe,
		New:     join(".new"),
		Sum:     join(".new") + ".sha256",
		Old:     join(".old"),
		Marker:  filepath.Join(dir, stem+".upgrade.json"),
	}, nil
}

// marker records the progress of one install, used to trigger an automatic rollback when
// the new version cannot start.
type marker struct {
	From     string `json:"from"`     // version before the upgrade
	To       string `json:"to"`       // target version
	Attempts int    `json:"attempts"` // number of startups attempted since the install
	StagedAt int64  `json:"staged_at"`
}

func readMarker(path string) (marker, bool) {
	b, err := os.ReadFile(path)
	if err != nil {
		return marker{}, false
	}
	var m marker
	if json.Unmarshal(b, &m) != nil {
		return marker{}, false
	}
	return m, true
}

func writeMarker(path string, m marker) error {
	b, err := json.MarshalIndent(m, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, b, 0o644)
}

// cleanStaged removes the staged files. It is used after a successful install, a failed
// verification, and a user cancellation, so a leftover artex.new is not retried on the
// next startup.
func cleanStaged(p Paths) {
	_ = os.Remove(p.New)
	_ = os.Remove(p.Sum)
}

// CompareVersions compares two version numbers and returns -1/0/1 (a<b / a==b / a>b).
// ok=false means at least one side is not a comparable version number (for example "dev"
// from a local development build, or "0.3.7-2-gabc1234-dirty" produced by git describe); in
// that case the caller should disable one-click update, otherwise it would "upgrade" a
// development build to a release and overwrite uncommitted changes.
func CompareVersions(a, b string) (int, bool) {
	av, aok := parseVersion(a)
	bv, bok := parseVersion(b)
	if !aok || !bok {
		return 0, false
	}
	for i := range 3 {
		if av[i] != bv[i] {
			if av[i] < bv[i] {
				return -1, true
			}
			return 1, true
		}
	}
	return 0, true
}

// parseVersion parses a version of the form "v0.3.7" / "0.3.7" into [3]int.
//
// It accepts only a clean three-part version: when building a non-tag build, build.sh uses
// git describe to produce versions with a suffix such as "0.3.7-2-gabc1234", and these must
// be judged incomparable rather than treated as 0.3.7 — otherwise a development build would
// be misjudged as "already up to date" or overwritten by a release.
func parseVersion(s string) ([3]int, bool) {
	s = strings.TrimSpace(s)
	s = strings.TrimPrefix(s, "v")
	if s == "" {
		return [3]int{}, false
	}
	parts := strings.Split(s, ".")
	if len(parts) != 3 {
		return [3]int{}, false
	}
	var out [3]int
	for i, p := range parts {
		n, err := strconv.Atoi(p)
		if err != nil || n < 0 {
			return [3]int{}, false
		}
		out[i] = n
	}
	return out, true
}

// InDocker reports whether the process runs inside a container. Under Docker, an install
// writes to the container's writable layer, and `docker compose up -d` recreating the
// container reverts to the version bundled in the image — this is expected behaviour (at
// that point the user is pulling a new image anyway), but the frontend needs to be able to
// explain it clearly.
func InDocker() bool {
	if _, err := os.Stat("/.dockerenv"); err == nil {
		return true
	}
	b, err := os.ReadFile("/proc/1/cgroup")
	if err != nil {
		return false
	}
	s := string(b)
	return strings.Contains(s, "docker") || strings.Contains(s, "containerd")
}
