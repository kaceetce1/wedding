package db

import "testing"

func rule(kind, pattern string, enabled bool) AssetInterceptRule {
	return AssetInterceptRule{Kind: kind, Pattern: pattern, Enabled: enabled}
}

func TestMatchAssetInterceptRules(t *testing.T) {
	cases := []struct {
		name    string
		rules   []AssetInterceptRule
		domains []string
		ips     []string
		urls    []string
		want    bool
		wantVal string
	}{
		{"builtin fuzzy government domain match", []AssetInterceptRule{rule("fuzzy_domain", ".gov.cn", true)},
			[]string{"www.beijing.gov.cn"}, nil, nil, true, "www.beijing.gov.cn"},
		{"fuzzy education domain match", []AssetInterceptRule{rule("fuzzy_domain", ".edu", true)},
			[]string{"mit.edu"}, nil, nil, true, "mit.edu"},
		{"exact domain match is case-insensitive", []AssetInterceptRule{rule("exact_domain", "Example.com", true)},
			[]string{"example.com"}, nil, nil, true, "example.com"},
		{"exact domain does not match subdomain", []AssetInterceptRule{rule("exact_domain", "example.com", true)},
			[]string{"a.example.com"}, nil, nil, false, ""},
		{"exact IP match", []AssetInterceptRule{rule("exact_ip", "203.0.113.5", true)},
			nil, []string{"203.0.113.5"}, nil, true, "203.0.113.5"},
		{"fuzzy IP prefix match", []AssetInterceptRule{rule("fuzzy_ip", "203.0.113.", true)},
			nil, []string{"203.0.113.99"}, nil, true, "203.0.113.99"},
		{"CIDR match", []AssetInterceptRule{rule("cidr", "192.168.0.0/16", true)},
			nil, []string{"192.168.5.20"}, nil, true, "192.168.5.20"},
		{"CIDR no match", []AssetInterceptRule{rule("cidr", "192.168.0.0/16", true)},
			nil, []string{"10.0.0.1"}, nil, false, ""},
		{"exact URL match", []AssetInterceptRule{rule("exact_url", "https://a.gov.cn/login", true)},
			nil, nil, []string{"https://a.gov.cn/login"}, true, "https://a.gov.cn/login"},
		{"fuzzy URL matches path", []AssetInterceptRule{rule("fuzzy_url", "/admin", true)},
			nil, nil, []string{"https://x.com/admin/panel"}, true, "https://x.com/admin/panel"},
		{"disabled rule does not match", []AssetInterceptRule{rule("fuzzy_domain", ".gov.cn", false)},
			[]string{"www.gov.cn"}, nil, nil, false, ""},
		{"no rules does not match", nil, []string{"www.gov.cn"}, nil, nil, false, ""},
		{"empty pattern does not match", []AssetInterceptRule{rule("fuzzy_domain", "  ", true)},
			[]string{"www.gov.cn"}, nil, nil, false, ""},

		// suffix_domain matches only at a label boundary — the fix for the
		// built-in ".gov" rule blocking unrelated countries' registries.
		{"suffix domain matches bare label", []AssetInterceptRule{rule("suffix_domain", ".gov", true)},
			[]string{"agency.gov"}, nil, nil, true, "agency.gov"},
		{"suffix domain matches subdomain", []AssetInterceptRule{rule("suffix_domain", ".gov", true)},
			[]string{"portal.agency.gov"}, nil, nil, true, "portal.agency.gov"},
		{"suffix domain matches deep subdomain", []AssetInterceptRule{rule("suffix_domain", ".gov", true)},
			[]string{"a.b.c.gov"}, nil, nil, true, "a.b.c.gov"},
		{"suffix domain rejects foreign ccTLD", []AssetInterceptRule{rule("suffix_domain", ".gov", true)},
			[]string{"ministry.gov.kh"}, nil, nil, false, ""},
		{"suffix domain rejects brand containing pattern", []AssetInterceptRule{rule("suffix_domain", ".gov", true)},
			[]string{"evil-gov.com"}, nil, nil, false, ""},
		{"suffix domain rejects pattern as a prefix label", []AssetInterceptRule{rule("suffix_domain", ".gov", true)},
			[]string{"gov.example.com"}, nil, nil, false, ""},
		{"suffix domain pattern without leading dot", []AssetInterceptRule{rule("suffix_domain", "gov", true)},
			[]string{"agency.gov"}, nil, nil, true, "agency.gov"},
		{"suffix domain wildcard pattern", []AssetInterceptRule{rule("suffix_domain", "*.gov", true)},
			[]string{"agency.gov"}, nil, nil, true, "agency.gov"},
		{"suffix domain is case-insensitive", []AssetInterceptRule{rule("suffix_domain", ".GOV", true)},
			[]string{"Agency.Gov"}, nil, nil, true, "Agency.Gov"},
		{"suffix domain .gov.cn matches its own registry", []AssetInterceptRule{rule("suffix_domain", ".gov.cn", true)},
			[]string{"www.beijing.gov.cn"}, nil, nil, true, "www.beijing.gov.cn"},
		{"suffix domain .gov does not swallow .gov.cn", []AssetInterceptRule{rule("suffix_domain", ".gov", true)},
			[]string{"www.beijing.gov.cn"}, nil, nil, false, ""},
		{"suffix domain disabled does not match", []AssetInterceptRule{rule("suffix_domain", ".gov", false)},
			[]string{"agency.gov"}, nil, nil, false, ""},
		{"suffix domain empty pattern does not match", []AssetInterceptRule{rule("suffix_domain", "  ", true)},
			[]string{"agency.gov"}, nil, nil, false, ""},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			r, val, ok := MatchAssetInterceptRules(c.rules, c.domains, c.ips, c.urls)
			if ok != c.want {
				t.Fatalf("match = %v, want %v (rule=%+v)", ok, c.want, r)
			}
			if ok && val != c.wantVal {
				t.Fatalf("match value = %q, want %q", val, c.wantVal)
			}
		})
	}
}

func TestEvaluateAssetGate(t *testing.T) {
	block := []AssetInterceptRule{rule("fuzzy_domain", ".gov.cn", true)}
	allow := []AssetInterceptRule{rule("fuzzy_domain", "example.com", true)}

	// 1. Hits a block rule -> deny (the block reason takes precedence).
	if d := EvaluateAssetGate(block, allow, []string{"www.gov.cn"}, nil, nil); d.Allowed {
		t.Fatal("hitting a block rule must be denied")
	}

	// 2. No block hit, allow rules exist but do not match -> deny (not allowed).
	d := EvaluateAssetGate(block, allow, []string{"foo.other.com"}, nil, nil)
	if d.Allowed {
		t.Fatal("with an allowlist, a non-match must be denied")
	}
	if d.Reason == "" {
		t.Fatal("a denial must carry a reason")
	}

	// 3. No block hit, hits an allow rule -> allow.
	if d := EvaluateAssetGate(block, allow, []string{"api.example.com"}, nil, nil); !d.Allowed {
		t.Fatal("hitting the allowlist must be allowed")
	}

	// 4. No allow rules (allowlist disabled) -> no block hit means allow.
	if d := EvaluateAssetGate(block, nil, []string{"foo.other.com"}, nil, nil); !d.Allowed {
		t.Fatal("without an allowlist, no block hit must be allowed")
	}

	// 5. All allow rules disabled -> treated as allowlist disabled, allow.
	disabledAllow := []AssetInterceptRule{rule("fuzzy_domain", "example.com", false)}
	if d := EvaluateAssetGate(nil, disabledAllow, []string{"foo.other.com"}, nil, nil); !d.Allowed {
		t.Fatal("with the allowlist fully disabled, must be allowed")
	}

	// 6. Block takes precedence over allow: a target hitting both -> deny.
	if d := EvaluateAssetGate(
		[]AssetInterceptRule{rule("fuzzy_domain", ".gov.cn", true)},
		[]AssetInterceptRule{rule("fuzzy_domain", ".gov.cn", true)},
		[]string{"www.gov.cn"}, nil, nil,
	); d.Allowed {
		t.Fatal("block must take precedence over allow")
	}
}

func TestAssetInterceptCandidates(t *testing.T) {
	// A service asset carrying only a URL: the host must be split out into the
	// domain candidates so fuzzy_domain can hit it.
	a := &Asset{Type: "service", URL: "https://portal.beijing.gov.cn:8443/app"}
	domains, _, urls := a.interceptCandidates()
	if len(urls) != 1 || urls[0] != a.URL {
		t.Fatalf("urls = %v", urls)
	}
	found := false
	for _, d := range domains {
		if d == "portal.beijing.gov.cn" {
			found = true
		}
	}
	if !found {
		t.Fatalf("URL host not split into domain candidates: %v", domains)
	}
	r, _, ok := MatchAssetInterceptRules([]AssetInterceptRule{rule("fuzzy_domain", ".gov.cn", true)}, domains, nil, urls)
	if !ok {
		t.Fatalf("a government service asset carrying only a URL should be hit by fuzzy_domain, rule=%+v", r)
	}

	// A URL host that is an IP should go into the IP candidates and be hit by CIDR.
	b := &Asset{Type: "service", URL: "http://10.1.2.3/x"}
	_, ips, _ := b.interceptCandidates()
	if r, _, ok := MatchAssetInterceptRules([]AssetInterceptRule{rule("cidr", "10.0.0.0/8", true)}, nil, ips, nil); !ok {
		t.Fatalf("the IP in the URL should be hit by CIDR, ips=%v rule=%+v", ips, r)
	}
}
