// Package db is the PostgreSQL data source for ARTEX (replaces the old single-file
// graph SQLite store). It opens connections, applies the schema, and seeds the
// built-in agents and their variable catalogs.
package db

import (
	"context"
	"database/sql"
	_ "embed"
	"errors"
	"fmt"
	"net/url"
	"strings"
	"time"

	"github.com/Autumn-27/artex/config"
	"github.com/jackc/pgx/v5/pgconn"
	_ "github.com/jackc/pgx/v5/stdlib" // pgx database/sql driver ("pgx")
)

//go:embed schema.sql
var schemaSQL string

const schemaMigrationLockKey int64 = 7337741001

var schemaDeadlockRetryDelays = [...]time.Duration{
	100 * time.Millisecond,
	250 * time.Millisecond,
	500 * time.Millisecond,
	time.Second,
}

type schemaExecer interface {
	ExecContext(context.Context, string, ...any) (sql.Result, error)
}

func isPostgresDeadlock(err error) bool {
	var pgErr *pgconn.PgError
	return errors.As(err, &pgErr) && pgErr.Code == "40P01"
}

func applySchemaWithRetry(ctx context.Context, execer schemaExecer, sleep func(time.Duration)) error {
	for attempt := 0; ; attempt++ {
		if _, err := execer.ExecContext(ctx, schemaSQL); err != nil {
			if !isPostgresDeadlock(err) || attempt >= len(schemaDeadlockRetryDelays) {
				return err
			}
			sleep(schemaDeadlockRetryDelays[attempt])
			continue
		}
		return nil
	}
}

// withSchemaMigrationLock pins the session-level lock to one checked-out
// connection. Running pg_advisory_lock through *sql.DB is incorrect because a
// later schema or unlock call may use a different pooled PostgreSQL session.
func withSchemaMigrationLock(ctx context.Context, sqlDB *sql.DB, action func(*sql.Conn) error) (err error) {
	conn, err := sqlDB.Conn(ctx)
	if err != nil {
		return err
	}
	defer conn.Close()
	if _, err := conn.ExecContext(ctx, `SELECT pg_advisory_lock($1)`, schemaMigrationLockKey); err != nil {
		return fmt.Errorf("advisory lock: %w", err)
	}
	defer func() {
		if _, unlockErr := conn.ExecContext(context.Background(), `SELECT pg_advisory_unlock($1)`, schemaMigrationLockKey); unlockErr != nil && err == nil {
			err = fmt.Errorf("advisory unlock: %w", unlockErr)
		}
	}()
	return action(conn)
}

// coordinateWithSchemaMigration makes long, multi-table archive transactions
// mutually exclusive with startup DDL while allowing ordinary runtime queries
// to continue normally.
func coordinateWithSchemaMigration(tx *sql.Tx) error {
	if _, err := tx.Exec(`SELECT pg_advisory_xact_lock($1)`, schemaMigrationLockKey); err != nil {
		return fmt.Errorf("coordinate with schema migration: %w", err)
	}
	return nil
}

// DSN resolves the PostgreSQL connection string and reports where it came from.
// Precedence: env ARTEX_PG_DSN > config file (config.json). There is no
// built-in default — it errors if neither source is configured.
func DSN() (dsn, source string, err error) {
	return config.PostgresDSN()
}

// DB wraps the shared *sql.DB. PG handles its own connection pool + concurrency
// (MVCC), so unlike the old SQLite store there is no process-wide write mutex.
type DB struct{ *sql.DB }

// ensureDatabase connects to the postgres system database and creates the target
// database if it does not exist. dsn must be a postgres:// URL.
func ensureDatabase(dsn string) error {
	u, err := url.Parse(dsn)
	if err != nil {
		return nil // unparseable DSN — let the normal Open fail with a clear error
	}
	dbName := strings.TrimPrefix(u.Path, "/")
	if dbName == "" || dbName == "postgres" {
		return nil
	}
	// connect to the postgres maintenance database instead
	adminDSN := *u
	adminDSN.Path = "/postgres"
	admin, err := sql.Open("pgx", adminDSN.String())
	if err != nil {
		return nil // best-effort; let Open surface the real error
	}
	defer admin.Close()
	if err := admin.Ping(); err != nil {
		return nil
	}
	var exists bool
	_ = admin.QueryRow(`SELECT true FROM pg_database WHERE datname=$1`, dbName).Scan(&exists)
	if !exists {
		if _, err := admin.Exec(`CREATE DATABASE "` + dbName + `"`); err != nil {
			return fmt.Errorf("create database %q: %w", dbName, err)
		}
	}
	return nil
}

// Open connects, applies the schema (idempotent), and seeds builtin rows.
func Open(dsn string) (*DB, error) {
	if err := ensureDatabase(dsn); err != nil {
		return nil, err
	}
	sqlDB, err := sql.Open("pgx", dsn)
	if err != nil {
		return nil, err
	}
	if err := sqlDB.Ping(); err != nil {
		sqlDB.Close()
		return nil, fmt.Errorf("ping postgres (%s): %w", config.Redact(dsn), err)
	}
	d := &DB{sqlDB}
	// pgx runs multi-statement Exec via the simple protocol when there are no args.
	// Keep the dedicated lock connection checked out until both DDL and seeding
	// finish so concurrent application instances cannot initialize out of order.
	err = withSchemaMigrationLock(context.Background(), sqlDB, func(conn *sql.Conn) error {
		if err := applySchemaWithRetry(context.Background(), conn, time.Sleep); err != nil {
			return fmt.Errorf("apply schema: %w", err)
		}
		if err := d.seedBuiltins(); err != nil {
			return fmt.Errorf("seed builtins: %w", err)
		}
		return nil
	})
	if err != nil {
		sqlDB.Close()
		return nil, err
	}
	return d, nil
}

// builtinAgent describes one of the fixed agents and its prompt-variable catalog.
type builtinAgent struct {
	key, name, role, desc string
	vars                  []promptVar
	interactiveShell      bool // default interactive-shell switch set on insert; ON CONFLICT does not override a later manual toggle
	runSeconds            *int // per-run wall-clock cap in seconds set on insert; nil=seed default (1200), 0=unlimited
}

type promptVar struct{ name, desc, example, source string }

// intp returns a pointer to v, so optional builtinAgent fields (such as runSeconds)
// can be set explicitly.
func intp(v int) *int { return &v }

// builtinAgents mirrors docs §5(a). Built-in tools are not stored in the DB; this
// only seeds the agents and their variable catalogs.
// Note: the interactive shell for planner/worker/mainagent/auto is turned on by the
// interactive_shell_default_v1 block below, which respects a later toggle; the
// interactiveShell here only applies to new agents that must default on at insert.
var builtinAgents = []builtinAgent{
	{"goals", "Goal Breakdown", "goals", "Break a penetration-test goal down into several independent, verifiable sub-goals.", []promptVar{
		{"EngagementDescription", "Engagement description (target/background)", "Test the example.com site", "exploration"},
		// Now is a global runtime variable (see server.globalPromptVars), so it is no
		// longer defined repeatedly in each agent catalog, which would collide with
		// the global entry when withGlobalVars appends it.
	}, false, nil},
	{"planner", "Planning", "planner", "Read the situation, assess the goal, and only add exploration intents when there really is an uncovered new direction (one planning cycle per task).", []promptVar{
		{"Goal", "Overall task goal", "Gain admin access to example.com", "exploration"},
		{"AssetSummary", "Asset count/type distribution summary (optional)", "domain:3 ip:5 site:2", "distilled"},
	}, false, nil},
	{"mainagent", "Main", "main", "Human-machine interface: observe progress and turn human intent into hints or high-priority intents.", []promptVar{
		{"Goal", "Current task goal", "Gain admin access to example.com", "exploration"},
		{"AssetSummary", "Opening situation summary (optional)", "domain:3 ip:5", "distilled"},
		{"FindingsSummary", "Confirmed findings summary (optional)", "high:1 medium:2", "distilled"},
	}, false, nil},
	{"worker", "Execution", "worker", "Claim one intent, execute it, write the facts/findings back to the knowledge graph, then stop.", []promptVar{
		{"ProxyAddr", "Recorded proxy address (drives the if dual-branch wording)", "127.0.0.1:8080", "runtime"},
		{"WorkerName", "Worker self-identifier (optional)", "worker-1", "runtime"},
	}, false, nil},
	// Auto: the built-in "platform operations" agent. It does not join the pentest
	// orchestration loop; it is driven from the chat page and operates the platform
	// through tools.
	{"auto", "Auto", "assistant", "Platform operations assistant: uses tools to manage tasks (create/view/pause/hint) and assets, and can create/modify skills, custom tools, and MCPs.", nil, false, nil},
	// Pentest: the built-in "standalone pentest" agent. Driven from the chat page, a
	// single agent walks the whole pentest chain from recon to wrap-up, planning,
	// executing, and adversarially verifying on its own. Interactive shell defaults on.
	{"pentest", "Pentest", "assistant", "Standalone pentest agent: a single agent walks the whole chain from recon → attack-surface discovery → exploitation → verification → wrap-up, planning, executing, and adversarially verifying on its own.", nil, true, intp(0)},
}

// seedBuiltins inserts the fixed built-in agents and their variable catalog (idempotent).
func (d *DB) seedBuiltins() error {
	for _, a := range builtinAgents {
		var agentID int64
		err := d.QueryRow(`
INSERT INTO agents(key, name, description, role, builtin, enabled, interactive_shell, run_seconds)
VALUES ($1, $2, NULLIF($3,''), $4, true, true, $5, COALESCE($6, 1200))
ON CONFLICT (key) DO UPDATE SET name = EXCLUDED.name, description = EXCLUDED.description
RETURNING id`, a.key, a.name, a.desc, a.role, a.interactiveShell, a.runSeconds).Scan(&agentID)
		if err != nil {
			return fmt.Errorf("agent %s: %w", a.key, err)
		}
		for _, v := range a.vars {
			if _, err := d.Exec(`
INSERT INTO agent_prompt_vars(agent_id, var_name, description, example, source)
VALUES ($1, $2, $3, $4, $5)
ON CONFLICT (agent_id, var_name) DO UPDATE
  SET description = EXCLUDED.description, example = EXCLUDED.example, source = EXCLUDED.source`,
				agentID, v.name, v.desc, v.example, v.source); err != nil {
				return fmt.Errorf("agent %s var %s: %w", a.key, v.name, err)
			}
		}
	}
	// Drop catalog entries for variables that were renamed, so the white-list no
	// longer advertises a name templates can't resolve (EngagementTitle→Description).
	// After 'Now' was promoted from per-agent catalogs to a global runtime variable,
	// old databases still have a leftover 'Now' row under goals that would collide
	// with the global entry (duplicate key in the frontend variable list); purge it too.
	if _, err := d.Exec(`DELETE FROM agent_prompt_vars WHERE var_name IN ('EngagementTitle', 'CoverageGaps', 'Now')`); err != nil {
		return fmt.Errorf("cleanup renamed vars: %w", err)
	}
	// Default-on interactive_shell for the runtime agents (planner/worker/mainagent/auto)
	// ONCE — respects a later user toggle-off (guarded by a settings flag). goals(one-shot
	// decomposer) stays off. Runs after the column exists (schema applied before seed).
	if v, _, _ := d.GetSetting("interactive_shell_default_v1"); v != "true" {
		if _, err := d.Exec(`UPDATE agents SET interactive_shell=true WHERE key IN ('planner','worker','mainagent','auto')`); err != nil {
			return fmt.Errorf("seed interactive_shell defaults: %w", err)
		}
		_ = d.SetSetting("interactive_shell_default_v1", "true")
	}
	// Seed the built-in browser (Playwright) MCP once — DISABLED by default (the user
	// enables it when needed), no proxy by default. The traffic-capture toggle injects/strips
	// the recording proxy + CA at runtime (server.Manager.syncBrowserMCPProxy).
	// Insert only if absent so we never clobber user edits (args/env/enabled/
	// visibility) on restart.
	if _, err := d.Exec(`
INSERT INTO mcp_servers(name, transport, command, args, env, enabled)
VALUES ('browser', 'stdio', 'npx', $1, '{}', false)
ON CONFLICT (name) DO NOTHING`,
		`["@playwright/mcp","--headless"]`); err != nil {
		return fmt.Errorf("seed browser mcp: %w", err)
	}
	// Seed the built-in websearch MCP once — ENABLED by default. It is a remote
	// Streamable-HTTP research service (web fetch/search + GitHub code grep +
	// browser automation). Insert only if absent so we never clobber user edits
	// (url/env/enabled/visibility) on restart. Visibility to every agent is
	// granted separately by seedWebsearchMCPVisibility (needs agent rows, which
	// seedBuiltins above has already created).
	if _, err := d.Exec(`
INSERT INTO mcp_servers(name, transport, url, env, enabled)
VALUES ('websearch', 'http', 'https://mcp.xn--lun-lna.vn/mcp', '{}', true)
ON CONFLICT (name) DO NOTHING`); err != nil {
		return fmt.Errorf("seed websearch mcp: %w", err)
	}
	// NOTE: the placeholder ScopeSentry data-source MCP (empty URL + empty X-API-Key,
	// disabled) is seeded directly in schema.sql §F so a raw `psql < schema.sql` init
	// also gets it. schema.sql is Exec'd on every startup, so it stays idempotent.
	if err := d.seedBuiltinSkillVisibility(); err != nil {
		return fmt.Errorf("seed skill visibility: %w", err)
	}
	if err := d.seedWebsearchMCPVisibility(); err != nil {
		return fmt.Errorf("seed websearch mcp visibility: %w", err)
	}
	if err := d.seedDefaultInterceptRules(); err != nil {
		return fmt.Errorf("seed intercept rules: %w", err)
	}
	if err := d.seedDefaultInterceptRulesV2(); err != nil {
		return fmt.Errorf("seed intercept rules v2: %w", err)
	}
	if err := d.seedDefaultInterceptRulesV3(); err != nil {
		return fmt.Errorf("seed intercept rules v3: %w", err)
	}
	if err := d.seedDefaultAssetInterceptRules(); err != nil {
		return fmt.Errorf("seed asset intercept rules: %w", err)
	}
	if err := d.migrateBuiltinInterceptRulesToSuffix(); err != nil {
		return fmt.Errorf("migrate builtin intercept rules: %w", err)
	}
	return nil
}

// seedDefaultAssetInterceptRules inserts the built-in asset blocklist (suffix
// domain matches for government / education sites) once on first startup. Gated
// by a settings flag so a user's later disable/delete is never resurrected on
// restart — same policy as the intercept-rule seed.
//
// suffix_domain (not fuzzy_domain) is deliberate: a substring match on ".gov"
// also matches ".gov.kh" and ".gov.au" — unrelated countries' registries — which
// silently blocked legitimate in-scope assets. suffix_domain matches only at a
// label boundary.
func (d *DB) seedDefaultAssetInterceptRules() error {
	if v, _, _ := d.GetSetting("asset_intercept_default_rules_v1"); v == "done" {
		return nil
	}
	rules := []struct {
		kind    string
		pattern string
		note    string
	}{
		{"suffix_domain", ".gov", "[Built-in] Government sites (.gov)"},
		{"suffix_domain", ".gov.cn", "[Built-in] Government sites (.gov.cn)"},
		{"suffix_domain", ".edu", "[Built-in] Education sites (.edu)"},
		{"suffix_domain", ".edu.cn", "[Built-in] Education sites (.edu.cn)"},
	}
	for _, r := range rules {
		if _, err := d.Exec(`
INSERT INTO asset_intercept_rules(enabled, kind, pattern, note, builtin)
VALUES (false, $1, $2, $3, true)
ON CONFLICT DO NOTHING`, r.kind, r.pattern, r.note); err != nil {
			return fmt.Errorf("asset rule %q: %w", r.pattern, err)
		}
	}
	return d.SetSetting("asset_intercept_default_rules_v1", "done")
}

// migrateBuiltinInterceptRulesToSuffix rewrites the built-in domain rules from the
// old substring "fuzzy_domain" kind to the boundary-aware "suffix_domain" kind.
// Databases seeded before that kind existed keep the over-broad rule until this
// runs, which made ".gov" block every ".gov.<cc>" government domain. Only rows
// still marked builtin with an unchanged kind are touched — a rule the user
// edited themselves is left alone.
func (d *DB) migrateBuiltinInterceptRulesToSuffix() error {
	if v, _, _ := d.GetSetting("asset_intercept_suffix_migration_v1"); v == "done" {
		return nil
	}
	if _, err := d.Exec(`
UPDATE asset_intercept_rules
   SET kind = 'suffix_domain'
 WHERE builtin = true AND kind = 'fuzzy_domain'
   AND pattern IN ('.gov', '.gov.cn', '.edu', '.edu.cn')`); err != nil {
		return fmt.Errorf("migrate builtin intercept rules: %w", err)
	}
	return d.SetSetting("asset_intercept_suffix_migration_v1", "done")
}

// builtinSkillVisibility maps a shipped skill's directory name → the built-in
// agent keys that should see it by default. The skill FILES themselves live on the
// filesystem (SkillDir, loaded by norma at runtime); DB only carries this visibility
// binding. The full shipped set is curated by role:
//
//	planner  → research/advisory/recon/reasoning/reporting (direction + which skill to dispatch)
//	worker   → recon + every execution skill (bug classes, offensive, AD/wireless/redteam) + fp-check/vuln-reasoning
//	retester → detection + web bug classes + fp-check/vuln-reasoning + report-writing
//	pentest  → everything (solo: its own planner + executor + auditor)
//	mainagent→ report-writing + scopesentry (HITL summary + platform MCP)
//	auto/goals → unchanged (auto manages skills/tools via its own prompt; goals is one-shot)
//
// scopesentry additionally declares `mcps: ScopeSentry`, which only takes effect once
// it's made visible and that MCP is enabled/configured.
var builtinSkillVisibility = map[string][]string{
	// research / advisory / CVE hunting — planner decides direction, pentest does it solo.
	"advisory-mining":   {"planner", "pentest"},
	"bugclass-catalog":  {"planner", "pentest"},
	"chain-builder":     {"planner", "pentest"},
	"cn-0day-hunt":      {"planner", "pentest"},
	"cousin-sweep":      {"planner", "pentest"},
	"cross-pollination": {"planner", "pentest"},
	"cve-watch":         {"planner", "pentest"},
	"lab-builder":       {"planner", "pentest"},
	"oneday-hunt":       {"planner", "pentest"},
	"primitive-harvest": {"planner", "pentest"},
	"pwn-arsenal":       {"planner", "pentest"},
	"variant-analyzer":  {"planner", "pentest"},

	// recon / intel — planner + worker (execution) + pentest.
	"api-recon":                    {"auto", "planner", "worker", "pentest"},
	"target-recon":                 {"planner", "worker", "pentest"},
	"redteam-recon":                {"planner", "worker", "pentest"},
	"offensive-osint":              {"planner", "worker", "pentest"},
	"offensive-osint-methodology":  {"planner", "worker", "pentest"},
	"version-fingerprint":          {"planner", "worker", "pentest"},
	"offensive-fast-checking":      {"planner", "worker", "pentest"},
	"offensive-bug-identification": {"planner", "worker", "pentest"},
	"offensive-vuln-classes":       {"planner", "worker", "pentest"},
	"pentest-toolbox":              {"worker", "pentest"},
	"playwright-cli":               {"planner", "worker", "pentest"},

	// reasoning / meta — everyone who reaches a conclusion about a finding.
	"fp-check":            {"planner", "worker", "retester", "pentest"},
	"vuln-reasoning":      {"planner", "worker", "retester", "pentest"},
	"report-writing":      {"planner", "retester", "mainagent", "pentest"},
	"offensive-reporting": {"planner", "retester", "mainagent", "pentest"},

	// detection primitives — worker + retester (verification) + pentest.
	"auth-bypass":            {"worker", "retester", "pentest"},
	"code-injection-codegen": {"worker", "retester", "pentest"},
	"command-injection":      {"worker", "retester", "pentest"},
	"decompression-bomb":     {"worker", "retester", "pentest"},
	"entity-expansion":       {"worker", "retester", "pentest"},
	"jwt-attacks":            {"worker", "retester", "pentest"},
	"kernel-memcorruption":   {"worker", "retester", "pentest"},
	"method-clobbering":      {"worker", "retester", "pentest"},
	"path-traversal":         {"worker", "retester", "pentest"},
	"prototype-pollution":    {"worker", "retester", "pentest"},
	"recursion-dos":          {"worker", "retester", "pentest"},
	"redos":                  {"worker", "retester", "pentest"},
	"sandbox-escape":         {"worker", "retester", "pentest"},
	"ssrf":                   {"worker", "retester", "pentest"},
	"ssti":                   {"worker", "retester", "pentest"},
	"xxe":                    {"worker", "retester", "pentest"},

	// web / app-layer exploitation — worker + retester + pentest.
	"bypass-arsenal":                 {"worker", "retester", "pentest"},
	"offensive-api-abuse":            {"worker", "retester", "pentest"},
	"offensive-api-security":         {"worker", "retester", "pentest"},
	"offensive-business-logic":       {"worker", "retester", "pentest"},
	"offensive-crypto-attacks":       {"worker", "retester", "pentest"},
	"offensive-dependency-confusion": {"worker", "retester", "pentest"},
	"offensive-deserialization":      {"worker", "retester", "pentest"},
	"offensive-file-upload":          {"worker", "retester", "pentest"},
	"offensive-graphql":              {"worker", "retester", "pentest"},
	"offensive-idor":                 {"worker", "retester", "pentest"},
	"offensive-jwt":                  {"worker", "retester", "pentest"},
	"offensive-oauth":                {"worker", "retester", "pentest"},
	"offensive-open-redirect":        {"worker", "retester", "pentest"},
	"offensive-parameter-pollution":  {"worker", "retester", "pentest"},
	"offensive-race-condition":       {"worker", "retester", "pentest"},
	"offensive-rce":                  {"worker", "retester", "pentest"},
	"offensive-request-smuggling":    {"worker", "retester", "pentest"},
	"offensive-sqli":                 {"worker", "retester", "pentest"},
	"offensive-ssrf":                 {"worker", "retester", "pentest"},
	"offensive-ssti":                 {"worker", "retester", "pentest"},
	"offensive-toctou":               {"worker", "retester", "pentest"},
	"offensive-waf-bypass":           {"worker", "retester", "pentest"},
	"offensive-xss":                  {"worker", "retester", "pentest"},
	"offensive-xxe":                  {"worker", "retester", "pentest"},

	// infra / AD / post-exploit — worker + pentest.
	"offensive-active-directory":    {"worker", "pentest"},
	"offensive-anti-forensics":      {"worker", "pentest"},
	"offensive-basic-exploitation":  {"worker", "pentest"},
	"offensive-c2-frameworks":       {"worker", "pentest"},
	"offensive-cicd-pipeline":       {"worker", "pentest"},
	"offensive-cicd-secrets":        {"worker", "pentest"},
	"offensive-cloud":               {"worker", "pentest"},
	"offensive-container-escape":    {"worker", "pentest"},
	"offensive-crash-analysis":      {"worker", "pentest"},
	"offensive-data-exfiltration":   {"worker", "pentest"},
	"offensive-edr-evasion":         {"worker", "pentest"},
	"offensive-exploit-dev-course":  {"worker", "pentest"},
	"offensive-exploit-development": {"worker", "pentest"},
	"offensive-fuzzing":             {"worker", "pentest"},
	"offensive-fuzzing-course":      {"worker", "pentest"},
	"offensive-initial-access":      {"worker", "pentest"},
	"offensive-iot":                 {"worker", "pentest"},
	"offensive-k8s-attacks":         {"worker", "pentest"},
	"offensive-keylogger-arch":      {"worker", "pentest"},
	"offensive-lateral-movement":    {"worker", "pentest"},
	"offensive-linux-privesc":       {"worker", "pentest"},
	"offensive-mitigations":         {"worker", "pentest"},
	"offensive-mobile":              {"worker", "pentest"},
	"offensive-network-attacks":     {"worker", "pentest"},
	"offensive-persistence":         {"worker", "pentest"},
	"offensive-phishing":            {"worker", "pentest"},
	"offensive-shellcode":           {"worker", "pentest"},
	"offensive-social-engineering":  {"worker", "pentest"},
	"offensive-supply-chain":        {"worker", "pentest"},
	"offensive-tls-attacks":         {"worker", "pentest"},
	"offensive-windows-boundaries":  {"worker", "pentest"},
	"offensive-windows-mitigations": {"worker", "pentest"},
	"offensive-windows-privesc":     {"worker", "pentest"},

	// wireless / RF — worker + pentest.
	"offensive-bluetooth-ble":        {"worker", "pentest"},
	"offensive-bluetooth-classic":    {"worker", "pentest"},
	"offensive-deauth-disassoc":      {"worker", "pentest"},
	"offensive-evil-twin":            {"worker", "pentest"},
	"offensive-krack-fragattacks":    {"worker", "pentest"},
	"offensive-lorawan-sub-ghz":      {"worker", "pentest"},
	"offensive-wifi":                 {"worker", "pentest"},
	"offensive-wifi-recon":           {"worker", "pentest"},
	"offensive-wpa-enterprise":       {"worker", "pentest"},
	"offensive-wpa2-psk":             {"worker", "pentest"},
	"offensive-wpa3-sae":             {"worker", "pentest"},
	"offensive-wps":                  {"worker", "pentest"},
	"offensive-z-wave":               {"worker", "pentest"},
	"offensive-zigbee-thread-matter": {"worker", "pentest"},

	// red team ops (through proxy) — worker + pentest.
	"offensive-advanced-redteam": {"worker", "pentest"},
	"redteam-attack":             {"worker", "pentest"},
	"redteam-bruteforce":         {"worker", "pentest"},
	"redteam-fuzz":               {"worker", "pentest"},

	// AI/LLM security — planner + worker + pentest.
	"offensive-ai-security": {"planner", "worker", "pentest"},

	// platform MCP (ScopeSentry) — planner + mainagent + pentest.
	"scopesentry": {"planner", "mainagent", "pentest"},
}

// seedBuiltinSkillVisibility binds the shipped built-in skills to their default
// agents. Insert-if-absent (ON CONFLICT DO NOTHING) so a user's later toggle-off is
// never resurrected on restart — matches the browser-MCP / intercept-rule seed policy.
func (d *DB) seedBuiltinSkillVisibility() error {
	for skillName, agentKeys := range builtinSkillVisibility {
		for _, key := range agentKeys {
			if _, err := d.Exec(`
INSERT INTO agent_skill_visibility(agent_id, skill_name, enabled)
SELECT id, $2, true FROM agents WHERE key=$1
ON CONFLICT (agent_id, skill_name) DO NOTHING`, key, skillName); err != nil {
				return fmt.Errorf("skill %s → agent %s: %w", skillName, key, err)
			}
		}
	}
	return nil
}

// SeedSkillVisibilityForAgent binds one agent key to its curated built-in skills
// (insert-if-absent). Used to backfill an agent whose row is created AFTER
// seedBuiltinSkillVisibility ran on a fresh boot — notably the "retester" agent,
// which seedFindingRetester creates in a later startup phase. Idempotent, so it can
// be called every startup; a user's later toggle-off is never resurrected.
func (d *DB) SeedSkillVisibilityForAgent(agentKey string) error {
	for skillName, agentKeys := range builtinSkillVisibility {
		for _, key := range agentKeys {
			if key != agentKey {
				continue
			}
			if _, err := d.Exec(`
INSERT INTO agent_skill_visibility(agent_id, skill_name, enabled)
SELECT id, $2, true FROM agents WHERE key=$1
ON CONFLICT (agent_id, skill_name) DO NOTHING`, agentKey, skillName); err != nil {
				return fmt.Errorf("skill %s → agent %s: %w", skillName, agentKey, err)
			}
		}
	}
	return nil
}

// seedWebsearchMCPVisibility makes the built-in websearch MCP visible to EVERY
// agent (built-in and custom). Runs on startup, so it also covers custom agents
// created after the first boot — each gets the binding on the next restart.
// Insert-if-absent per (agent, mcp) so a user's later toggle-off is never
// resurrected — same policy as seedBuiltinSkillVisibility. No-op when the
// websearch server row is absent (a user deleted it).
func (d *DB) seedWebsearchMCPVisibility() error {
	_, err := d.Exec(`
INSERT INTO agent_visibility(agent_id, resource_kind, resource_id, enabled)
SELECT a.id, 'mcp', m.id, true
FROM agents a CROSS JOIN mcp_servers m
WHERE m.name = 'websearch'
ON CONFLICT (agent_id, resource_kind, resource_id, mcp_tool_name) DO NOTHING`)
	if err != nil {
		return fmt.Errorf("websearch mcp visibility: %w", err)
	}
	return nil
}

// seedDefaultInterceptRules inserts built-in safety intercept rules once on
// first startup. The seed is gated by a settings flag so user edits (disable,
// delete, re-order) are never overwritten on subsequent restarts.
func (d *DB) seedDefaultInterceptRules() error {
	if v, _, _ := d.GetSetting("intercept_default_rules_v1"); v == "done" {
		return nil
	}
	type rule struct {
		name     string
		target   string // tool_name | tool_input
		typ      string // string | regex
		pattern  string
		action   string
		message  string
		priority int
	}
	rules := []rule{
		// ── Destructive system commands (priority 100) ─────────────────────
		{
			name:     "[Built-in] Recursive force delete rm -rf",
			target:   "tool_input",
			typ:      "regex",
			pattern:  `(?i)\brm\b.{0,80}(?:-[a-z]*r[a-z]*f[a-z]*|-[a-z]*f[a-z]*r[a-z]*|--recursive|--no-preserve-root)`,
			action:   "deny",
			message:  "Recursive force deletion is forbidden (rm -rf / rm --recursive); it can permanently damage the system or the target environment",
			priority: 100,
		},
		{
			name:     "[Built-in] Delete critical system directories",
			target:   "tool_input",
			typ:      "regex",
			pattern:  `\brm\b[^"'\n]{0,60}["'\s](/|/etc|/bin|/usr|/boot|/var|/lib|/sys|/proc|/dev|/sbin|/root)`,
			action:   "deny",
			message:  "Deleting critical system paths is forbidden",
			priority: 100,
		},
		{
			name:     "[Built-in] Disk format mkfs",
			target:   "tool_input",
			typ:      "regex",
			pattern:  `\bmkfs\b`,
			action:   "deny",
			message:  "Formatting a disk (mkfs) is forbidden",
			priority: 100,
		},
		{
			name:     "[Built-in] Overwrite disk device dd",
			target:   "tool_input",
			typ:      "regex",
			pattern:  `\bdd\b[^|\n]{0,100}\bof=\s*/dev/[a-zA-Z]`,
			action:   "deny",
			message:  "Using dd to overwrite a disk device is forbidden",
			priority: 100,
		},
		{
			name:     "[Built-in] Fork bomb",
			target:   "tool_input",
			typ:      "regex",
			pattern:  `:\(\)\s*\{[^}]*:\|:`,
			action:   "deny",
			message:  "Running a fork bomb is forbidden",
			priority: 100,
		},
		{
			name:     "[Built-in] Shutdown / reboot",
			target:   "tool_input",
			typ:      "regex",
			pattern:  `\b(?:shutdown|reboot|halt|poweroff|init\s+[06])\b`,
			action:   "deny",
			message:  "Shutdown or reboot commands are forbidden",
			priority: 100,
		},
		{
			name:     "[Built-in] Kill all processes",
			target:   "tool_input",
			typ:      "regex",
			pattern:  `\bkill\s+-9\s+-1\b|\bkillall\s+-9\b`,
			action:   "deny",
			message:  "kill -9 -1 or killall -9 (killing all processes) is forbidden",
			priority: 100,
		},
		{
			name:     "[Built-in] Disk wipe shred / wipe",
			target:   "tool_input",
			typ:      "regex",
			pattern:  `\b(?:shred|wipe)\b[^|\n]{0,80}/dev/[a-zA-Z]`,
			action:   "deny",
			message:  "Running shred/wipe on a disk device is forbidden",
			priority: 100,
		},
		{
			name:     "[Built-in] Flush firewall rules",
			target:   "tool_input",
			typ:      "regex",
			pattern:  `\biptables\s+(?:-F|--flush)\b|\bnft\s+flush\s+ruleset\b`,
			action:   "deny",
			message:  "Flushing firewall rules is forbidden (iptables -F / nft flush)",
			priority: 100,
		},
		// ── Destructive database operations (priority 90) ──────────────────
		{
			name:     "[Built-in] SQL DROP DATABASE / TABLE / SCHEMA",
			target:   "tool_input",
			typ:      "regex",
			pattern:  `(?i)\bDROP\s+(?:DATABASE|TABLE|SCHEMA|INDEX|VIEW|TABLESPACE|USER|ROLE)\b`,
			action:   "deny",
			message:  "Running a DROP is forbidden; it may irreversibly destroy database objects",
			priority: 90,
		},
		{
			name:     "[Built-in] SQL TRUNCATE",
			target:   "tool_input",
			typ:      "regex",
			pattern:  `(?i)\bTRUNCATE\s+(?:TABLE\s+)?\w`,
			action:   "deny",
			message:  "Running TRUNCATE is forbidden; it may empty all data in a table",
			priority: 90,
		},
		{
			name:     "[Built-in] MongoDB drop / dropDatabase",
			target:   "tool_input",
			typ:      "regex",
			pattern:  `(?i)\.(?:dropDatabase|dropCollection|drop)\s*\(`,
			action:   "deny",
			message:  "Running a MongoDB drop is forbidden",
			priority: 90,
		},
		{
			name:     "[Built-in] Redis FLUSHALL / FLUSHDB",
			target:   "tool_input",
			typ:      "regex",
			pattern:  `(?i)\b(?:FLUSHALL|FLUSHDB)\b`,
			action:   "deny",
			message:  "Running Redis FLUSHALL / FLUSHDB is forbidden; it may empty all cached data",
			priority: 90,
		},
		// ── Destructive HTTP requests (priority 80) ────────────────────────
		// Three common ways an agent sends a DELETE request:
		//   1. curl -X DELETE / --request DELETE (run directly by the Bash tool or written into a script)
		//   2. Python HTTP client .delete() method
		//   3. method: 'DELETE' / method="DELETE" in JS/generic scripts
		{
			name:     "[Built-in] curl / wget sends a DELETE request",
			target:   "tool_input",
			typ:      "regex",
			pattern:  `(?i)\bcurl\b[^|\n&;"]{0,300}(?:-X\s*DELETE|--request\s+DELETE|-XDELETE)|\bwget\b[^|\n&;"]{0,300}--method[=\s]+DELETE`,
			action:   "deny",
			message:  "Sending an HTTP DELETE request via curl/wget is forbidden; it may delete data on the target system",
			priority: 80,
		},
		{
			name:     "[Built-in] Python HTTP client DELETE (requests/httpx/aiohttp)",
			target:   "tool_input",
			typ:      "regex",
			pattern:  `(?i)\b(?:requests|httpx|aiohttp|urllib\.request)\.delete\s*\(|session\.delete\s*\(|client\.delete\s*\(`,
			action:   "deny",
			message:  "Sending a DELETE request with a Python HTTP client is forbidden",
			priority: 80,
		},
		{
			name:     "[Built-in] Script declares an HTTP DELETE method (JS/generic)",
			target:   "tool_input",
			typ:      "regex",
			pattern:  `(?i)axios\.delete\s*\(|method\s*[:=]\s*['"]DELETE['"]`,
			action:   "deny",
			message:  "Declaring and sending an HTTP DELETE request in a script is forbidden",
			priority: 80,
		},
		{
			name:     "[Built-in] Bulk clear / wipe endpoint paths",
			target:   "tool_input",
			typ:      "regex",
			pattern:  `(?i)/(?:clear|wipe|flush|purge|truncate|drop|destroy|factory[-_]reset|reset[-_]all)(?:[/?#"'\s]|$)`,
			action:   "deny",
			message:  "Calling bulk-clear or destructive endpoints is forbidden (/clear /wipe /flush /purge, etc.)",
			priority: 80,
		},
	}
	for _, r := range rules {
		if _, err := d.Exec(`
INSERT INTO intercept_rules(name, enabled, priority, match_target, match_type, pattern, action, message, timeout_enabled, timeout_seconds, timeout_action)
VALUES ($1, false, $2, $3, $4, $5, $6, $7, false, 60, 'deny')
ON CONFLICT DO NOTHING`,
			r.name, r.priority, r.target, r.typ, r.pattern, r.action, r.message,
		); err != nil {
			return fmt.Errorf("rule %q: %w", r.name, err)
		}
	}
	return d.SetSetting("intercept_default_rules_v1", "done")
}

// seedDefaultInterceptRulesV2 migrates the two safety patterns that used to be
// hard-coded in guard.go (destructive shell + data-exfil pipe) into ordinary
// intercept rules. Gated by its own flag so it also lands on DBs that already ran
// v1. Unlike the old guard.go floor, these are plain [Built-in] rules — the user can
// disable or delete them. The exfil rule ships DISABLED by default (its
// curl/wget/nc pipe pattern mis-fires on legitimate CTF/pentest reverse-shell and
// data-transfer pipes); enable it manually when exfil gating is actually wanted.
func (d *DB) seedDefaultInterceptRulesV2() error {
	if v, _, _ := d.GetSetting("intercept_default_rules_v2"); v == "done" {
		return nil
	}
	rules := []struct {
		name     string
		pattern  string
		action   string
		message  string
		enabled  bool
		priority int
	}{
		{
			name:     "[Built-in] Destructive system commands",
			pattern:  `(?i)\b(rm\s+-rf\s+/|mkfs|dd\s+if=|:\(\)\s*\{|shutdown|reboot|>\s*/dev/sd)`,
			action:   "deny",
			message:  "Destructive command denied (rm -rf / / mkfs / dd / fork bomb / shutdown-reboot / overwriting a disk device)",
			enabled:  false,
			priority: 100,
		},
		{
			name:     "[Built-in] Data-exfiltration pipe",
			pattern:  `(?i)(curl|wget|nc|ncat)\b[^|]*\b(\|\s*(curl|wget|nc))`,
			action:   "deny",
			message:  "Suspected data-exfiltration pipe denied (command output sent out via curl/wget/nc)",
			enabled:  false,
			priority: 80,
		},
	}
	for _, r := range rules {
		if _, err := d.Exec(`
INSERT INTO intercept_rules(name, enabled, priority, match_target, match_type, pattern, action, message, timeout_enabled, timeout_seconds, timeout_action)
VALUES ($1, $2, $3, 'tool_input', 'regex', $4, $5, $6, false, 60, 'deny')
ON CONFLICT DO NOTHING`,
			r.name, r.enabled, r.priority, r.pattern, r.action, r.message,
		); err != nil {
			return fmt.Errorf("rule %q: %w", r.name, err)
		}
	}
	return d.SetSetting("intercept_default_rules_v2", "done")
}

// seedDefaultInterceptRulesV3 adds the delete-endpoint path rule. The v1 HTTP rules
// only catch the DELETE *method* (curl -X DELETE, requests.delete(, method:'DELETE'),
// and v1's path rule covers only /clear /wipe /flush /purge /truncate /drop /destroy
// /factory-reset /reset-all — so a plain `curl 'http://t/api/user/delete?id=1'` (a
// delete endpoint reached with GET/POST, which is how most web apps expose deletion)
// slipped through every built-in rule. Own flag so it also lands on DBs that already
// ran v1/v2, where editing the v1 seed would have no effect.
//
// The pattern deliberately requires a separator after the verb so /delivery,
// /details, /delta and /delegate do not match, while /deleteAll, /delete_user and
// /delete-user do. destroy is re-covered here because v1's rule does not allow a
// suffix (/destroyAll was missed).
//
// Exported as a package const only so the seeded regex is unit-testable without a DB.
const deleteEndpointPathPattern = `(?i)/(?:(?:delete|remove|unlink|erase|destroy)[-\w]*|del)(?:[/?#"'\s]|$)`

func (d *DB) seedDefaultInterceptRulesV3() error {
	if v, _, _ := d.GetSetting("intercept_default_rules_v3"); v == "done" {
		return nil
	}
	const name = "[Built-in] Delete-class endpoint paths"
	if _, err := d.Exec(`
INSERT INTO intercept_rules(name, enabled, priority, match_target, match_type, pattern, action, message, timeout_enabled, timeout_seconds, timeout_action)
SELECT $1, false, 80, 'tool_input', 'regex', $2, 'deny', $3, false, 60, 'deny'
WHERE NOT EXISTS (SELECT 1 FROM intercept_rules WHERE name = $1)`,
		name,
		deleteEndpointPathPattern,
		"Calling delete-class endpoints is forbidden (/delete /remove /unlink /erase, etc.), regardless of the HTTP method — most applications expose deletion through GET/POST, which also really deletes the target data",
	); err != nil {
		return fmt.Errorf("rule %q: %w", name, err)
	}
	return d.SetSetting("intercept_default_rules_v3", "done")
}
