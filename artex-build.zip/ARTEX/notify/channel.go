package notify

import (
	"context"
	"errors"
	"sort"
	"strconv"
	"strings"
)

// Channel is a notification channel adapter. Implementations must be
// **stateless**: the same instance is reused concurrently by multiple channel
// configs, and credentials are always passed in via the cfg parameter.
type Channel interface {
	// Kind returns the channel type identifier, which must match the registry key.
	Kind() string
	// Validate is called when saving config, checking required fields and format.
	// The returned error is shown directly to the configurer, so the wording should
	// say "which field is missing" rather than a vague "invalid config".
	Validate(cfg map[string]any) error
	// Send delivers one message and returns the **number of items actually
	// delivered** plus an error.
	//
	// Why return a count: every platform has a message length limit, and a digest
	// message that doesn't fit the whole batch gets truncated. If the caller
	// unconditionally marked the whole batch delivered, the truncated items would
	// vanish — invisible in the message and shown as successful in the delivery
	// history, with no place to discover that a vulnerability was never sent. With
	// kept returned, the caller marks only the first kept items, leaving the rest
	// for the next batch.
	//
	// A returned error means delivery failed, where *PermanentError means it should
	// not be retried. On failure kept is meaningless and the caller should ignore it.
	Send(ctx context.Context, cfg map[string]any, m Message) (int, error)
	// DefaultRatePerMin returns the channel's officially recommended per-minute
	// delivery cap, as the default rate limit for a new channel instance. Returning
	// 0 means no known limit.
	DefaultRatePerMin() int
	// SecretKeys returns the names of keys in this channel's config that are
	// credentials. These keys' values are masked when echoed by the API, and their
	// stored values are kept when a masked value is received on update. Only the
	// implementation knows which fields count as credentials (WeCom's entire webhook
	// address is the credential, whereas DingTalk's is only the secret within it),
	// so this knowledge must come from the channel, not be guessed by the caller.
	SecretKeys() []string
	// DestinationKeys returns the names of keys in this channel's config that
	// determine "where messages are sent".
	//
	// Like SecretKeys, this is security-related: the destination address and the
	// credentials are two independent sets of fields, and allowing "change only the
	// address, keep the credentials as-is" would let anyone who can edit the channel
	// config send the stored real credentials to a server they control, making the
	// channel config's masking entirely pointless. See PrepareConfigUpdate.
	DestinationKeys() []string
}

// registry is the channel registry. An explicit literal is deliberately used
// instead of init() self-registration: this way "which channels exist" is visible
// in one place, and adding a channel surfaces omissions at compile time rather
// than through runtime side effects.
var registry = map[string]Channel{
	KindDingTalk: dingTalkChannel{},
	KindFeishu:   feishuChannel{},
	KindWeCom:    weComChannel{},
	KindWebhook:  webhookChannel{},
	KindTelegram: telegramChannel{},
	KindEmail:    emailChannel{},
}

// Get fetches a channel implementation by type.
func Get(kind string) (Channel, bool) {
	c, ok := registry[kind]
	return c, ok
}

// ValidKind reports whether kind is a supported channel type.
func ValidKind(kind string) bool {
	_, ok := registry[kind]
	return ok
}

// Kinds returns all supported channel types, sorted lexicographically (for a
// stable UI dropdown).
func Kinds() []string {
	out := make([]string, 0, len(registry))
	for k := range registry {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}

// PermanentError marks a delivery failure that should not be retried: bad
// credentials, target rejection, invalid request body, etc. Retrying only makes
// sense for transient faults (network jitter, rate limits, peer 5xx); repeatedly
// backing off and retrying a permanent failure won't succeed and drowns the real
// error in the retry log.
type PermanentError struct{ Err error }

func (e *PermanentError) Error() string { return e.Err.Error() }
func (e *PermanentError) Unwrap() error { return e.Err }

// Permanent marks err as a permanent failure. It returns nil when err is nil, so
// it can be written as `return Permanent(someCheck())`.
func Permanent(err error) error {
	if err == nil {
		return nil
	}
	return &PermanentError{Err: err}
}

// IsPermanent reports whether err's chain carries the permanent-failure marker.
func IsPermanent(err error) bool {
	var pe *PermanentError
	return errors.As(err, &pe)
}

// ---- config-reading helpers ----
//
// Channel config comes from a database JSONB column, and after encoding/json
// deserialization is a map[string]any where numbers are always float64 and arrays
// are []any. The helpers below unify that conversion layer and tolerate the type
// deviations caused by users leaving things blank in the UI (e.g. entering a port
// as a string).

// cfgString reads a string config item, always trimming surrounding whitespace —
// easily picked up when copy-pasting from a web form.
func cfgString(cfg map[string]any, key string) string {
	v, ok := cfg[key]
	if !ok {
		return ""
	}
	s, ok := v.(string)
	if !ok {
		return ""
	}
	return strings.TrimSpace(s)
}

// cfgInt reads an integer config item, accepting both float64 (JSON default) and
// string sources.
func cfgInt(cfg map[string]any, key string) int {
	switch v := cfg[key].(type) {
	case float64:
		return int(v)
	case int:
		return v
	case string:
		n, err := strconv.Atoi(strings.TrimSpace(v))
		if err != nil {
			return 0
		}
		return n
	default:
		return 0
	}
}

// cfgBool reads a boolean config item, accepting the strings "true"/"1".
func cfgBool(cfg map[string]any, key string) bool {
	switch v := cfg[key].(type) {
	case bool:
		return v
	case string:
		s := strings.ToLower(strings.TrimSpace(v))
		return s == "true" || s == "1" || s == "yes"
	default:
		return false
	}
}

// cfgStrings reads a string-array config item, trimming whitespace and dropping
// empty strings.
func cfgStrings(cfg map[string]any, key string) []string {
	raw, ok := cfg[key].([]any)
	if !ok {
		// A single string is also accepted, handy for form submissions with one
		// value only.
		if s := cfgString(cfg, key); s != "" {
			return []string{s}
		}
		return nil
	}
	out := make([]string, 0, len(raw))
	for _, v := range raw {
		s, ok := v.(string)
		if !ok {
			continue
		}
		if s = strings.TrimSpace(s); s != "" {
			out = append(out, s)
		}
	}
	return out
}

// cfgMap reads a string-map config item (e.g. custom HTTP headers), trimming both
// keys and values and dropping empty keys.
func cfgMap(cfg map[string]any, key string) map[string]string {
	raw, ok := cfg[key].(map[string]any)
	if !ok {
		return nil
	}
	out := make(map[string]string, len(raw))
	for k, v := range raw {
		k = strings.TrimSpace(k)
		if k == "" {
			continue
		}
		s, ok := v.(string)
		if !ok {
			continue
		}
		out[k] = s
	}
	return out
}
