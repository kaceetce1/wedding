package notify

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"net/url"
	"strconv"
	"time"
)

// dingTalkChannel implements the DingTalk custom robot.
//
// Platform characteristics (which drive the implementation choices here):
//   - A single robot is rate-limited to 20 messages/minute, and excess sends are
//     silently dropped (HTTP may still be 200), so rate limiting must be done on
//     the client, see DefaultRatePerMin.
//   - One of three security settings: sign / custom keyword / IP allowlist. Signing
//     is the only option that doesn't depend on the message content, so only
//     signing is supported (a bare webhook with all three off is also supported).
//   - Both success and failure return HTTP 200, distinguished by the errcode in the
//     body — not checking errcode would record a delivery failure as success.
type dingTalkChannel struct{}

func (dingTalkChannel) Kind() string { return KindDingTalk }

func (dingTalkChannel) DefaultRatePerMin() int { return 20 }

// DingTalk's webhook address carries an access_token and is itself a credential, so
// it is masked as a whole.
func (dingTalkChannel) SecretKeys() []string { return []string{"webhook", "secret"} }

// The target is DingTalk's webhook address itself; changing the address requires
// re-stating the signing secret for the new address at the same time.
func (dingTalkChannel) DestinationKeys() []string { return []string{"webhook"} }

func (dingTalkChannel) Validate(cfg map[string]any) error {
	hook := cfgString(cfg, "webhook")
	if hook == "" {
		return errors.New("missing Webhook address")
	}
	if err := validateHTTPURL(hook); err != nil {
		return fmt.Errorf("invalid Webhook address: %w", err)
	}
	return nil
}

// Send delivers one message. With a backlink and a single item it uses an
// ActionCard (with a button), otherwise markdown.
func (c dingTalkChannel) Send(ctx context.Context, cfg map[string]any, m Message) (int, error) {
	hook := cfgString(cfg, "webhook")
	if err := c.Validate(cfg); err != nil {
		return 0, Permanent(err)
	}
	endpoint, err := dingTalkSignedURL(hook, cfgString(cfg, "secret"), time.Now())
	if err != nil {
		return 0, Permanent(err)
	}

	title := markdownTitle(m)
	// DingTalk markdown body has no clear byte limit, but a cap is still applied to
	// guard against an evidence field ballooning abnormally.
	text, kept := markdownBody(m, 20000)

	var payload any
	if !m.Batch && len(m.Items) == 1 && m.Items[0].DetailURL != "" {
		payload = map[string]any{
			"msgtype": "actionCard",
			"actionCard": map[string]any{
				"title":          title,
				"text":           text,
				"btnOrientation": "0",
				"singleTitle":    "View details",
				"singleURL":      m.Items[0].DetailURL,
			},
		}
	} else {
		payload = map[string]any{
			"msgtype":  "markdown",
			"markdown": map[string]any{"title": title, "text": text},
		}
	}

	raw, err := doJSON(ctx, "POST", endpoint, nil, payload)
	if err != nil {
		return 0, err
	}
	// DingTalk hides business errors inside a 200 response.
	var res struct {
		ErrCode int    `json:"errcode"`
		ErrMsg  string `json:"errmsg"`
	}
	if err := json.Unmarshal(raw, &res); err != nil {
		return 0, fmt.Errorf("failed to parse DingTalk response: %w (%s)", err, snippet(raw))
	}
	if res.ErrCode != 0 {
		// 301000 is a signature verification failure, 310000 is a keyword mismatch —
		// both are config errors and retrying won't self-heal.
		return 0, Permanent(fmt.Errorf("DingTalk returned error %d: %s", res.ErrCode, res.ErrMsg))
	}
	return kept, nil
}

// dingTalkSignedURL appends timestamp and sign parameters to the webhook per the
// official signing rules.
//
// Rule: the string to sign = timestamp + "\n" + secret, the HMAC-SHA256 **key is
// also secret**, and the result is base64-encoded then URL-encoded. timestamp is
// in milliseconds. An empty secret returns the hook unchanged, to support robots
// with signing disabled.
func dingTalkSignedURL(hook, secret string, now time.Time) (string, error) {
	if secret == "" {
		return hook, nil
	}
	ts := strconv.FormatInt(now.UnixMilli(), 10)
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(ts + "\n" + secret))
	sign := base64.StdEncoding.EncodeToString(mac.Sum(nil))

	u, err := url.Parse(hook)
	if err != nil {
		// err must not be passed through: url.Parse's error text carries the full
		// address (including the access_token).
		return "", fmt.Errorf("failed to parse Webhook address: %s", redactRequestTarget(hook))
	}
	q := u.Query()
	q.Set("timestamp", ts)
	q.Set("sign", sign)
	u.RawQuery = q.Encode()
	return u.String(), nil
}

// validateHTTPURL validates that the address is usable and the scheme is
// supported, and does an internal-address check for literal IP targets.
//
// Two things to note:
//
//  1. **The error message must be redacted.** url.Parse itself returns a *url.Error
//     whose Error() carries the **full original address**, and this feature's
//     vendors' addresses have credentials embedded in them (DingTalk access_token,
//     WeCom key, Telegram bot token, Feishu hook id). There was once a plain
//     `return err` here, so the "invalid address format" error leaked the
//     credential, flowing to the test endpoint's 400 response, the last_error
//     stored on every delivery, the server log, and the delivery history endpoint.
//
//  2. **A literal IP is judged internal directly**, while domains are left to the
//     dial stage (blockInternalDial is the point where it actually takes effect and
//     also covers DNS rebinding). Doing it here is so the hint is available when
//     saving config, rather than waiting for the first delivery to fail.
//
// Restricting the scheme is defensive: file:///gopher:// etc. cause unexpected
// behavior in http.Client (though already blocked by the scheme check, there's no
// reason to open up this surface).
func validateHTTPURL(raw string) error {
	u, err := url.Parse(raw)
	if err != nil {
		return fmt.Errorf("address cannot be parsed (%s)", redactRequestTarget(raw))
	}
	if u.Scheme != "http" && u.Scheme != "https" {
		return fmt.Errorf("only http/https are supported, got %q", u.Scheme)
	}
	if u.Host == "" {
		return errors.New("missing hostname")
	}
	if ip := net.ParseIP(u.Hostname()); ip != nil && isBlockedDialIP(ip) && !allowLocalTargets() {
		return fmt.Errorf("refusing to deliver to a local/link-local address %s (if you really need to deliver to a local service, set %s=1)", ip, AllowLocalTargetsEnv)
	}
	return nil
}
