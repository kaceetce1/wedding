package notify

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
)

// weComMarkdownLimit is the hard cap on a WeCom group robot's markdown content
// (bytes, not characters). This is the tightest limit of all six channels, and the
// main reason TruncateBytes exists.
const weComMarkdownLimit = 4096

// weComChannel implements the WeCom group robot.
//
// Platform characteristics:
//   - It authenticates solely via the key in the URL and doesn't support signing —
//     so the webhook address itself is the entire credential.
//   - markdown content is capped at 4096 **bytes**, and an overlong one is rejected
//     whole (not truncated). A CJK character is 3 bytes, meaning only about a
//     thousand characters of body can be written, so client-side truncation is
//     required.
//   - Rate-limited to 20 messages/minute, likewise backed by client-side limiting.
type weComChannel struct{}

func (weComChannel) Kind() string { return KindWeCom }

func (weComChannel) DefaultRatePerMin() int { return 20 }

// WeCom has only one credential, the webhook (the key in the URL), and it doesn't
// support signing — the whole address is the credential, and no other field needs
// masking.
func (weComChannel) SecretKeys() []string { return []string{"webhook"} }

// WeCom has only one field, the webhook, which is both the destination and the
// credential, so there's no such thing as a "credential left over after the
// address changed".
func (weComChannel) DestinationKeys() []string { return []string{"webhook"} }

func (weComChannel) Validate(cfg map[string]any) error {
	hook := cfgString(cfg, "webhook")
	if hook == "" {
		return errors.New("missing Webhook address")
	}
	if err := validateHTTPURL(hook); err != nil {
		return fmt.Errorf("invalid Webhook address: %w", err)
	}
	return nil
}

func (c weComChannel) Send(ctx context.Context, cfg map[string]any, m Message) (int, error) {
	if err := c.Validate(cfg); err != nil {
		return 0, Permanent(err)
	}
	// A digest batch can be long (50 items × one line each + prefix), easily over
	// 4096 bytes. Truncation is done here rather than relying on the platform's
	// error: rejection means losing the entire batch, while truncation at least
	// delivers the first several items.
	content, kept := markdownBody(m, weComMarkdownLimit)
	payload := map[string]any{
		"msgtype":  "markdown",
		"markdown": map[string]any{"content": content},
	}
	raw, err := doJSON(ctx, "POST", cfgString(cfg, "webhook"), nil, payload)
	if err != nil {
		return 0, err
	}
	var res struct {
		ErrCode int    `json:"errcode"`
		ErrMsg  string `json:"errmsg"`
	}
	if err := json.Unmarshal(raw, &res); err != nil {
		return 0, fmt.Errorf("failed to parse WeCom response: %w (%s)", err, snippet(raw))
	}
	if res.ErrCode != 0 {
		// 45009 means the API call limit was exceeded — the platform's rate limit
		// window rolls, so retrying after backoff is effective, so it is explicitly
		// classified as retryable. Reaching here means the client's rate_per_min is
		// set too aggressively; the retry is only a backstop, and the real fix is to
		// lower that channel's rate limit.
		if res.ErrCode == 45009 {
			return 0, fmt.Errorf("WeCom rate limit %d: %s", res.ErrCode, res.ErrMsg)
		}
		// 93000 means the webhook key is invalid — a permanent failure, retrying
		// won't self-heal.
		return 0, Permanent(fmt.Errorf("WeCom returned error %d: %s", res.ErrCode, res.ErrMsg))
	}
	return kept, nil
}
