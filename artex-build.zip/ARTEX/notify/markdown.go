package notify

import (
	"fmt"
	"strings"
)

// This file is the message rendering shared by the "Markdown family" channels
// (DingTalk, WeCom). Feishu uses card JSON, Telegram uses HTML, and email uses
// HTML, each rendered in its own adapter.

// maxAssetsShown is the maximum number of assets listed in a message. A
// vulnerability may be anchored to dozens of assets, and listing them all would
// burst the message with no informational value — nobody reads domains past the
// fourth one in an IM.
const maxAssetsShown = 3

// maxSummaryRunes is how many characters a summary is compressed to. An IM message
// is a "go look at the details" prompt, not the report itself; the full content is
// in the platform.
const maxSummaryRunes = 120

// markdownReservedBytes is held back for the message header (digest line + severity
// distribution + possible truncation notice) and footer (platform link). When
// packing whole items it is subtracted from the budget so the header and footer
// aren't truncated — once they are, the reader can't even tell "which batch this
// is, or how many items aren't shown".
const markdownReservedBytes = 320

// markdownEscape escapes markdown metacharacters.
//
// Why it's necessary: the vulnerability title, summary, class and asset display
// names all come from **untrusted sources** — the title and summary come from
// model output (the model reads the target's responses), and the asset url is the
// full URL obtained by scanning (including the target-controlled query string).
// Without escaping, a vulnerability whose title is
//
//	Login SQL injection\n[Urgent: verify your account here](http://attacker.tld)
//
// would render as a **clickable external link** in the security engineer's
// DingTalk/Feishu; and `![](http://attacker.tld/beacon)` would be fetched by the
// client at render time, effectively announcing "this vulnerability has been
// viewed" and leaking the reader's IP. Even for innocuous content, injected bold
// or block quotes can push the high-severity vulnerability below out of the
// collapsed preview.
//
// The escape set covers the characters in titles/links/emphasis/lists/quotes/
// strikethrough that change structure or produce clickable elements. `\` must be
// handled first, otherwise it would re-escape the backslashes added afterwards.
func markdownEscape(s string) string {
	replacer := strings.NewReplacer(
		`\`, `\\`,
		"`", "\\`",
		"*", `\*`,
		"_", `\_`,
		"[", `\[`,
		"]", `\]`,
		"(", `\(`,
		")", `\)`,
		"!", `\!`,
		"#", `\#`,
		">", `\>`,
		"|", `\|`,
		"~", `\~`,
	)
	return replacer.Replace(s)
}

// markdownText collapses untrusted text into a single line and escapes it, for
// markdown body text. Single-lining is the other half beyond escaping: a newline
// alone can forge a new list item or block quote, and escape characters don't
// stop that.
func markdownText(s string, maxRunes int) string {
	return markdownEscape(OneLine(s, maxRunes))
}

// markdownTitle returns the message title (the IM platform's title bar/card
// title); the content is the **unescaped original text**.
//
// Escaping is deliberately not done here: this title is shared by renderers in
// four contexts — markdown body, Telegram's HTML, Feishu card's plain_text, and
// the generic webhook's JSON and email subject. Each context has different escape
// rules (markdown escapes in HTML leave visible backslashes, in JSON they corrupt
// the data), so escaping must be the responsibility of each output end, see
// writeItem / feishuItemLines / telegramEscape. Markdown escaping was once added
// in the shared function, and the result was visible backslashes like `\(1\)` in
// Telegram messages.
func markdownTitle(m Message) string {
	if m.Batch {
		return fmt.Sprintf("Vulnerability digest · %d total", len(m.Items))
	}
	if len(m.Items) == 0 {
		return "Vulnerability notification"
	}
	it := m.Items[0]
	return fmt.Sprintf("[%s] %s", SeverityLabel(it.Severity), OneLine(it.Title(), 0))
}

// markdownBody renders the message body and returns the body plus the **number of
// items actually written**.
//
// The returned kept is the number of items truly delivered by this send, and the
// caller marks only the first kept items as delivered accordingly — items kept out
// by the channel length limit must be left for the next batch, not marked
// successful along with the rest. This is exactly where "silent loss" comes from:
// the message was truncated, but the delivery record shows everything delivered,
// and no place reveals that the second half was never sent.
//
// maxBytes<=0 means no limit.
func markdownBody(m Message, maxBytes int) (string, int) {
	if !m.Batch {
		if len(m.Items) == 0 {
			return "", 0
		}
		var b strings.Builder
		writeItem(&b, m.Items[0], "", true)
		// A single message is sent even if oversized (the final truncation is the
		// backstop): partial information about one vulnerability beats sending none.
		return TruncateBytes(b.String(), maxBytes), 1
	}

	footer := ""
	if m.HomeURL != "" {
		footer = fmt.Sprintf("\n[View all in the platform](%s)\n", m.HomeURL)
	}
	kept := packItemCount(m.Items, maxBytes, markdownReservedBytes, footer, byteSize, func(it Item, idx int) string {
		var b strings.Builder
		writeItem(&b, it, fmt.Sprintf("%d. ", idx+1), false)
		return b.String()
	})

	items := m.Items[:kept]
	var b strings.Builder
	b.WriteString(markdownBatchIntro(m, items, len(m.Items)))
	for i, it := range items {
		writeItem(&b, it, fmt.Sprintf("%d. ", i+1), false)
	}
	b.WriteString(footer)
	return TruncateBytes(b.String(), maxBytes), kept
}

// markdownBatchIntro renders the opening of a digest message: the time window,
// the count and the severity distribution. With these, someone receiving a digest
// can judge whether this batch needs immediate attention without opening the
// platform.
//
// items are the ones **actually packed in**, total is the batch's expected total.
// When they differ, it must be stated how many items are in the next message —
// otherwise the reader assumes the number in the header is all of them, and the
// items that were never sent simply don't exist anywhere in the UI.
func markdownBatchIntro(m Message, items []Item, total int) string {
	var b strings.Builder
	if m.WindowMinutes > 0 {
		fmt.Fprintf(&b, "**%d new vulnerabilities in the last %d minutes**", total, m.WindowMinutes)
	} else {
		fmt.Fprintf(&b, "**%d new vulnerabilities**", total)
	}
	if extra := total - len(items); extra > 0 {
		fmt.Fprintf(&b, " (showing the first %d here; the remaining %d continue in the next message)", len(items), extra)
	}
	// Give the distribution by severity so the reader sees at a glance whether any
	// critical items are present. Only items **actually included here** are counted,
	// so "Critical 3" stays consistent with the items countable below.
	counts := map[string]int{}
	for _, it := range items {
		counts[it.Severity]++
	}
	var parts []string
	for _, sev := range []string{"critical", "high", "medium", "low"} {
		if n := counts[sev]; n > 0 {
			parts = append(parts, fmt.Sprintf("%s %d", SeverityLabel(sev), n))
		}
	}
	if len(parts) > 0 {
		b.WriteString("\n" + strings.Join(parts, " · "))
	}
	b.WriteString("\n\n")
	return b.String()
}

// writeItem renders a single vulnerability item.
//
// prefix is used for the digest list numbering; when single=true it renders the
// full version (with summary and backlink), while the digest list renders only a
// one-line summary — otherwise a 50-item digest becomes a long document.
//
// All externally sourced content (title/class/assets/summary) goes through
// markdownText: single-lining + escaping. The backlink is assembled from the
// admin-configured public_base_url, is not untrusted content, and must be a
// clickable link, so it is output as-is.
func writeItem(b *strings.Builder, it Item, prefix string, single bool) {
	line := fmt.Sprintf("%s**%s · %s**", prefix, SeverityLabel(it.Severity), markdownText(it.Title(), 0))
	if !single {
		// Digest mode: presented on one line, with assets and summary compressed
		// after it.
		var extras []string
		if a := assetLine(it.Assets, maxAssetsShown); a != "" {
			extras = append(extras, markdownText(a, 0))
		}
		if it.Summary != "" {
			extras = append(extras, markdownText(it.Summary, 60))
		}
		if len(extras) > 0 {
			line += " — " + strings.Join(extras, " · ")
		}
		b.WriteString(line + "\n")
		return
	}
	b.WriteString(line + "\n")
	if it.IsStatusChange() {
		fmt.Fprintf(b, "**Status change**: %s → %s\n",
			markdownText(StatusLabel(it.FromStatus), 0), markdownText(StatusLabel(it.ToStatus), 0))
	}
	if it.VulnClass != "" && it.VulnClass != it.Title() {
		fmt.Fprintf(b, "**Class**: %s\n", markdownText(it.VulnClass, 0))
	}
	if a := assetLine(it.Assets, maxAssetsShown); a != "" {
		fmt.Fprintf(b, "**Assets**: %s\n", markdownText(a, 0))
	}
	if it.Summary != "" {
		if s := markdownText(it.Summary, maxSummaryRunes); s != "" {
			fmt.Fprintf(b, "**Summary**: %s\n", s)
		}
	}
	if it.DetailURL != "" {
		fmt.Fprintf(b, "[View details](%s)\n", it.DetailURL)
	}
}
