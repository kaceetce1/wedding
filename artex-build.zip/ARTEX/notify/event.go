package notify

// Snapshot is the contract for the notification_events.snapshot JSONB column. The
// writer is the finding-persistence transaction in the db layer; the readers are
// the delivery engine and filter matching in the server layer. It is defined in
// this package because it is the "notification domain" payload: db is only
// responsible for serialization and does not understand the field meanings.
//
// Why store the finding fields redundantly instead of looking them up at render
// time: findings get renamed, re-graded and re-statused after the fact, but the
// pushed content should reflect the conclusion **as of the moment it happened** —
// a lookup would yield the dangerous misleading result of "later downgraded to
// low". It also means fan-out and rendering don't need to JOIN the findings/tasks/
// assets tables.
type Snapshot struct {
	// Event type: finding_created / finding_status_changed
	Kind      string  `json:"kind"`
	FindingID int64   `json:"finding_id"`
	TaskID    int64   `json:"task_id"`
	VulnClass string  `json:"vulnclass"`
	Name      string  `json:"name"`
	Severity  string  `json:"severity"`
	Summary   string  `json:"summary"`
	AssetIDs  []int64 `json:"asset_ids"`
	// Non-empty only when kind=finding_status_changed.
	FromStatus string `json:"from_status,omitempty"`
	ToStatus   string `json:"to_status,omitempty"`
}

// Item is a vulnerability awaiting push, for a channel to render.
type Item struct {
	FindingID int64
	Name      string
	VulnClass string
	Severity  string
	Summary   string
	// Assets are the parsed asset display names (e.g. domain/IP). Filled in by the
	// server layer — this package does not touch the database and can't get them.
	Assets []string
	// DetailURL is the finding detail backlink; empty means public_base_url is not
	// configured, and it is omitted at render time.
	DetailURL string
	// Specific to status-change events; when both are non-empty they render as
	// "Pending → Fixed".
	FromStatus string
	ToStatus   string
}

// IsStatusChange reports whether the item is a status-change event.
func (i Item) IsStatusChange() bool { return i.FromStatus != "" || i.ToStatus != "" }

// Title returns the item's display title: prefer the human-assigned name, fall
// back to the vulnerability class vulnclass, and if both are empty use a
// placeholder — never output an empty title.
func (i Item) Title() string {
	if i.Name != "" {
		return i.Name
	}
	if i.VulnClass != "" {
		return i.VulnClass
	}
	return "(Unnamed vulnerability)"
}

// Message is the full content of one channel send.
type Message struct {
	// Length 1 for a single push; a whole batch for a digest push.
	// An empty slice is illegal; the caller must guarantee at least one item.
	Items []Item
	// When Batch=true it renders as a digest message (different title, with the
	// time window and item count).
	Batch bool
	// WindowMinutes is the digest window (minutes), used only when Batch=true for
	// the "last N minutes" wording. Deliberately passed in explicitly by config
	// rather than computed at render time with time.Since: keeping rendering
	// deterministic makes it testable.
	WindowMinutes int
	// HomeURL is the platform dashboard URL (global public_base_url); empty means
	// no dashboard entry.
	HomeURL string
}
