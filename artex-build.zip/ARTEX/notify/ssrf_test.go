package notify

import (
	"context"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"strings"
	"testing"
)

// This file covers two related hardening measures:
//   ① A delivery address must not turn the server into a springboard to hit the
//      internal network / cloud metadata (SSRF)
//   ② The address-validation error text must not carry the credential in the address
//
// About the test environment: many cases in this package use httptest fake
// receivers on 127.0.0.1, which the guard blocks by default. So TestMain turns
// AllowLocalTargetsEnv on globally, and each SSRF case below explicitly clears it
// to assert the **default-deny** behavior.

func TestMain(m *testing.M) {
	// Let the regular cases reach the local fake receivers; the SSRF cases clear it
	// themselves temporarily.
	_ = os.Setenv(AllowLocalTargetsEnv, "1")
	os.Exit(m.Run())
}

// TestDialGuardRejectsLoopbackByDefault is the core SSRF assertion: under the
// default config, delivering to a loopback address must be refused by the
// **connection layer**.
func TestDialGuardRejectsLoopbackByDefault(t *testing.T) {
	var hit bool
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		hit = true
		_, _ = io.WriteString(w, `{"errcode":0}`)
	}))
	defer srv.Close()

	t.Setenv(AllowLocalTargetsEnv, "") // clearing the escape hatch = the default behavior
	_, err := (dingTalkChannel{}).Send(context.Background(),
		map[string]any{"webhook": srv.URL + "/robot/send"}, Message{Items: []Item{{Severity: "high"}}})
	if err == nil {
		t.Fatal("by default, delivery to a loopback address should not be allowed")
	}
	if hit {
		t.Fatal("the request already reached the local service — the guard is not working")
	}
	// The error should guide the user on how to open it up (a local SMTP relay is a
	// legitimate config).
	if !strings.Contains(err.Error(), AllowLocalTargetsEnv) {
		t.Errorf("the refusal message should explain how to explicitly allow it: %v", err)
	}
}

// TestDialGuardAllowsLoopbackWhenOptedIn is the reverse case: after explicitly
// turning it on, it must work, otherwise legitimate deployments like a local
// postfix / internal relay would be flatly disabled.
func TestDialGuardAllowsLoopbackWhenOptedIn(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		_, _ = io.WriteString(w, `{"errcode":0,"errmsg":"ok"}`)
	}))
	defer srv.Close()

	t.Setenv(AllowLocalTargetsEnv, "1")
	if _, err := (dingTalkChannel{}).Send(context.Background(),
		map[string]any{"webhook": srv.URL + "/robot/send"}, Message{Items: []Item{{Severity: "high"}}}); err != nil {
		t.Fatalf("after explicitly allowing it, delivery should work: %v", err)
	}
}

func TestIsBlockedDialIP(t *testing.T) {
	blocked := []string{
		"127.0.0.1", "127.1.2.3", "::1",
		"169.254.169.254", // cloud metadata endpoint — the main reason this function exists
		"169.254.1.1", "fe80::1",
		"0.0.0.0", "::",
		"224.0.0.1", "ff02::1",
		"::ffff:127.0.0.1", // the IPv4-mapped form must be unmapped before judging, otherwise it is a bypass
		"",
	}
	for _, s := range blocked {
		if !isBlockedDialIP(net.ParseIP(s)) {
			t.Errorf("%s should be blocked", s)
		}
	}
	// RFC1918 private networks are **deliberately allowed**: a self-hosted internal
	// Mattermost / SMTP relay is common legitimate usage. This assertion pins the
	// tradeoff down — if someone later adds a private-network check, this fails and
	// forces a conscious decision (rather than silently killing a batch of
	// deployments).
	allowed := []string{"10.0.0.5", "172.16.3.4", "192.168.1.10", "8.8.8.8", "2606:4700::1111"}
	for _, s := range allowed {
		if isBlockedDialIP(net.ParseIP(s)) {
			t.Errorf("%s should be allowed (private networks are a common legitimate delivery target)", s)
		}
	}
}

// TestValidateHTTPURLRejectsLiteralPrivateTargets covers the config-stage heads-up:
// a literal IP should be rejected at save time, not wait until the first delivery
// fails.
func TestValidateHTTPURLRejectsLiteralPrivateTargets(t *testing.T) {
	t.Setenv(AllowLocalTargetsEnv, "")
	for _, raw := range []string{
		"http://127.0.0.1:8080/hook",
		"http://169.254.169.254/latest/meta-data/",
		"http://[::1]:8080/hook",
	} {
		if err := validateHTTPURL(raw); err == nil {
			t.Errorf("%s should be rejected at the config stage", raw)
		}
	}
	// Public and private addresses pass as usual (private networks are left to the
	// dial stage, which doesn't block them).
	for _, raw := range []string{"https://oapi.dingtalk.com/robot/send", "http://10.0.0.9/hook"} {
		if err := validateHTTPURL(raw); err != nil {
			t.Errorf("%s should pass validation: %v", raw, err)
		}
	}
}

// TestValidateHTTPURLErrorNeverLeaksCredentials is a branch the audit pointed out
// I missed in the previous round.
//
// When url.Parse **fails** it returns a *url.Error whose Error() contains the full
// original address. In the previous round I only redacted http.Client.Do's returned
// error and missed this one; and the "permanent-failure path" cases I added then
// (file://, gopher://, ftp://) can all actually be parsed by url.Parse and take the
// scheme branch, so being all green proved nothing about this path — a false
// assurance.
func TestValidateHTTPURLErrorNeverLeaksCredentials(t *testing.T) {
	cases := []string{
		"http://127.0.0.1/%zz?access_token=" + leakProbeToken,         // illegal percent escape
		"https://a.example.com:port/x?access_token=" + leakProbeToken, // port not a number
		"http://[::1?access_token=" + leakProbeToken,                  // unbalanced brackets
	}
	for _, raw := range cases {
		// First confirm this input **really** makes url.Parse fail. Without this step
		// the case could silently take another branch (that's where the previous
		// round's false assurance came from).
		if _, err := url.Parse(raw); err == nil {
			t.Errorf("%q should have failed to parse, otherwise this case doesn't cover the target branch", raw)
			continue
		}
		err := validateHTTPURL(raw)
		if err == nil {
			t.Errorf("%q should fail validation", raw)
			continue
		}
		assertNoSecret(t, err.Error(), leakProbeToken)
	}
	// Confirm the channel-layer wrapper doesn't carry the address out either.
	t.Setenv(AllowLocalTargetsEnv, "")
	err := (dingTalkChannel{}).Validate(map[string]any{"webhook": cases[0]})
	if err == nil {
		t.Fatal("an illegal address should fail validation")
	}
	assertNoSecret(t, err.Error(), leakProbeToken)
}

// TestEmailDialGuardRejectsLoopbackByDefault covers the SMTP channel's dial guard.
//
// The email channel once used a bare net.Dialer and was the one gap in the whole
// SSRF protection: with host set to 169.254.169.254 or 127.0.0.1 it could connect
// directly, and when smtp.NewClient's handshake failed it wrapped the peer's
// returned line into the error, which via last_error was echoed by the delivery
// history endpoint — exactly the semi-blind read primitive the other channels had
// already closed; the timing difference between "connection refused vs timeout"
// could also be used to probe ports.
//
// This package's TestMain turns AllowLocalTargetsEnv on globally (many cases use
// fake receivers on 127.0.0.1), so this case must clear it itself — otherwise it
// passes whether or not the guard exists, which is exactly why the gap was never
// found by any test.
func TestEmailDialGuardRejectsLoopbackByDefault(t *testing.T) {
	f := newFakeSMTP(t)
	cfg := emailCfg(t, f, nil)

	t.Setenv(AllowLocalTargetsEnv, "") // clearing the escape hatch = the default behavior
	_, err := (emailChannel{}).Send(context.Background(), cfg, singleMsg())
	if err == nil {
		t.Fatal("by default, email delivery to a loopback address should not be allowed")
	}
	// The connection should never be established: the guard blocks it in the Control
	// hook, so EHLO is never sent.
	if f.sawCommand("EHLO") || f.sawCommand("HELO") {
		t.Fatal("the SMTP session was already established — the guard is not working")
	}
	// The error should guide the user on how to open it up (a local postfix relay is
	// a legitimate config).
	if !strings.Contains(err.Error(), AllowLocalTargetsEnv) {
		t.Errorf("the refusal message should explain how to explicitly allow it: %v", err)
	}
}

// TestEmailDialGuardAllowsLoopbackWhenOptedIn is the paired reverse case: after
// explicitly turning it on, delivery must work normally. A self-hosted internal
// SMTP / local relay is a very common deployment, and the guard must not flatly
// block it.
func TestEmailDialGuardAllowsLoopbackWhenOptedIn(t *testing.T) {
	f := newFakeSMTP(t)
	cfg := emailCfg(t, f, nil)

	t.Setenv(AllowLocalTargetsEnv, "1")
	if _, err := (emailChannel{}).Send(context.Background(), cfg, singleMsg()); err != nil {
		t.Fatalf("after explicitly allowing it, local SMTP should be deliverable: %v", err)
	}
	if !f.sawCommand("EHLO") {
		t.Fatal("no EHLO seen — the session wasn't really established")
	}
}
