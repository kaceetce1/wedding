package notify

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"os"
	"strings"
	"syscall"
	"time"
)

// allowLocalTargets decides whether delivering messages to loopback / link-local
// addresses is allowed.
//
// Rejected by default. These address ranges are not places an IM robot or a public
// mail server would appear, and what they can reach is very sensitive: the admin
// port of another service on the same host, and a cloud environment's metadata
// endpoint (169.254.169.254, which can read out instance credentials). The
// delivery address is set by an admin, but an admin session hijacked via XSS/CSRF,
// or a second person sharing the same JWT, can change the config to read the
// response content back — doJSON writes the first 200 bytes of a 4xx/5xx response
// body into last_error, and the delivery history endpoint echoes it back, which is
// a semi-blind read primitive.
//
// But a "localhost SMTP relay" (postfix on 127.0.0.1:25) is a common setup for
// self-hosted mail, and a blanket ban would block people. So an explicit escape
// hatch is left instead of hardcoding an allowance: setting
// ARTEX_NOTIFY_ALLOW_LOCAL=1 enables it.
//
// Exported as AllowLocalTargetsEnv so tests can explicitly enable it — this
// package's and the server package's cases make heavy use of httptest fake
// receivers on 127.0.0.1, which would all be stopped by the guard otherwise.
const AllowLocalTargetsEnv = "ARTEX_NOTIFY_ALLOW_LOCAL"

func allowLocalTargets() bool {
	v := strings.TrimSpace(os.Getenv(AllowLocalTargetsEnv))
	return v == "1" || strings.EqualFold(v, "true")
}

// isBlockedDialIP reports whether the target IP belongs to a range that is "not
// allowed for delivery by default".
//
// Only loopback, link-local (including the cloud metadata 169.254.169.254),
// unspecified and multicast are rejected. RFC1918 private networks are **not**
// rejected: a self-hosted internal Mattermost / SMTP relay is a common legitimate
// use, and blocking them too would make the feature unusable in real
// environments. This tradeoff is deliberate — the protection must block genuinely
// sensitive targets without disabling normal deployments along with them.
func isBlockedDialIP(ip net.IP) bool {
	if ip == nil {
		return true
	}
	// An IPv4-mapped IPv6 (::ffff:127.0.0.1) must be converted back to IPv4 before
	// checking, otherwise the check is bypassed.
	if v4 := ip.To4(); v4 != nil {
		ip = v4
	}
	return ip.IsLoopback() || ip.IsLinkLocalUnicast() || ip.IsLinkLocalMulticast() ||
		ip.IsInterfaceLocalMulticast() || ip.IsUnspecified() || ip.IsMulticast()
}

// blockInternalDial is the Control hook for http.Transport's dialer, checking the
// target address **when the connection is established**.
//
// Why at the dial stage rather than only validating when saving config: this is the
// point where it actually takes effect. It also covers two cases that bypass config
// validation — DNS rebinding (resolving to a public IP at validation time, an
// internal IP at connection time) and redirects (though we already reject
// cross-host redirects, a same-host redirect may still point the path elsewhere).
func blockInternalDial(_, address string, _ syscall.RawConn) error {
	if allowLocalTargets() {
		return nil
	}
	host, _, err := net.SplitHostPort(address)
	if err != nil {
		return err
	}
	ip := net.ParseIP(host)
	if ip == nil {
		return fmt.Errorf("cannot resolve target address %q", host)
	}
	if isBlockedDialIP(ip) {
		return fmt.Errorf("refusing to deliver to a local/link-local address %s (if you really need to deliver to a local service, set %s=1)", ip, AllowLocalTargetsEnv)
	}
	return nil
}

// notifyTransport adds only a dial guard on top of the default Transport.
// Clone is used to preserve all the default tuning (connection pool, HTTP/2,
// timeouts, proxy, etc.), avoiding behavior changes just to add a check.
var notifyTransport = func() *http.Transport {
	t, ok := http.DefaultTransport.(*http.Transport)
	if !ok {
		return &http.Transport{}
	}
	clone := t.Clone()
	clone.DialContext = (&net.Dialer{Timeout: 10 * time.Second, Control: blockInternalDial}).DialContext
	return clone
}()

// httpClient is the client shared by all channel deliveries.
//
// It deliberately does **not** reuse the project's global egress proxy (the
// server-side GlobalProxy): that proxy is for penetration-target traffic and is
// often an unstable tunnel, and notification availability should not be held
// hostage by the target network's flakiness. IM pushes connect directly. The
// timeout is 15 seconds — a peer slower than that is effectively already in a
// failure state.
//
// Cross-host redirects are rejected: this feature's delivery addresses are all of
// the form "one fixed endpoint" and would not normally redirect to another host;
// and these vendors' credentials (DingTalk's access_token, WeCom's key, Telegram's
// bot token) are **in the URL itself**, so following a cross-host redirect amounts
// to handing the credentials to the redirect target. Same-host redirects (e.g.
// appending a trailing slash) are still allowed.
var httpClient = &http.Client{
	Timeout:   15 * time.Second,
	Transport: notifyTransport,
	CheckRedirect: func(req *http.Request, via []*http.Request) error {
		if len(via) >= 5 {
			return errors.New("too many redirects")
		}
		if len(via) > 0 && req.URL.Host != via[0].URL.Host {
			return fmt.Errorf("refusing cross-host redirect (%s → %s)", via[0].URL.Host, req.URL.Host)
		}
		return nil
	},
}

// respBodyLimit caps the size of the response body read. A misbehaving peer may
// return an oversized body, and we only need the error code and a short error
// description to display in the delivery history.
const respBodyLimit = 8 << 10

// doJSON sends one request and returns the response body (length-capped).
//
// A nil payload sends an empty body (for GET or cases where the platform doesn't
// require one). Header key/values are attached as-is, for the generic webhook's
// custom headers.
//
// Error classification is this function's core responsibility: network-layer
// failures and 5xx/408/429 are "retryable", the other 4xx are "permanent
// failures" — retrying a 403 just spams the same error into the log 3 times.
func doJSON(ctx context.Context, method, url string, headers map[string]string, payload any) ([]byte, error) {
	var body io.Reader
	if payload != nil {
		raw, err := json.Marshal(payload)
		if err != nil {
			// Serialization failure is a local bug (wrong config field type) and
			// retrying won't help.
			return nil, Permanent(fmt.Errorf("failed to build request body: %w", err))
		}
		body = bytes.NewReader(raw)
	}
	req, err := http.NewRequestWithContext(ctx, method, url, body)
	if err != nil {
		// Invalid URL — most likely the user entered the address wrong, a permanent
		// failure. Here too err must not be passed through: url.Parse's error text
		// contains the full address.
		return nil, Permanent(fmt.Errorf("invalid request address: %s", redactRequestTarget(url)))
	}
	if payload != nil {
		req.Header.Set("Content-Type", "application/json; charset=utf-8")
	}
	for k, v := range headers {
		req.Header.Set(k, v)
	}
	resp, err := httpClient.Do(req)
	if err != nil {
		// Connection refused, DNS failure, timeout — mostly transient, left to
		// backoff retries.
		//
		// The error text must be redacted before being passed outward. Reason:
		// http.Client.Do returns a *url.Error whose Error() is
		// `Op "full URL": underlying error`, and this feature's vendors' credentials
		// are **in the URL** (DingTalk access_token, WeCom key, Feishu hook id,
		// Telegram /bot<token>/). Without redaction, the credentials would leak
		// along this error string to four places: notification_deliveries'
		// last_error (stored in plaintext), the delivery history endpoint's response
		// (**bypassing the channel config's masking**), the server log, and the 502
		// text the test-send endpoint returns to the frontend.
		return nil, fmt.Errorf("request failed: %s", redactTransportError(err))
	}
	defer resp.Body.Close()
	raw, readErr := io.ReadAll(io.LimitReader(resp.Body, respBodyLimit))
	if readErr != nil {
		return nil, fmt.Errorf("failed to read response: %w", readErr)
	}
	if resp.StatusCode >= 200 && resp.StatusCode < 300 {
		return raw, nil
	}
	// 429 (rate limit) and 408 (timeout) are worth retrying; the other 4xx are
	// config or permission issues, where retrying is pointless.
	if resp.StatusCode == http.StatusTooManyRequests || resp.StatusCode == http.StatusRequestTimeout {
		return nil, fmt.Errorf("peer rate-limited or timed out (HTTP %d): %s", resp.StatusCode, snippet(raw))
	}
	if resp.StatusCode >= 500 {
		return nil, fmt.Errorf("peer service error (HTTP %d): %s", resp.StatusCode, snippet(raw))
	}
	return nil, Permanent(fmt.Errorf("peer rejected the request (HTTP %d): %s", resp.StatusCode, snippet(raw)))
}

// snippet compresses the response body into a short one-line text for error
// messages. The response may contain newlines and lots of whitespace, and putting
// it straight into last_error would wreck the delivery history page's layout.
func snippet(raw []byte) string {
	return OneLine(string(raw), 200)
}

// redactRequestTarget compresses a delivery address into "scheme://host/…" for
// error messages.
//
// This is the package's one address-redaction rule, deliberately made **crude
// enough**: aside from scheme and host, everything else is dropped. The reason is
// that there is no "generic and safe" way to tell which part of a URL is a
// credential:
//
//	DingTalk  credential in query       /robot/send?access_token=xxx
//	WeCom     credential in query       /cgi-bin/webhook/send?key=xxx
//	Feishu    credential in **last path segment** /open-apis/bot/v2/hook/<hook_id>
//	Telegram  credential in **middle path segment** /bot<token>/sendMessage
//
// Trying to "keep only the useful part" means patching per channel, and missing
// any one is a credential leak. Keeping the host is enough for troubleshooting
// (DNS resolution failures, connection failures, bad certificates can all be
// located), and which robot it specifically is can be recognized from the masked
// tail hint in the channel config.
//
// On parse failure it returns a fixed placeholder — never echo the raw string.
func redactRequestTarget(raw string) string {
	u, err := url.Parse(raw)
	if err != nil || u.Host == "" {
		return "(unparseable address)"
	}
	return u.Scheme + "://" + u.Host + "/…"
}

// redactTransportError strips the address from a transport-layer error, keeping
// only the underlying cause.
//
// *url.Error's structure is {Op, URL, Err}, and Error() prints the URL too. This
// explicitly takes the Err field, bypassing its Error() — more reliable than
// string replacement afterwards, because replacement would have to correctly
// handle the various URL-encoded/escaped variants and easily misses one.
func redactTransportError(err error) string {
	var uerr *url.Error
	if errors.As(err, &uerr) {
		host := ""
		if u, parseErr := url.Parse(uerr.URL); parseErr == nil {
			host = u.Host
		}
		if uerr.Err != nil {
			return fmt.Sprintf("%s %s: %s", uerr.Op, host, uerr.Err)
		}
		return fmt.Sprintf("%s %s: unknown error", uerr.Op, host)
	}
	// Non-*url.Error (e.g. an error returned by the redirect policy) may also carry
	// an address; route it through redaction uniformly.
	return redactURLsInText(err.Error())
}

// redactURLsInText replaces http(s) addresses occurring in a text with their
// redacted form.
//
// Used as a backstop for errors where structured fields aren't available (redirect
// policy errors, third-party libraries' custom errors). Only http/https prefixes
// are recognized, split on whitespace and quotes — addresses contain neither.
func redactURLsInText(s string) string {
	var b strings.Builder
	for i := 0; i < len(s); {
		rest := s[i:]
		if strings.HasPrefix(rest, "http://") || strings.HasPrefix(rest, "https://") {
			end := len(rest)
			if j := strings.IndexAny(rest, " \t\n\"'"); j >= 0 {
				end = j
			}
			b.WriteString(redactRequestTarget(rest[:end]))
			i += end
			continue
		}
		b.WriteByte(s[i])
		i++
	}
	return b.String()
}
