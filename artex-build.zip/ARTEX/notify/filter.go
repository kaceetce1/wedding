package notify

import (
	"encoding/json"
	"fmt"
	"slices"
	"strings"
)

// Filter is the contract for the notification_channels.filter JSONB column: the
// filter conditions of a channel instance. All fields are optional, and the
// default means "no filtering" — which is exactly the fallback semantics for
// malformed config, see ParseFilter.
type Filter struct {
	// MinSeverity is the minimum severity threshold (low/medium/high/critical);
	// empty = no threshold.
	MinSeverity string `json:"min_severity"`
	// An empty TaskIDs / AssetIDs array means unrestricted; a non-empty one
	// requires the event to intersect it.
	TaskIDs  []int64 `json:"task_ids"`
	AssetIDs []int64 `json:"asset_ids"`
	// An empty VulnClassInclude means accept everything; a non-empty one requires
	// vulnclass to match one of the keywords.
	// VulnClassExclude excludes on matching any keyword (exclusion takes priority
	// over inclusion).
	// Matching is case-insensitive substring — safer than regex: a user's broken
	// regex won't silently disable the channel.
	VulnClassInclude []string `json:"vulnclass_include"`
	VulnClassExclude []string `json:"vulnclass_exclude"`
	// OnStatusChange determines whether this channel receives vulnerability
	// status-change events (only meaningful in realtime mode).
	OnStatusChange bool `json:"on_status_change"`
}

// ParseFilter parses a channel filter config.
//
// **Never returns an error.** This is a deliberate design choice: when the filter
// config is malformed it always degrades to the zero-value Filter (= no filtering
// = match everything), because for a vulnerability notification system, **pushing
// one extra message is far better than silently missing a high-severity one**.
// Making a parse failure mean "don't push" would hand the user a channel that
// looks configured but actually pushes nothing — the worst possible failure mode.
func ParseFilter(raw []byte) Filter {
	var f Filter
	if len(raw) == 0 {
		return f
	}
	// On parse failure f stays zero-value, i.e. no filtering.
	_ = json.Unmarshal(raw, &f)
	return f
}

// ValidMinSeverity reports whether s is a valid severity threshold (an empty
// string means no threshold).
func ValidMinSeverity(s string) bool {
	if s == "" {
		return true
	}
	_, ok := severityRank[s]
	return ok
}

// Validate checks the fields with **constrained values** in a filter config, for
// use when saving a channel.
//
// Why it must be caught at write time: Match evaluates an unknown threshold as
// `rank >= 0`, which is always true — meaning a single typo in min_severity
// ("hgih") makes the filter **silently fail** and become "push everything". This
// is consistent with this package's "rather push too much than miss" tradeoff (it
// won't miss), but the consequence is that the user thinks they're doing graded
// pushes while actually flooding the group with every vulnerability, with no
// indication that they misconfigured it. This kind of "silent degradation" is
// exactly what should be caught at the entry point.
//
// Note Validate is only used on the **write** path. The read path still uses
// ParseFilter's lenient semantics, so bad values already present in historical
// data won't make a channel entirely unreadable.
func (f Filter) Validate() error {
	if !ValidMinSeverity(f.MinSeverity) {
		return fmt.Errorf("invalid minimum severity %q, allowed: low / medium / high / critical, or leave empty for unrestricted", f.MinSeverity)
	}
	return nil
}

// Match determines whether an event should be delivered to a channel with these
// filter conditions.
//
// **Never returns an error**, for the same reason as ParseFilter: any internal
// anomaly is treated as "match". Order of checks: event type → severity
// threshold → task/asset scope → vulnerability class keywords.
func Match(f Filter, s Snapshot) bool {
	// Status-change events are received only by channels that explicitly enable
	// them. Off by default, because the vast majority of users expect "push" to
	// mean "a new vulnerability was found", not a running account of every status
	// transition.
	if s.Kind == EventFindingStatusChanged && !f.OnStatusChange {
		return false
	}
	if !AtLeast(s.Severity, f.MinSeverity) {
		return false
	}
	if len(f.TaskIDs) > 0 && !slices.Contains(f.TaskIDs, s.TaskID) {
		return false
	}
	if len(f.AssetIDs) > 0 && !intersectsInt(f.AssetIDs, s.AssetIDs) {
		return false
	}
	// Exclusion takes priority: matching any exclude keyword drops the event, even
	// if it also matches the include list.
	if len(f.VulnClassExclude) > 0 && containsAnyFold(s.VulnClass, f.VulnClassExclude) {
		return false
	}
	if len(f.VulnClassInclude) > 0 && !containsAnyFold(s.VulnClass, f.VulnClassInclude) {
		return false
	}
	return true
}

func intersectsInt(a, b []int64) bool {
	// A linear scan over a small set is enough; both sides are on the order of
	// "a few dozen hand-ticked items", so building a map costs more than it saves.
	for _, v := range b {
		if slices.Contains(a, v) {
			return true
		}
	}
	return false
}

// containsAnyFold reports whether s contains any of the keywords
// (case-insensitive).
func containsAnyFold(s string, keywords []string) bool {
	lower := strings.ToLower(s)
	for _, kw := range keywords {
		kw = strings.ToLower(strings.TrimSpace(kw))
		if kw != "" && strings.Contains(lower, kw) {
			return true
		}
	}
	return false
}
