package notify

import (
	"strings"
	"unicode/utf8"
)

const ellipsis = "…"

// TruncateBytes truncates s to at most max bytes, guaranteeing the result is valid
// UTF-8 with no character split.
//
// Why cut on a character boundary: the WeCom group robot's markdown has a
// 4096-**byte** hard limit (not character count), while one CJK character is 3
// bytes. Slicing directly by byte would cut a CJK character in half, producing
// invalid UTF-8 — the platform would either reject the whole message or display
// it as garbled blocks. The approach here is to back up from the budget position
// to the nearest rune start byte (utf8.RuneStart detects continuation bytes
// 0b10xxxxxx).
//
// max<=0 means no limit. After truncation an ellipsis is appended, unless max is
// too small to hold it.
func TruncateBytes(s string, max int) string {
	if max <= 0 || len(s) <= max {
		return s
	}
	budget := max - len(ellipsis)
	suffix := ellipsis
	if budget < 0 {
		// max is shorter than the ellipsis: drop the ellipsis and truncate plainly,
		// so the result doesn't end up exceeding max.
		budget = max
		suffix = ""
	}
	cut := budget
	for cut > 0 && !utf8.RuneStart(s[cut]) {
		cut--
	}
	return s[:cut] + suffix
}

// OneLine collapses multi-line text into a single line: fold all whitespace, then
// truncate by character count. Used for IM message title lines — summaries often
// contain newlines, and stuffing them directly into a table/title wrecks the
// layout. max<=0 means no length limit.
func OneLine(s string, max int) string {
	s = strings.Join(strings.Fields(s), " ")
	return TruncateRunes(s, max)
}

// TruncateRunes truncates s to at most max characters (not bytes), appending an
// ellipsis when exceeded. max<=0 means no limit.
//
// The difference from TruncateBytes is the platform's unit: WeCom limits by bytes,
// Telegram by character count. Using the wrong unit causes no error, only a
// message cut far shorter than expected (one CJK character = 3 bytes, so cutting
// 4096 by byte leaves only about 1365 characters), so both functions must be kept
// and chosen per channel.
func TruncateRunes(s string, max int) string {
	if max <= 0 {
		return s
	}
	runes := []rune(s)
	if len(runes) <= max {
		return s
	}
	if max <= 1 {
		return string(runes[:max])
	}
	return string(runes[:max-1]) + ellipsis
}

// TruncateHTML truncates an HTML fragment by character count and guarantees no
// half-open tag is produced.
//
// Truncating HTML by character directly can cut a broken tag like `<a href="htt`;
// the platform's parser would either reject the whole message with an error or
// swallow the following body as an attribute value. The approach here: truncate
// by character first, then check whether the tail has an unclosed `<` and, if so,
// back up to before it.
//
// No tag balancing (completing `</b>` etc.): Telegram's HTML parser closes
// unclosed tags automatically, and implementing balancing ourselves would need to
// handle quotes inside attributes, comments and self-closing tags — complexity out
// of proportion to the benefit.
func TruncateHTML(s string, max int) string {
	if max <= 0 || len([]rune(s)) <= max {
		return s
	}
	cut := TruncateRunes(s, max)
	// If the tail is a fragment starting with `<` (no `>` after the last `<`),
	// back up to before the `<`.
	if lt := strings.LastIndex(cut, "<"); lt >= 0 && !strings.Contains(cut[lt:], ">") {
		cut = cut[:lt]
	}
	// If the tail is a cut HTML entity (e.g. `&amp;` cut into `&amp`), back up too.
	// An entity fragment in a parser that only recognizes entities can get the
	// **entire message** rejected — a digest message over the length limit is
	// already common, and it's not worth losing the whole notification over it.
	if amp := strings.LastIndex(cut, "&"); amp >= 0 && !strings.Contains(cut[amp:], ";") {
		cut = cut[:amp]
	}
	return cut
}

// packItemCount computes how many items fit **completely** within the budget, for
// packing digest messages whole-item by whole-item.
//
// Why whole items rather than rendering the whole thing and truncating: truncation
// would make the items in the second half vanish out of nowhere, while their
// delivery records would still be marked as delivered — invisible in the message
// and invisible in the delivery history; the vulnerabilities are simply gone.
// After packing whole items, the items that don't fit stay in the database as the
// next batch, and the kept value the caller gets is the number of items actually
// delivered in this message.
//
// Parameters: maxSize<=0 means no limit; reserve is the amount held back for the
// message header/footer; size does the measurement (units differ per platform:
// WeCom/DingTalk by byte, Telegram by character count — using the wrong unit
// causes no error, only a CJK message squeezed far below the limit); render turns
// item idx into its actual text — length varies with content, so it can't be
// estimated.
//
// Returns at least 1 (as long as items remain). Even a single extremely oversized
// item must be sent, with the caller's final truncation as the backstop, otherwise
// one oversized vulnerability would block the whole batch forever.
func packItemCount(items []Item, maxSize, reserve int, footer string, size func(string) int, render func(Item, int) string) int {
	if maxSize <= 0 {
		return len(items)
	}
	budget := maxSize - reserve - size(footer)
	if budget < 0 {
		budget = 0
	}
	used := 0
	for i, it := range items {
		used += size(render(it, i))
		if used > budget && i > 0 {
			return i
		}
	}
	return len(items)
}

// byteSize / runeSize are packItemCount's two measurement units, named so that
// call sites don't contain a bare func(s string) int closure that makes it hard to
// tell at a glance which unit is being used.
func byteSize(s string) int { return len(s) }
func runeSize(s string) int { return utf8.RuneCountInString(s) }

// assetLine renders an asset list as a single display line, omitting the rest and
// noting the total when there are more than limit. A vulnerability may be anchored
// to dozens of assets, and listing them all would burst the message.
func assetLine(assets []string, limit int) string {
	if len(assets) == 0 {
		return ""
	}
	if limit <= 0 || len(assets) <= limit {
		return strings.Join(assets, ", ")
	}
	return strings.Join(assets[:limit], ", ") + " and " + itoa(len(assets)) + " more"
}

// itoa is a short alias for strconv.Itoa, used only for building display text, to
// avoid importing strconv everywhere.
func itoa(n int) string {
	if n == 0 {
		return "0"
	}
	neg := n < 0
	if neg {
		n = -n
	}
	var buf [20]byte
	i := len(buf)
	for n > 0 {
		i--
		buf[i] = byte('0' + n%10)
		n /= 10
	}
	if neg {
		i--
		buf[i] = '-'
	}
	return string(buf[i:])
}
