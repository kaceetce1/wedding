// Package notify implements the IM / email push channel adaptation layer for
// vulnerability findings.
//
// Layering: this package is a **leaf package** and depends only on the standard
// library. It knows nothing about the database or the server. Channel config is
// passed in as map[string]any (mapping to the notification_channels.config JSONB
// column), and the content to push is passed in as a Message. The benefit of this
// split is that the genuinely error-prone parts — signature computation, UTF-8
// truncation, filter matching — can be unit-tested without PostgreSQL, and the
// host only needs to orchestrate on the server side.
//
// Concurrency contract: a Channel implementation must be **stateless**. The same
// Channel instance is reused concurrently by multiple channel configs (and even
// by multiple bot instances of the same channel), so all credentials are passed
// in via the cfg parameter, and implementations must not cache things like the
// webhook URL in their own fields.
package notify

// Channel type identifiers. These values are also the legal set for
// notification_channels.kind, validated against a whitelist on the server side
// (same as findings.status — no DB CHECK, to make adding channels easier later).
const (
	KindDingTalk = "dingtalk" // DingTalk custom robot
	KindFeishu   = "feishu"   // Feishu (incl. Lark) custom robot
	KindWeCom    = "wecom"    // WeCom group robot
	KindWebhook  = "webhook"  // Generic webhook: custom method/headers/JSON template
	KindTelegram = "telegram" // Telegram Bot API
	KindEmail    = "email"    // SMTP email
)

// Event types, matching notification_events.kind.
const (
	EventFindingCreated       = "finding_created"
	EventFindingStatusChanged = "finding_status_changed"
)

// InitKind is the fallback value for an empty kind in config.
const InitKind = KindDingTalk

// severityRank maps a vulnerability severity to a comparable ordinal. Unknown
// severities return 0, so any min_severity setting filters unknown severities
// out — when in doubt, don't push, to avoid false-positive spam.
var severityRank = map[string]int{
	"low":      1,
	"medium":   2,
	"high":     3,
	"critical": 4,
}

// SeverityRank returns the ordinal of a severity; unknown severities return 0.
func SeverityRank(severity string) int { return severityRank[severity] }

// SeverityLabel returns the emoji-prefixed severity label, used for message
// titles and card colors. Unknown severities are echoed as-is, not invented.
func SeverityLabel(severity string) string {
	switch severity {
	case "critical":
		return "🔴 Critical"
	case "high":
		return "🟠 High"
	case "medium":
		return "🟡 Medium"
	case "low":
		return "🔵 Low"
	default:
		return severity
	}
}

// StatusLabel translates a handling status into a display label, used in
// status-change messages.
func StatusLabel(status string) string {
	switch status {
	case "pending":
		return "Pending"
	case "in_progress":
		return "In Progress"
	case "confirmed":
		return "Confirmed"
	case "resolved":
		return "Resolved"
	case "fixed":
		return "Fixed"
	case "false_positive":
		return "False Positive"
	case "ignored":
		return "Ignored"
	case "duplicate":
		return "Duplicate"
	case "risk_accepted":
		return "Risk Accepted"
	default:
		return status
	}
}

// AtLeast reports whether severity reaches the min threshold. An empty min means
// no threshold, so everything passes. Note that an unknown severity has ordinal
// 0, so it is rejected by any non-empty min (see the severityRank comment).
func AtLeast(severity, min string) bool {
	if min == "" {
		return true
	}
	return SeverityRank(severity) >= SeverityRank(min)
}
